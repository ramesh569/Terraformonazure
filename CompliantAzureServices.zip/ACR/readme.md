## ACR Bicep Module

The example demonstrating the use of ACR bicep module in coordination with other resources is available in CCC ACR feature [Click here](https://dev.azure.com/raboweb/Cloud%20Competence%20Center/_git/ft-containerregistry)

The parameters used to create ACR ( and other ) resources can be initialised in the JSON parameter file which inturn can be passed to these BICEP modules. The parameter file should strictly follow the structure as defined in the file [ACR parameters](https://dev.azure.com/raboweb/Cloud%20Competence%20Center/_git/ft-containerregistry?path=/parameters/acr-params.json) .

