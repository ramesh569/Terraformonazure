# Structure of this Service

Azure Backup
├───Backup - Backup Vault - Backup Storage Account
├───Backup - Backup Vault - Backup Disk
└───Recovery - Recovery Services Vault

See ft-backup in the QuickStarts on Confluence

2023-09-21: updated API versions of modules and set the softdelete and immutability options