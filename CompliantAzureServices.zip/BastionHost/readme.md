## BastionHost Bicep Module

The example demonstrating the use of APIM bicep module in coordination with other resources is available in [CCC Bastion feature](https://dev.azure.com/raboweb/Cloud%20Competence%20Center/_git/ft-bastion?path=/zexamples)

The parameters used to create APIM ( and other ) resources can be initialised in the JSON parameter file which inturn can be passed to these BICEP modules. The parameter file should strictly follow the structure as defined in the [parameters](https://dev.azure.com/raboweb/Cloud%20Competence%20Center/_git/ft-bastion?path=/parameters) folder.
