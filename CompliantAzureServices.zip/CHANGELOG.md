## 2024-08-01
### Changed
- AppGW\appgw_module.bicep - added capacity for scaling and zone redundancy

## 2024-06-18
### Changed
- appserviceplan_module.bicep - updated to version 2022-09-01 where skuTier is no longer used
- appserviceplan_module.bicep - added skuCapacity, maximumElasticWorkerCount, elasticScaleEnabled and zoneRedundant

## 2024-05-28
### Changed
- appinsights_loganalytics_module.bicep - added appId output

## 2024-05-06
### Changed
- VirtualMachine\virtualmachine_module.bicep - conditionalized the plan part (only needed for Marketplace EULA acceptance)

## 2024-04-26
### Changed
- vnet / vnet_module_bastion_subnet.bicep - Enable private endpoint network policy 
- vnet / vnet_module_bastion_subnet_natgw.bicep - Enable private endpoint network policy 

## 2024-04-24
### Changed
- aci_module.bicep - changed the api version, added subnet instead of network profile, added user assigned identity option and imageRegistryCredentials support for ACR logon

## 2024-04-11
### Changed
- Update sqlDatabase\sqlmi_module.bicep
- virtualmachine_module.bicep - added plan for VM with use of Marketplace images

## 2024-04-05
### Changed
- Add subnetIds as output of Vnet/vnet_module.bicep
- Fix module EventHub/eventhub_vnet_module.bicep
- Fix module Relay/relay_module.bicep

## 2024-04-04
### Changed
- Update Operations/CallDSM.ps1 to version 3.0.1

## 2024-03-28
### Changed
- vnet / vnet_module_bastion_subnet.bicep - Enable private endpoint network policy 

## 2024-02-15
### Changed
- PostgreSqlFlexible / server-module.bicep - support for ReviveDropped createMode 

## 2024-02-14
### Added
- PostgreSqlFlexible folder and its modules

## 2024-02-08
### Changed
- For all CosmosDB modules, changed the API version to refer to the latest version.
- For the acount related CosmosDB modules, make sure to only allow TLS1.2 and up.

## 2024-01-18
### Changed
- loganalytics_module.bicep  - output 2 extra properties (used in, for example, a managed environment configuration)
- managedEnvironment_module.bicep  - made runtimeSubnetId optional, ARM asks to use InfrastructureSubnetId instead (see ManagedEnvironmentInvalidNetworkConfiguration error code)

## 2023-11-15
### Changed
- frontdoorcdn_module.bicep  - endpoint fix to be useable with new deployments but also with re-deployments
- frontdoorcdn_pubdns_module.bicep - endpoint fix to be useable with new deployments but also with re-deployments

## 2023-11-07
### Changed
- frontdoorcdn_module.bicep - updated api versions
- frontdoorcdn_pubdns_module.bicep - made aware of existing installation to prevent creation of another endpoint and failing further in installation
- roleassignment_RG_module.bicep - added scope to get rid of warning during deployment

## 2023-10-05
### Changed
- allow to override (scm)IpSecurityRestrictionsSettings for ft-webapp, ft-functionapp and ft-logicapp standard feature

## 2023-10-04
### Changed
- use (scm)IpSecurityRestrictionsDefaultAction as Deny in ft-webapp, ft-functionapp and ft-logicapp standard feature

## 2023-10-04
### Changed
- added property for SoftDelete in ft-backup feature

## 2023-10-02
### Changed
- updated API versions of modules and set the softdelete and immutability options
- added parameters for diff in Dev and Prod

## 2023-09-22
### Added 
- Fixed parameter and cleanup
### Changed

## 2023-09-22
### Added 
- Fixed typo databricks module and comment
### Changed

## 2023-09-21
### Added 
- Remove databricks random name generator for workspace
### Changed

## 2023-09-01
### Added 
- Added apachesparkpool_module to SynapseWorkspace
### Changed

## 2023-08-30
### Added
### Changed
- Storage account added comment in tags of 3 modules
- Keyvault - make ipRules parameter optional
### Known Issues

## 2023-08-28
### Added
### Changed
- Databricks added required parameters for secure cluster connectivity(PEP and No Public access)
### Known Issues

## 2023-08-09
### Added
### Changed
- CognitiveServices (cognitiveservices.bicep) / Add support for new kinds
### Known Issues

## 2023-06-26
### Added
### Changed
- VirtualMachine - Updated all modules to newest version
### Known Issues

## 2023-06-19
### Added
### Changed
- SqlDatabase (sqldatabasewithspn_module.bicep) / changed VA-config from classic to express
### Known Issues

## 2023-06-09
### Added
- SqlDatabase / sqldb_cfvnetrules_module.bicep - to create CF related vnet rules
### Changed
### Known Issues

## 2023-04-07
### Added
### Changed
- added serverless billing option to the CosmosDB SQL-API modules
### Known Issues

## 2023-03-28
### Added
- added output of static web app id to staticwebapp_module.bicep
### Changed
### Removed
### Known Issues

## 2023-01-25
### Added
- Operations/CallDSM.ps1 added to centralize DSM API Call for different feature example pipelines.
### Changed
### Removed
### Known Issues

## 2023-01-24
### Added
### Changed
- appgw_module.bicep - use of newer API version, added sslPolicy and requestRoutingRules priority
- renamed wafPolicy.bicep to wafPolicy_appgw_module.bicep - added wafPolicy as variable for more flexible input
### Removed
### Known Issues

## 2022-12-14
### Added
### Changed
- LogicApp - fix: set functionsRuntimeScaleMonitoringEnabled to false for LogicApp Standard
### Removed
### Known Issues

## 2022-12-06
### Added
### Changed
- frontdoor - fix endpoint name conflicts with dateTime addition
### Removed
### Known Issues

## 2022-12-06
### Added
- FrontDoorClassic: added a Azure Front Door (Classic) module, because that can still be used for some time
### Removed
### Known Issues

## 2022-12-02
### Added
-     LogicApp: add Azure AD AuthSettingsV2 for Logic App
### Removed
### Known Issues

## 2022-11-30
### Added
-     WebApp: add managed certificate, bind custom domain
### Removed
### Known Issues

## 2022-11-23
### Added
-     Public DNS modules: cname with alias, activate zone, deactivate zone
### Changed
-     asg_module.bicep to newer API version
### Removed
### Known Issues

## 2022-09-19
### Added
-     added identity parameter to staticwebapp_module.bicep
### Changed
### Removed
### Known Issues

## 2022-08-23
### Added
-     provisioningState: 'Paused' parameter to DedicatedSQLPool_module.bicep
### Changed
### Removed
### Known Issues

## 2022-01-26
### Added
### Changed
### Removed
Removed Advanced Threat Protection for incompatible CosmosDB API's 
### Known Issues

## 2022-01-26
### Added
Added modules for Analysis Service and Connection Gateway (for on-premise data gateway)
### Changed
### Removed
### Known Issues

## 2022-01-17
### Added
Added modules for CosmosDB
### Changed
### Removed
### Known Issues

## 2021-12-10
### Added
### Changed
### Removed
- from the following modules, removed the diagnosticSettings (and Log Analytics Workspace) resource and related module parameter;
    * azureml_module.bicep
    * keyvault_module.bicep
    * keyvault_module_no_mi.bicep
    * rediscache_module.bicep
    * relay_module.bicep
    * sqldatabase_module.bicep
    * vnet_module.bicep
    * vnet_module_natgw.bicep
    * vnet_udr_module.bicep
    * webapp_module.bicep
### Known Issues