## Azure Container Apps Bicep Module

The example demonstrating the use of containerapps bicep module in coordination with other resources is available in CCC containerapps feature [Click here](https://dev.azure.com/raboweb/Cloud%20Competence%20Center/_git/ft-containerapps?path=/zexamples)

The parameters used to create containerapps ( and other ) resources can be initialised in the JSON parameter file which inturn can be passed to these BICEP modules. The parameter file should strictly follow the structure as defined in the [parameters](https://dev.azure.com/raboweb/Cloud%20Competence%20Center/_git/ft-containerapps?path=/parameters) folder.
