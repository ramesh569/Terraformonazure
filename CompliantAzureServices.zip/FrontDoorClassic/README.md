## Frontdoor_module (Classic) parameters 
The package versions >= 0.0.154 deploys Azure Front Door Classic (also with <= 0.0.134 with ../Frontdoor/frontdoor_module.bicep).

The following parameters are expected from the pipeline/bicep-template:

| Parameter name | Description | Default/valid value(s)/Examples |
|---|---|--|
| frontDoorName | Name of Azure FrontDoor ||
| frontDoorWafName | Name of Azure FrontDoor Web application Firewall (WAF) ||
| webAppNameWe | Name of the Azure web application running in West Europe ||
| webAppNameNe | Name of the Azure web application running in North Europe ||
| backendpool | Backend pool array |Check frontdoor_module.bicep array declaration|
| frontDoorEnabledState | frontDoorEnabledState is boolean and it is set to true for two backends | true |
| healthProbeEnabledState | healthProbeEnabledState is boolean and it is set to true for checking backend health | true |
| frontDoorWafEnabledState | frontDoorWafEnabledState is boolean and it is set to true to enable waf | true |
| frontDoorWafMode | Waf mode should be Prevention as per frontdoor-H-001 policy | Prevention |

