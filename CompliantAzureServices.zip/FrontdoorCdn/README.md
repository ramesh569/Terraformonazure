## frontodoorcdn_module parameters (new)
From package version 0.0.161 Azure Front Door and CDN are combined into one. 

The following parameters are expected from the pipeline/bicep-template:

| Parameter name | Description | Default/valid value(s)/Examples | type |
|---|---|--|--|
| frontDoorName | Name of Azure Frontdoor || string |
| webAppNameNe | Web app name North Europe || string |
| webAppNameWe | Web app name West Europe || string |
| webAppName | Web app name (in single instance) || string |
| frontDoorSkuName | SKU |Premium_AzureFrontDoor (or Standard_AzureFrontDoor (1))| string |
| frontDoorWafEnabledState | WAF enabled state | true (or false)(2)| bool = true |
| frontDoorWafMode | Specify the frontDoorWafMode to Prevention due to Rabo Frontdoor H-001 policy | Prevention (or Detection) | string|
| customDNSprefix | Specify the name of the Custom DNS prefix (will be part of azure.rabo.cloud) as subzone | '' or value | string |

(1) - Default is Premium_AzureFrontDoor - this will enable managed WAF rule sets Microsoft_BotManagerRuleSet_1.0 and Microsoft_DefaultRuleSet_2.0. Individual rules in those sets can be disabled when needed.

(2) - Default is true; this enables WAF on the Front Door. If you NEED this to be disabled, you can set this to false : please consult with your FLR and Line Manager!!! Also, you can disable specific rules within the policy. Unfortunately not via an ```az cli``` command at this moment.

(3) - If you want the FrontDoor to be reachable on a public fqdn, use the ```customDNSprefix``` with the ```frontdoorcdn_pubdns_module.bicep``` module.