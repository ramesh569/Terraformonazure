## keyvault_module_no_mi parameters

| Parameter name | Description | Default/valid value(s)/Examples |
|---|---|--|
| keyVaultName | Name of KeyVault ||
| location | Location | dynamic formula |
| tenantId | Id of the Tenant where authentication will
take place ||
| skuName | Name of the SKU for the desired KeyVault |standard/premium |
| organisationalGroupId | Object Id (!) of the Organisational Group for which to assign a KeyVault role ||
| keyVaultRole | Id of the role to assign to the supplied managed identity  | default: Key Vault Secrets User, default value='4633458b-17de-408a-b874-0445c86b69e6' |
| ipRules | IP address for the outgoing/browsing ip address for the keyvault | example for pipeline reference in e.g. template.bicep: <pre><json>param ipRules array = [<br> {<br>    value: ipAddresses<br>  }<br>]</json></pre> |
| accessPolicies | Security Settings for the KeyVault')| (extensive) example for pipeline reference in e.g. template.bicep, see ft-keyvault \examples\template.bicep, starting with ```param accessPolicies array = [``` |
| virtualNetworkRules | virtual network rules for KeyVault| (extensive) example for pipeline reference in e.g. template.bicep, see ft-keyvault \examples\template.bicep, starting with ```param virtualNetworkRules array = [```  |

## keyvault_module parameters (with Managed ID, e.g. for SQL Server)

| Parameter name | Description | Default/valid value(s)/Examples |
|---|---|--|
| keyVaultName | Name of KeyVault ||
| location | Location | dynamic formula |
| tenantId | Id of the Tenant where authentication will take place ||
| skuName | Name of the SKU for the desired KeyVault |standard/premium |
| subnetId | Resource Id of the subnet ||
| managedIdentityPrincipalId | Principal Id of the managed identity for which to assign a KeyVault role ||
| keyVaultRole | Id of the role to assign to the supplied managed identity  | default: Key Vault Secrets User, default value='4633458b-17de-408a-b874-0445c86b69e6' |

## keyvault_secret_module parameters

| Parameter name | Description | Default/valid value(s)/Examples |
|---|---|--|
| keyVaultName | Name of KeyVault ||
| keyVaultSecretName | Name of KeyVault Secret ||
| keyVaultSecretValue | Value of KeyVault Secret ||
