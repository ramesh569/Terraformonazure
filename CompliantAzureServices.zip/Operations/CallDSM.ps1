param(
  [parameter(Mandatory=$true, HelpMessage="Path of url for AddOn. Starts with '/api/'.")]
  [ValidateNotNullOrEmpty()]
  [string] $urlPath,
  [parameter(Mandatory=$false, HelpMessage="Resource for url. Default 'https://dsmapi.ep-selfservice.azure.rabo.cloud'.")]
  [string] $urlResource = "https://dsmapi.ep-selfservice.azure.rabo.cloud",
  [parameter(Mandatory=$false, HelpMessage="Method of URL: 'GET', 'POST', 'PUT', 'PATCH', 'DELETE'. Default 'POST'.")]
  [string] $urlMethod = 'POST',
  [parameter(Mandatory=$false, HelpMessage="Groupname of Azure DevOps variables. Default ''.")]
  [string] $variableStartname='',
  [parameter(Mandatory=$false, HelpMessage="Body for url. Start/End with triple quote, escape each double quote.")]
  [string] $jsonBody,
  [parameter(Mandatory=$false, HelpMessage="Specified Json body is raw and do not have to be converted.")]
  [switch] $jsonRaw,
  [parameter(Mandatory=$false, HelpMessage="Azure DevOps variables, comma-separated.")]
  [string] $azdoVariables,
  [parameter(Mandatory=$false, HelpMessage="Azure DevOps variables as secret, comma-separated.")]
  [string] $azdoVariablesSecret,
  [parameter(Mandatory=$false, HelpMessage="Allowed http statuscode. Default ''.")]
  [string] $allowedHttpStatusCode='',
  [parameter(Mandatory=$false, HelpMessage="Allowed, if http eror message matches. Default ''.")]
  [string] $allowedHttpErrorMatchMessage='',
  [parameter(Mandatory=$false, HelpMessage="Do NOT expect a correlation id returned.")]
  [switch] $expectNoCorrelationId,
  [parameter(Mandatory=$false, HelpMessage="Do NOT Wait till job is finished.")]
  [switch] $doNotWaitForFinished,
  [parameter(Mandatory=$false, HelpMessage="Number of seconds to wait before next job status is requested. Default '15'.")]
  [int] $statusInterval= 15,
  [parameter(Mandatory=$false, HelpMessage="Number of retries. Default '9'.")]
  [int] $numberOfRetries= 9,
  [parameter(Mandatory=$false, HelpMessage="Name of variable to save the valid secret. Default 'validSecretCallCmapi'.")]
  [string] $validSecretVariableName = 'validSecretCallCmapi', 
  [parameter(Mandatory=$false, HelpMessage="Overrule token variables.")]
  [switch] $overruleTokenVariables,
  [parameter(Mandatory=$false, HelpMessage="Other tenant id to be used. Default 'env:tenantId'.")]
  [string]$tenantId,
  [parameter(Mandatory=$false, HelpMessage="Other deploy service principal to be used. Default 'env:servicePrincipalId'.")]
  [string]$clientId,
  [parameter(Mandatory=$false, HelpMessage="Other deploy service principal secret to be used. Default 'env:servicePrincipalKey'.")]
  [string]$clientSecret,
  [parameter(Mandatory=$false, HelpMessage="Show some debug output.")]
  [switch] $debugOutput
)

# Version: 3.0.1

##
# Functions

Function GetMsToken {
    <#
      .SYNOPSIS
          Get an authentication token required for interacting with Azure 
    #>
    param(
      [parameter(Mandatory=$true, HelpMessage="A tenant id for Azure AD application.")]
      [ValidateNotNullOrEmpty()]
      [string]$TenantId,
  
      [parameter(Mandatory=$true, HelpMessage="A resource to get token for.")]
      [ValidateNotNullOrEmpty()]
      [string]$Resource,
      [parameter(Mandatory=$true, HelpMessage="A client id for Azure AD application.")]
      [ValidateNotNullOrEmpty()]
      [string]$ClientId,
  
      [parameter(Mandatory=$true, HelpMessage="A secret of the client for Azure AD application.")]
      [ValidateNotNullOrEmpty()]
      [string]$ClientSecret
    )
    $adTokenUrl = "https://login.microsoftonline.com/$TenantId/oauth2/token"
    $adBody = @{
        grant_type    = "client_credentials"
        client_id     = $ClientId
        client_secret = $ClientSecret
        resource      = $Resource
    }

    $VerbosePreference = "SilentlyContinue"
    $response = Invoke-RestMethod -Method 'Post' -Uri $adTokenUrl -ContentType "application/x-www-form-urlencoded" -Body $adBody
    $VerbosePreference = "Continue"

    return $response.access_token
}

Function GetMsTokenRetrySecret {
    <#
      .SYNOPSIS
          Get an authentication token required for interacting with Azure, 
          When it fails and a secret has been saved, retry once again but use the saved secret
    #>
    param(
      [parameter(Mandatory=$true, HelpMessage="A tenant id for Azure AD application.")]
      [ValidateNotNullOrEmpty()]
      [string]$TenantId,
  
      [parameter(Mandatory=$true, HelpMessage="A resource to get token for.")]
      [ValidateNotNullOrEmpty()]
      [string]$Resource,
      [parameter(Mandatory=$true, HelpMessage="A client id for Azure AD application.")]
      [ValidateNotNullOrEmpty()]
      [string]$ClientId,
  
      [parameter(Mandatory=$true, HelpMessage="A secret of the client for Azure AD application.")]
      [ValidateNotNullOrEmpty()]
      [string]$ClientSecret,

      [parameter(Mandatory=$true, HelpMessage="Name of variable to save the valid secret.")]
      [ValidateNotNullOrEmpty()]
      [string]$ValidSecretVariableName
    )
   try {
       $accesstoken = GetMsToken -TenantId $tenantId -Resource $urlResource -ClientId $clientId -ClientSecret $clientSecret
       Write-Host "##vso[task.setvariable variable=$ValidSecretVariableName;issecret=true]$ClientSecret"
       return $accesstoken
   }
   catch {
       $ClientSecret = $env:validSecretCallCmapi
       $ClientSecret2 = [System.Environment]::GetEnvironmentVariable($validSecretVariableName)

       if ($ClientSecret -ne "") {
          Write-Host "Retry with the valid secret last time saved..."
          return GetMsToken -TenantId $tenantId -Resource $urlResource -ClientId $clientId -ClientSecret $clientSecret
       } 

       Write-Error "No valid last time saved secret found..."
   }
}

Function GetAzDoVariables {
    param(
      [hashtable]$VarHash,
      [string]$Resource,
      [string]$CorrelationId,
      [string]$AzDoVariables,
      [bool]$IsSecret,
      [string]$VariableStartname
    )

    if("$AzDoVariables" -match "\S"){
       $urlStatus = '{0}/api/jobs/{1}/getvalues/{2}' -f $Resource,$CorrelationId,$AzDoVariables
       Write-Host "urlStatus $($urlStatus) "
       $getValues = Invoke-RestMethod -Method GET -Headers $headers -Uri $urlStatus

       $AzDoVariables.Split(",") | ForEach {
          if ("$($getValues.output.$_)" -match "\S") {
             $outputVar = "{0}$_" -f $variableStartname
             if ($IsSecret) {
                Write-Host "##vso[task.setvariable variable=$outputVar;issecret=true]$($getValues.output.$_)"
                $VarHash.Add("$outputVar", " ****")
             } else {
                Write-Host "##vso[task.setvariable variable=$outputVar]$($getValues.output.$_)"
                $VarHash.Add("$outputVar", $($getValues.output.$_))
             }
          } else {
             Write-Host "...because variable '$_' is empty its value is not put in Azure DevOps variable '$VariableStartname$_'."
             Write-Host "##vso[task.setvariable variable=$VariableStartname$_] "
		  }
       } 
    }

    return $VarHash
}

Function ShowAndAnalyzeHttpError {
    param(
      [string]$StatusCode,
      [string]$ErrRespString,
      [string]$AllowedHttpStatusCode,
      [string]$AllowedHttpErrorMatchMessage
    )

    if ($AllowedHttpStatusCode -eq "") {
      Write-Error "API call failed with status code $StatusCode. Extra information: $ErrRespString"
    } elseif ($AllowedHttpStatusCode -ne $StatusCode) {
      Write-Error "API call failed with status code $StatusCode (expected status code: $AllowedHttpStatusCode). Extra information: $ErrRespString"
    } elseif ($AllowedHttpErrorMatchMessage -ne "") {
      if ($ErrRespString -match $AllowedHttpErrorMatchMessage) {
          Write-Host "API call ended with expected deviated status code $StatusCode and expected error message: '$ErrRespString'."
      }
      else {
          Write-Error "API call failed with expected deviated status code $StatusCode, but got unexpected error message: '$ErrRespString'."
      }
    } else {
      Write-Host "API call ended with expected deviated status code $StatusCode."
    }
}

# End of Functions
###


if ($variableStartname) {
    $variableStartname += "."
}

if (!$overruleTokenVariables) {
    $accesstoken = az account get-access-token --resource $urlResource | ConvertFrom-Json | select -ExpandProperty accessToken
} else {
    Write-Host "Get token by overruling token variables..."

    if ([string]::IsNullOrEmpty($tenantId)) {
        $tenantId = $env:tenantId
    }
    if ([string]::IsNullOrEmpty($clientId)) {
        $clientId = $env:servicePrincipalId
    }
    if ([string]::IsNullOrEmpty($clientSecret)) {
        $clientSecret = $env:servicePrincipalKey
    }
        
    $accesstoken = GetMsTokenRetrySecret -TenantId $tenantId -Resource $urlResource -ClientId $clientId -ClientSecret $clientSecret -ValidSecretVariableName $validSecretVariableName
}
$url= '{0}{1}' -f $urlResource,$urlPath
$headers = @{
    'Authorization' = 'Bearer ' + $accesstoken
    'Content-Type' = 'application/json'
}

Write-Host "`nnumberOfRetries: $numberOfRetries"
write-Host "azdoVariables to read: $azdoVariables"
write-Host "azdoVariablesSecret to read: $azdoVariablesSecret"

Write-Host "`n`nURL: $url"
Write-Host "METHOD: $urlMethod"

if ($jsonBody) {
    if ($debugOutput) {Write-Host "[DEBUG] body: '$jsonBody'"}
    $body = $jsonBody  | ConvertFrom-Json
    if ($jsonRaw) {
        $body = $jsonBody
    }
    Write-Host "BODY: $body`n"
} else {
    Write-Host "BODY: <no body>`n"
}

if (!$expectNoCorrelationId) {
      
    $statusCode = '200'

    $retryCount = 0
    $retryAction = $true
    $addSleep = 0
    $sleep = $statusInterval
    while ($retryCount -lt 5 -AND $retryAction) {
        $retryCount++
        $retryAction = $false

        try{
            if ($jsonBody) {
                if ($debugOutput) {Write-Host "[DEBUG] -Method $urlMethod -Body $body -Uri $url"}
                $output = Invoke-RestMethod -Method $urlMethod -Headers $headers -Body $body -Uri $url
            } else {
                if ($debugOutput) {Write-Host "[DEBUG] -Method $urlMethod -Uri $url"}
                $output = Invoke-RestMethod -Method $urlMethod -Headers $headers -Uri $url
		    }
        }catch [System.Net.WebException]{
           $errRespString = $_.ErrorDetails.Message
   
           $statusCode = $_.Exception.Response.StatusCode.value__
           if ($null -ne (@('429', '503') | ? { $statusCode -match $_ })) {
                $retryAction = $true
                Write-Host "API is temporarily unavailable...(retry count: $retryCount/5, status code: $statusCode)...retrying after $sleep seconds..."
                sleep $sleep 
                $addSleep += $statusInterval
                $sleep += $addSleep
           } else {
                ShowAndAnalyzeHttpError -StatusCode $statusCode -ErrRespString $errRespString -AllowedHttpStatusCode $allowedHttpStatusCode -AllowedHttpErrorMatchMessage $allowedHttpErrorMatchMessage
           }
        }
    }

    if ((!$output.correlation_id -or $output.value) -and $statusCode -eq '200') {
            $statusCode = '201'
    }

    if ($allowedHttpStatusCode -ne "") {
        if ($allowedHttpStatusCode -ne $statusCode) {
            Write-Error "API call ended with unexpected status code $statusCode (expected status code: $allowedHttpStatusCode)!"
        }
    }

    if ($retryAction) {
        Write-Error "Maximum number of retries has reached! Contact 'EP - Azure Platform' Support if problem reoccurs."
    }

    if ($output.correlation_id -and !$output.value) {
        $outputVar = '{0}CorrelationId' -f $variableStartname
        Write-Host "##vso[task.setvariable variable=$outputVar;]$($output.correlation_id)"
        Write-Host "Correlation id '$($output.correlation_id)' has been put in Azure DevOps variable '$outputVar'."
   
        if (!$doNotWaitForFinished) {
            $jobStatus = $output
            $urlStatus = '{0}/api/jobs/{1}' -f $urlResource,$output.correlation_id

            $initialWait = 10
            Write-Host "`n`nGet Job status: $urlStatus...wait $initialWait seconds..."
            sleep $initialWait

            $sleep = $statusInterval
            $retryCount = 0
            $addSleep = 0
            $totalWait = $initialWait
            while ($retryCount -lt $numberOfRetries -AND !$jobStatus.finished) {
                $retryCount++
                try{
                    $jobStatus = Invoke-RestMethod -Method GET -Headers $headers -Uri $urlStatus
                    if (!$jobStatus.finished) {
                       Write-Host "Job is not finished, yet (retry count: $retryCount/$numberOfRetries)...retrying after $sleep seconds..."

                       sleep $sleep 
                       $totalWait += $sleep
                       $addSleep += $statusInterval
                       $sleep += $addSleep
                    } elseif (!$jobStatus.successful) {
                       Write-Error "Job is finished, but execution has failed! Contact 'EP - Azure Platform' Support if problem reoccurs."

                    }                       
                      else {
                       Write-Host "Job is finished and successfully executed."

                       $varHash = @{}
                       $varHash = GetAzDoVariables -VarHash $varHash -AzDoVariables "$azdoVariables"       -IsSecret $false -Resource $urlResource -CorrelationId $output.correlation_id -VariableStartname $variableStartname 
                       $varHash = GetAzDoVariables -VarHash $varHash -AzDoVariables "$azdoVariablesSecret" -IsSecret $true  -Resource $urlResource -CorrelationId $output.correlation_id -VariableStartname $variableStartname 
                       $varHash | Format-Table
                    }
				} catch [System.Net.WebException]{
                    $statusCode = $_.Exception.Response.StatusCode.value__
                    if ($null -ne (@('403', '404', '422', '429', '503') | ? { $statusCode -match $_ })) {
                       Write-Host "Job status is not received! Returncode: $statusCode (retry count: $retryCount/$numberOfRetries)...retrying after $sleep seconds..."
                       sleep $sleep 
					}  
                    else 
                    {
                       Write-Host "(statuscode: $statusCode)..."  
                       sleep 5
					}

                    $totalWait += $sleep
                    $addSleep += $statusInterval
                    $sleep += $addSleep
				 }
                 
            }
   
            $jobStatus

            if (!$jobStatus.finished) {
               Write-Host "Job has not finished within $totalWait seconds!"
               if ($totalWait -ge 1500) {
                  Write-Error "Contact 'EP - Azure Platform' Support if problem reoccurs."
               } else {
                  Write-Error "Increase the statusInterval time and/or numberOfRetries  and retry."
               }
            }
        }
   
    } else {
        $output
    }
   
} else {
   if ($jsonBody) {
       Invoke-RestMethod -Method $urlMethod -Headers $headers -Body $body -Uri $url
   } else {
       Invoke-RestMethod -Method $urlMethod -Headers $headers -Uri $url
   }
}
 