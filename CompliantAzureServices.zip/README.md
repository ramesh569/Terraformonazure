# Introduction
This project contains Bicep (IaC) templates related to the Rabobank compliant Azure services. More information can be found here: https://confluence.dev.rabobank.nl/display/Azure/FAQ%3A+Bicep+for+Azure+DevOps+pipelines
