sqlmi_module.bicep
------------------

This bicep modules creates a SQL Managed instance resource. 
The example on how to use this module can be found at [ ft-sqlmi ](https://dev.azure.com/raboweb/Cloud%20Competence%20Center/_git/ft-sqlmi?path=/examples/azure-pipelines.yml)


This module also makes use of bicep vnet module vnet_udr_module.bicep

