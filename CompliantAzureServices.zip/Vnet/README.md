This document provides additional information on how to use each individual Bicep module contained within this folder.

vnet_module.bicep
-----------------
The array below is included as an example and may be used as a starting point for describing your own environment w.r.t VNET-subnetting.

    param subnets array = [
        {
            name: 'web'
            addressSpace: '10.0.0.0/24'
            serviceEndpoints: [
            ]
            delegations: [
                {
                    name: 'delegation'
                    properties: {
                        serviceName: 'Microsoft.Web/serverfarms'
                    }
                }
            ]
            privateLinkServiceNetworkPolicies: 'Enabled'
            privateEndpointNetworkPolicies: 'Enabled'
                }
        {
            name: 'data'
            addressSpace: '10.0.1.0/24'
            serviceEndpoints: [
                {
                    service: 'Microsoft.Sql'
                }
            ]
            delegations: [
            ]
            privateLinkServiceNetworkPolicies: 'Enabled'
            privateEndpointNetworkPolicies: 'Disabled'
                }
    ]

-----------------
vnet_udr_module.bicep

A UDR table introduced in the subnet properties.

routeTable:{
           id: udrtable
         }

-----------------

N.B. The above is valid for CompliantAzureServices packages up to 0.0.228. After that, the following feature example can be used: ft-network\examples\Network\ - in there you can find a parameter-file that defines the vnet, subnets to be used and nsg rules that are to be applied on said subnets. You can costomize this example to your needs, by removing/adding subnets and corresponding nsg rules.
