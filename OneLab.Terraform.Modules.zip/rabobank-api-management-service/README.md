<!-- BEGIN_TF_DOCS -->


## CCC alignment
This module follow the CCC security guidelines, as indicated in the link below
- [CCC Resource Overview](https://confluence.dev.rabobank.nl/display/Azure/Quickstarts)

## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >1.10.0 |
| <a name="requirement_azuread"></a> [azuread](#requirement\_azuread) | >= 3.0.0, < 4.0.0 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >= 4.0.1, < 5.0.0 |
| <a name="requirement_null"></a> [null](#requirement\_null) | >= 3.2.1 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azuread"></a> [azuread](#provider\_azuread) | >= 3.0.0, < 4.0.0 |
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | >= 4.0.1, < 5.0.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azuread_application_api_access.msgraph_api_access](https://registry.terraform.io/providers/hashicorp/azuread/latest/docs/resources/application_api_access) | resource |
| [azuread_application_owner.apim_registration_owners](https://registry.terraform.io/providers/hashicorp/azuread/latest/docs/resources/application_owner) | resource |
| [azuread_application_password.client_secret_password](https://registry.terraform.io/providers/hashicorp/azuread/latest/docs/resources/application_password) | resource |
| [azuread_application_redirect_uris.portal_redirect_aad](https://registry.terraform.io/providers/hashicorp/azuread/latest/docs/resources/application_redirect_uris) | resource |
| [azuread_application_registration.apim_registration](https://registry.terraform.io/providers/hashicorp/azuread/latest/docs/resources/application_registration) | resource |
| [azurerm_api_management.apim](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/api_management) | resource |
| [azurerm_api_management_identity_provider_aad.enable_identity_provider](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/api_management_identity_provider_aad) | resource |
| [azurerm_api_management_logger.apim](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/api_management_logger) | resource |
| [azurerm_api_management_product.onelab_api_product](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/api_management_product) | resource |
| [azurerm_api_management_product_group.product_group](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/api_management_product_group) | resource |
| [azurerm_api_management_product_policy.cors](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/api_management_product_policy) | resource |
| [azurerm_public_ip.apim_pip](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/public_ip) | resource |
| [azuread_application_published_app_ids.well_known](https://registry.terraform.io/providers/hashicorp/azuread/latest/docs/data-sources/application_published_app_ids) | data source |
| [azuread_service_principal.msgraph](https://registry.terraform.io/providers/hashicorp/azuread/latest/docs/data-sources/service_principal) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_application_insights_key"></a> [application\_insights\_key](#input\_application\_insights\_key) | n/a | `string` | `"key from application insights resource"` | no |
| <a name="input_extra_tags"></a> [extra\_tags](#input\_extra\_tags) | extra tags for this resource | `map(any)` | n/a | yes |
| <a name="input_lab_variant"></a> [lab\_variant](#input\_lab\_variant) | Variable used to define the lab | `string` | `"onelab"` | no |
| <a name="input_namings"></a> [namings](#input\_namings) | the object of the onelab-standards | `any` | n/a | yes |
| <a name="input_public_network_access_enabled"></a> [public\_network\_access\_enabled](#input\_public\_network\_access\_enabled) | public\_network\_access\_enabled has to be put on true on a first deploy. After that change it back to false and redeploy | `bool` | `true` | no |
| <a name="input_publisher_email"></a> [publisher\_email](#input\_publisher\_email) | The email of publisher/company | `string` | n/a | yes |
| <a name="input_publisher_name"></a> [publisher\_name](#input\_publisher\_name) | The name of publisher/company | `string` | `""` | no |
| <a name="input_resource_group"></a> [resource\_group](#input\_resource\_group) | resource\_group data | `any` | n/a | yes |
| <a name="input_sku_name"></a> [sku\_name](#input\_sku\_name) | value | `string` | `"Developer_1"` | no |
| <a name="input_virtual_network_configuration"></a> [virtual\_network\_configuration](#input\_virtual\_network\_configuration) | virtual network configuration | `list(string)` | n/a | yes |
| <a name="input_virtual_network_type"></a> [virtual\_network\_type](#input\_virtual\_network\_type) | virtual network type | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_apim_obj"></a> [apim\_obj](#output\_apim\_obj) | n/a |

## Calling the module

<details>
<summary>Click to expand</summary>

```hcl
resource "random_id" "rg_name" {
  byte_length = 8
}

resource "random_integer" "rnd_sq" {
  min = 10
  max = 99
}
module "namings" {
  for_each    = toset(var.projects)
  source      = "../../rabobank-onelab-standards"
  bp_code     = var.bp_code
  department  = var.department
  location    = var.location
  project     = each.key
  seq_nr      = random_integer.rnd_sq.result
  environment = var.environment
}

resource "null_resource" "delete_rg" {
  # Resource groups are sometimes not deleted due to errors. This null_resource prevents flaky tests.
  provisioner "local-exec" {
    command    = "az group delete --name 'test-module-apim-${random_id.rg_name.hex}-rg' --subscription '409c506d-38d6-46b8-bd83-301633d8a28d' --yes"
    on_failure = continue
  }
}

resource "azurerm_resource_group" "test" {
  name       = "test-module-apim-${random_id.rg_name.hex}-rg"
  location   = module.namings["apizone"].location
  tags       = merge(module.namings["apizone"].default_tags, local.extra_tags)
  depends_on = [null_resource.delete_rg]
}

module "test_network" {
  source              = "../../rabobank-networking"
  resource_group      = azurerm_resource_group.test
  namings             = module.namings["apizone"]
  vnet_address_spaces = local.vnet_address_spaces
  subnets             = local.subnets
  extra_routes        = local.extra_routes
  extra_tags          = local.extra_tags
}

module "test_log_analytics" {
  source            = "../../rabobank-log-analytics"
  namings           = module.namings["apizone"]
  resource_group    = azurerm_resource_group.test
  retention_in_days = 30 # this is the minimum for testing purposes
  data_source_type  = []
}

resource "azurerm_application_insights" "test_appi" {
  name                = "appi-test-${module.namings["apizone"].base_name}"
  resource_group_name = azurerm_resource_group.test.name
  location            = azurerm_resource_group.test.location
  application_type    = "web"
  retention_in_days   = 30 # this is the minimum for testing purposes
  workspace_id        = module.test_log_analytics.id
}

# TODO: this is commented for now because it doesn't work
# module "test_apim" {
#   source                        = "../../rabobank-api-management-service"
#   namings                       = module.namings["apizone"]
#   resource_group                = azurerm_resource_group.test
#   application_insights_key      = azurerm_application_insights.test_appi.instrumentation_key
#   publisher_email               = "fm.nl.Onelab@rabobank.com"
#   publisher_name                = "Rabobank/OneLab"
#   sku_name                      = "Developer_1"  # Can only be Developer_1 or Premium_x for our use case
#   virtual_network_type          = local.virtual_network_type
#   virtual_network_configuration = [module.test_network.subnets["apim"].id]
#   extra_tags                    = merge(local.extra_tags, local.apim_tags)
# }
```

</details>
<!-- END_TF_DOCS -->