############## Arguments required ##############
# subscriptionID
# resourceGroup
# apimName

if [[ "$#" -eq  "0" ]];then
    echo "No arguments supplied. subcriptionID, resourceGroup and apimName required."
    exit 1
else
    echo $1
    echo $2
    echo $3
fi

timestamp=$(date +%Y%m%d%H%M%S)
apiVersion="2022-08-01"
# Get an Azure access token
token=$(az account get-access-token --query 'accessToken' -o tsv)

# Define the URL for the PUT request
url="https://management.azure.com/subscriptions/$1/resourceGroups/$2/providers/Microsoft.ApiManagement/service/$3/portalRevisions/$timestamp?api-version=$apiVersion"

echo $url
# Define the request body
requestBody='{
    "properties": {
        "description": "portal revision Terraform",
        "isCurrent": true
    }
}'

# Set the API version in the headers
headers="Authorization: Bearer $token"

# Send the PUT request
response=$(curl -X PUT -H "Content-Type: application/json" -H "$headers" -d "$requestBody" "$url")

# Output the response
echo "$response"