<!-- BEGIN_TF_DOCS -->


## CCC alignment
This module follow the CCC security guidelines, as indicated in the link below
- [CCC Resource Overview](https://confluence.dev.rabobank.nl/display/Azure/Quickstarts)

## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >1.10.0 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >= 4.0.1, < 5.0.0 |
| <a name="requirement_random"></a> [random](#requirement\_random) | >= 3.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | >= 4.0.1, < 5.0.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_application_gateway.application_gateway](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/application_gateway) | resource |
| [azurerm_public_ip.agw_pip](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/public_ip) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_backend_address_pools"></a> [backend\_address\_pools](#input\_backend\_address\_pools) | Backend address pools for the Azure Application Gateway | <pre>list(object({<br>    name         = string<br>    fqdns        = optional(list(string))<br>    ip_addresses = optional(list(string))<br>  }))</pre> | n/a | yes |
| <a name="input_backend_http_settings"></a> [backend\_http\_settings](#input\_backend\_http\_settings) | Backend HTTP settings for the Azure Application Gateway | <pre>list(object({<br>    name                  = string<br>    cookie_based_affinity = string<br>    path                  = string<br>    port                  = number<br>    protocol              = string<br>    request_timeout       = number<br>    probe_name            = optional(string)<br>  }))</pre> | n/a | yes |
| <a name="input_extra_tags"></a> [extra\_tags](#input\_extra\_tags) | Additional Tags | `map(string)` | `{}` | no |
| <a name="input_frontend_ports"></a> [frontend\_ports](#input\_frontend\_ports) | Frontend ports for the Azure Application Gateway | `map(number)` | `{}` | no |
| <a name="input_frontend_private_subnet"></a> [frontend\_private\_subnet](#input\_frontend\_private\_subnet) | Frontend Private Subnet ID Configuration of the Application Gateway | `string` | n/a | yes |
| <a name="input_gateway_ip_configuration"></a> [gateway\_ip\_configuration](#input\_gateway\_ip\_configuration) | Gateway IP Configuration of the Application Gateway | `string` | n/a | yes |
| <a name="input_health_probes"></a> [health\_probes](#input\_health\_probes) | Health probes for the Azure Application Gateway | <pre>list(object({<br>    host                = string<br>    interval            = number<br>    name                = string<br>    protocol            = string<br>    path                = string<br>    timeout             = number<br>    unhealthy_threshold = number<br>    match = object({<br>      body        = optional(string)<br>      status_code = list(string)<br>    })<br>  }))</pre> | n/a | yes |
| <a name="input_http_listeners"></a> [http\_listeners](#input\_http\_listeners) | HTTP listeners for the Azure Application Gateway | <pre>list(object({<br>    name                 = string<br>    frontend_ip_name     = string<br>    frontend_port        = string<br>    protocol             = string<br>    ssl_certificate_name = string<br>  }))</pre> | n/a | yes |
| <a name="input_identity_ids"></a> [identity\_ids](#input\_identity\_ids) | Managed Identity ID | `list(string)` | `[]` | no |
| <a name="input_max_capacity"></a> [max\_capacity](#input\_max\_capacity) | Maximum capacity for autoscaling. Accepted values are in the range 2 to 125. | `number` | n/a | yes |
| <a name="input_min_capacity"></a> [min\_capacity](#input\_min\_capacity) | Minimum capacity for autoscaling. Accepted values are in the range 0 to 100. | `number` | `1` | no |
| <a name="input_namings"></a> [namings](#input\_namings) | The object of the onelab-standards | `any` | n/a | yes |
| <a name="input_private_ip_address"></a> [private\_ip\_address](#input\_private\_ip\_address) | Static Private IP address of the Application Gateway | `string` | n/a | yes |
| <a name="input_privatelink_name"></a> [privatelink\_name](#input\_privatelink\_name) | Private link configuration name of the Application Gateway | `string` | `""` | no |
| <a name="input_request_routing_rules"></a> [request\_routing\_rules](#input\_request\_routing\_rules) | Request routing rules for the Azure Application Gateway | <pre>list(object({<br>    name                       = string<br>    rule_type                  = string<br>    url_path_map_name          = optional(string)<br>    http_listener_name         = string<br>    backend_address_pool_name  = string<br>    backend_http_settings_name = string<br>    priority                   = number<br>    rewrite_rule_set_name      = optional(string)<br>  }))</pre> | n/a | yes |
| <a name="input_resource_group"></a> [resource\_group](#input\_resource\_group) | Resource Group | `any` | n/a | yes |
| <a name="input_rewrite_rule_sets"></a> [rewrite\_rule\_sets](#input\_rewrite\_rule\_sets) | Creates a Rewrite Rule set and then the rules inside it | <pre>list(object({<br>    name = string<br>    # since a policy can contain either a condition or a most_recent_versions<br>    # block, these fields are all marked as `optional`<br>    rewrite_rules = list(object({<br>      name          = string<br>      rule_sequence = number<br><br>      condition = optional(list(object({<br>        variable    = string<br>        pattern     = string<br>        ignore_case = optional(bool)<br>        negate      = optional(bool)<br>      })))<br><br>      request_header_configuration = optional(list(object({<br>        header_name  = string<br>        header_value = string<br>      })))<br><br>      response_header_configuration = optional(list(object({<br>        header_name  = string<br>        header_value = string<br>      })))<br><br>      url = optional(list(object({<br>        path         = optional(string)<br>        query_string = optional(string)<br>        components   = optional(string)<br>        reroute      = optional(string)<br>      })))<br><br>    }))<br><br><br>  }))</pre> | n/a | yes |
| <a name="input_ssl_certificates"></a> [ssl\_certificates](#input\_ssl\_certificates) | Map of SSL certificates for HTTPS with their names and key vault secret IDs | <pre>map(object({<br>    name                = string # SSL certificate name in the key vault<br>    key_vault_secret_id = string # Secret Identifier of ssl cert stored in key vault<br>  }))</pre> | n/a | yes |
| <a name="input_url_path_map"></a> [url\_path\_map](#input\_url\_path\_map) | Map of SSL certificates for HTTPS with their names and key vault secret IDs | <pre>list(object({<br>    name                                = string<br>    default_backend_address_pool_name   = optional(string)<br>    default_backend_http_settings_name  = optional(string)<br>    default_redirect_configuration_name = optional(string)<br>    default_rewrite_rule_set_name       = optional(string)<br>    path_rule = list(object({<br>      name                        = string<br>      paths                       = list(string)<br>      backend_address_pool_name   = optional(string)<br>      backend_http_settings_name  = optional(string)<br>      redirect_configuration_name = optional(string)<br>      rewrite_rule_set_name       = optional(string)<br>      firewall_policy_id          = optional(string)<br>    }))<br>  }))</pre> | `[]` | no |
| <a name="input_waf_policy_id"></a> [waf\_policy\_id](#input\_waf\_policy\_id) | n/a | `string` | `""` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_application_gateway_id"></a> [application\_gateway\_id](#output\_application\_gateway\_id) | ID of the Azure Application Gateway |
| <a name="output_pip_id"></a> [pip\_id](#output\_pip\_id) | public ipadress app gateway |

## Calling the module

<details>
<summary>Click to expand</summary>

```hcl
provider "azurerm" {
  features {}
}

provider "azurerm" {
  alias                           = "ccc_management"
  resource_provider_registrations = "none"
  subscription_id                 = "f13f81f8-7578-4ca8-83f3-0a845fad3cb5" # sub-prd-global-cccmanagement
  features {}
}

resource "random_id" "rg_name" {
  byte_length = 8
}

resource "random_integer" "rnd_sq" {
  min = 10
  max = 99
}

module "namings" {
  source      = "../../rabobank-onelab-standards"
  bp_code     = var.bp_code
  department  = var.department
  location    = var.location
  project     = var.project
  seq_nr      = random_integer.rnd_sq.result
  environment = var.environment
}

resource "null_resource" "delete_rg" {
  # Resource groups are sometimes not deleted due to errors. This null_resource prevents flaky tests.
  provisioner "local-exec" {
    command    = "az group delete --name 'test-module-agw-${random_id.rg_name.hex}-rg' --subscription '409c506d-38d6-46b8-bd83-301633d8a28d' --yes"
    on_failure = continue
  }
}

resource "azurerm_resource_group" "test" {
  name       = "test-module-agw-${random_id.rg_name.hex}-rg"
  location   = module.namings.location
  tags       = merge(module.namings.default_tags, var.extra_tags)
  depends_on = [null_resource.delete_rg]
}

# Inspiration: https://terraformguru.com/terraform-real-world-on-azure-cloud/31-Azure-Application-Gateway-SSL-SelfSigned-KeyVault/

resource "azurerm_user_assigned_identity" "appgw_msi" {
  name                = "msi-${module.namings.base_name}"
  resource_group_name = azurerm_resource_group.test.name
  location            = module.namings.location
}

resource "azurerm_virtual_network" "agw_vnet" {
  name                = "vnet-agw-${random_id.rg_name.hex}"
  resource_group_name = azurerm_resource_group.test.name
  location            = module.namings.location
  address_space       = var.vnet_address_space
  tags                = merge(module.namings.default_tags, var.extra_tags)
}

resource "azurerm_subnet" "agw_frontend_subnet" {
  name                 = "fe-snet-agw-${random_id.rg_name.hex}"
  resource_group_name  = azurerm_resource_group.test.name
  virtual_network_name = azurerm_virtual_network.agw_vnet.name
  address_prefixes     = var.fe_subnet_prefixes
  service_endpoints    = ["Microsoft.KeyVault"]
}

module "onelab_keyvault" {
  source                  = "../../rabobank-key-vault"
  namings                 = module.namings
  resource_group          = azurerm_resource_group.test
  enable_purge_protection = false
  bypass                  = "AzureServices" # Includes Application Gateway:
  # https://learn.microsoft.com/en-us/azure/key-vault/general/overview-vnet-service-endpoints#trusted-services
  providers = {
    azurerm                = azurerm,
    azurerm.ccc_management = azurerm.ccc_management
  }
}

# You or the build-service full-access to generate a certificate.
resource "azurerm_key_vault_access_policy" "full_access" {
  key_vault_id = module.onelab_keyvault.kv_id
  tenant_id    = data.azurerm_client_config.current.tenant_id
  object_id    = data.azurerm_client_config.current.object_id
  lifecycle {
    create_before_destroy = true
  }
  certificate_permissions = [
    "Backup", "Create", "Delete", "DeleteIssuers", "Get", "GetIssuers", "Import", "List", "ListIssuers", "ManageContacts", "ManageIssuers", "Purge", "Recover", "Restore", "SetIssuers", "Update"
  ]
  key_permissions = [
    "Backup", "Create", "Decrypt", "Delete", "Encrypt", "Get", "Import", "List", "Purge", "Recover", "Restore", "Sign", "UnwrapKey", "Update", "Verify", "WrapKey"
  ]
  secret_permissions = [
    "Backup", "Delete", "Get", "List", "Purge", "Recover", "Restore", "Set"
  ]
  storage_permissions = [
    "Backup", "Delete", "DeleteSAS", "Get", "GetSAS", "List", "ListSAS", "Purge", "Recover", "RegenerateKey", "Restore", "Set", "SetSAS", "Update"
  ]
}

resource "azurerm_key_vault_access_policy" "appag_access" {
  key_vault_id            = module.onelab_keyvault.kv_id
  tenant_id               = data.azurerm_client_config.current.tenant_id
  object_id               = azurerm_user_assigned_identity.appgw_msi.principal_id
  certificate_permissions = ["Get"]
  secret_permissions      = ["Get"]
}

resource "azurerm_key_vault_certificate" "generated" {
  name         = "cert1"
  key_vault_id = module.onelab_keyvault.kv_id
  depends_on   = [azurerm_key_vault_access_policy.full_access]

  certificate_policy {
    issuer_parameters {
      name = "Self"
    }

    key_properties {
      exportable = true
      key_size   = 2048
      key_type   = "RSA"
      reuse_key  = true
    }

    secret_properties {
      content_type = "application/x-pkcs12"
    }

    x509_certificate_properties {
      # Server Authentication = 1.3.6.1.5.5.7.3.1
      # Client Authentication = 1.3.6.1.5.5.7.3.2
      extended_key_usage = ["1.3.6.1.5.5.7.3.1"]

      key_usage = [
        "cRLSign",
        "dataEncipherment",
        "digitalSignature",
        "keyAgreement",
        "keyCertSign",
        "keyEncipherment",
      ]

      subject            = "CN=hello-world"
      validity_in_months = 1
    }
  }
}

module "onelab_waf_policy" {
  source                            = "../../rabobank-waf-policy"
  namings                           = module.namings
  resource_group                    = azurerm_resource_group.test
  policy_file_limit                 = 100
  policy_request_body_check_enabled = true
  policy_max_body_size              = 128
  managed_rule_set                  = var.managed_rule_set
  exclusions                        = var.exclusions
  custom_rules                      = var.custom_rules
}

module "onelab_application_gateway" {
  source                   = "./.."
  namings                  = module.namings
  resource_group           = azurerm_resource_group.test
  gateway_ip_configuration = azurerm_subnet.agw_frontend_subnet.id
  frontend_private_subnet  = azurerm_subnet.agw_frontend_subnet.id
  privatelink_name         = ""
  min_capacity             = var.min_capacity
  max_capacity             = var.max_capacity
  frontend_ports           = var.frontend_ports
  http_listeners           = var.http_listeners
  backend_address_pools    = var.backend_address_pools
  backend_http_settings    = var.backend_http_settings
  request_routing_rules    = var.request_routing_rules
  ssl_certificates = {
    "cert1" = {
      name                = "test1-cert"
      key_vault_secret_id = azurerm_key_vault_certificate.generated.secret_id
    }
  }
  health_probes      = var.health_probes
  identity_ids       = [azurerm_user_assigned_identity.appgw_msi.id]
  private_ip_address = var.private_ip_address
  waf_policy_id      = module.onelab_waf_policy.waf_policy_id
  rewrite_rule_sets  = var.rewrite_rule_sets
}
```

</details>
<!-- END_TF_DOCS -->