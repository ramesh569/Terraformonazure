<!-- BEGIN_TF_DOCS -->

# This module creates a Cognitive Account in Azure
Using this module, you can create various cognitive services by specifying the desired resource kind when calling the module. The available resource kinds include Academic, AnomalyDetector, Bing.Autosuggest, Bing.Autosuggest.v7, Bing.CustomSearch, Bing.Search, Bing.Search.v7, Bing.Speech, Bing.SpellCheck, Bing.SpellCheck.v7, CognitiveServices, ComputerVision, ContentModerator, ContentSafety, CustomSpeech, CustomVision.Prediction, CustomVision.Training, Emotion, Face, FormRecognizer, ImmersiveReader, LUIS, LUIS.Authoring, MetricsAdvisor, OpenAI, Personalizer, QnAMaker, Recommendations, SpeakerRecognition, Speech, SpeechServices, SpeechTranslation, TextAnalytics, TextTranslation, and WebLM. Please note that changing the resource kind will result in the creation of a new resource.

Also, you have the flexibility to specify the SKU based on the supported SKU for each service. The available options include F0, F1, S0, S, S1, S2, S3, S4, S5, S6, P0, P1, P2, E0, and DC0. Choose the SKU that best suits your requirements.


## CCC alignment
This module follow the CCC security guidelines, as indicated in the link below
- [CCC Resource Overview](https://confluence.dev.rabobank.nl/display/Azure/Quickstarts)

## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 1.5.0 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >= 3.68.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | >= 3.68.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_search_service.search_service](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/search_service) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_extra_tags"></a> [extra\_tags](#input\_extra\_tags) | n/a | `map(any)` | n/a | yes |
| <a name="input_namings"></a> [namings](#input\_namings) | the object of the onelab-standards | `any` | n/a | yes |
| <a name="input_resource_group"></a> [resource\_group](#input\_resource\_group) | resource\_group data | `any` | n/a | yes |
| <a name="cognitive_account_configuration"></a> [cognitive\_account\_configuration](#input\cognitive\_account\_configuration) | cognitive\_account\_configuration data | `any` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_id"></a> [id](#output\_id) | n/a |
| <a name="output_search_service"></a> [search\_service](#output\_search\_service) | n/a |

## Calling the module

<details>
<summary>Click to expand</summary>

```hcl
provider "azurerm" {
  features {}
  storage_use_azuread = true
}


resource "random_id" "rg_name" {
  byte_length = 8
}

resource "random_integer" "suffix" {
  min = 10
  max = 99
}

module "namings" {
  source      = "../../rabobank-onelab-standards"
  bp_code     = var.bp_code
  department  = var.department
  location    = var.location
  project     = var.project
  seq_nr      = random_integer.suffix.result
  environment = var.environment
}

resource "azurerm_resource_group" "test" {
  name     = "test-module-search-service-${random_id.rg_name.hex}-rg"
  location = "West Europe"

  tags = module.namings.default_tags # Policy: resource group needs certain tags
}

module "onelab_cognitive_account" {
  source         = "../"
  namings        = module.namings
  resource_group = azurerm_resource_group.test
  cognitive_account_configuration = {
    resource_type_prefix               = "di"
    kind                               = "FormRecognizer"
    sku_name                           = "S0"
    outbound_network_access_restricted = false
    public_network_access_enabled      = false
    local_authentication_enabled       = false
    network_acls = {
      default_action = "Deny"
      ip_rules       = ["147.161.173.8"]
      virtual_network_rules = [
        {
          subnet_id                            = "/subscriptions/1dd73a91-5b7e-4b0c-ace3-fca74a7bb9ec/resourceGroups/rg-1labgeneric-01-citrix-dev01/providers/Microsoft.Network/virtualNetworks/vnet-1labgeneric-01-citrix-dev01/subnets/snet-citrix-agents"
          ignore_missing_vnet_service_endpoint = false
        }
      ]
    }
  }
  extra_tags = {}
}

```

</details>
<!-- END_TF_DOCS -->