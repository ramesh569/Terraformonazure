<!-- BEGIN_TF_DOCS -->


## CCC alignment
This module follow the CCC security guidelines, as indicated in the link below
- [CCC Resource Overview](https://confluence.dev.rabobank.nl/display/Azure/Quickstarts)

## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >1.10.0 |
| <a name="requirement_azapi"></a> [azapi](#requirement\_azapi) | >=2.0.0, <3.0.0 |
| <a name="requirement_azuread"></a> [azuread](#requirement\_azuread) | >= 3.0.0, < 4.0.0 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >= 4.0.1, < 5.0.0 |
| <a name="requirement_null"></a> [null](#requirement\_null) | >= 3.2.1 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azapi"></a> [azapi](#provider\_azapi) | >=2.0.0, <3.0.0 |
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | >= 4.0.1, < 5.0.0 |
| <a name="provider_azurerm.ccc_management"></a> [azurerm.ccc\_management](#provider\_azurerm.ccc\_management) | >= 4.0.1, < 5.0.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azapi_update_resource.update_acr_network_rules](https://registry.terraform.io/providers/Azure/azapi/latest/docs/resources/update_resource) | resource |
| [azurerm_container_registry.onelab_container_registry](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/container_registry) | resource |
| [azurerm_private_endpoint.pe_local_development](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_dev_access_from_local"></a> [dev\_access\_from\_local](#input\_dev\_access\_from\_local) | Enable access to dev resources from local development environments (if they're conneted to the Rabo network). | `object({ enabled = bool, current_environment = string })` | <pre>{<br>  "current_environment": "dev",<br>  "enabled": false<br>}</pre> | no |
| <a name="input_environment"></a> [environment](#input\_environment) | Environment where resources are deployed. | `string` | `"dev"` | no |
| <a name="input_extra_tags"></a> [extra\_tags](#input\_extra\_tags) | extra tags for this resource | `map(any)` | `{}` | no |
| <a name="input_namings"></a> [namings](#input\_namings) | the object of the onelab-standards | `any` | n/a | yes |
| <a name="input_network_rule_set"></a> [network\_rule\_set](#input\_network\_rule\_set) | value | `any` | `[]` | no |
| <a name="input_public_network_access_enabled"></a> [public\_network\_access\_enabled](#input\_public\_network\_access\_enabled) | Whether public network access is allowed for the container registry. | `bool` | `true` | no |
| <a name="input_resource_group"></a> [resource\_group](#input\_resource\_group) | resource\_group data | `any` | n/a | yes |
| <a name="input_retention_policy_days"></a> [retention\_policy\_days](#input\_retention\_policy\_days) | The number of days to retain an untagged manifest after which the acr is purged. | `number` | `0` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_acr"></a> [acr](#output\_acr) | acr object |

## Calling the module

<details>
<summary>Click to expand</summary>

```hcl

provider "azurerm" {
  features {}
  storage_use_azuread = true
}

resource "random_id" "rg_name" {
  byte_length = 8
}

resource "random_integer" "suffix" {
  min = 10
  max = 99
}

module "namings" {
  source      = "../../rabobank-onelab-standards"
  bp_code     = var.bp_code
  department  = var.department
  location    = var.location
  project     = var.project
  seq_nr      = "01"
  environment = var.environment
}

resource "null_resource" "delete_rg" {
  # Resource groups are sometimes not deleted due to errors. This null_resource prevents flaky tests.
  provisioner "local-exec" {
    command    = "az group delete --name 'test-module-function-app-${random_id.rg_name.hex}-rg' --subscription '409c506d-38d6-46b8-bd83-301633d8a28d' --yes"
    on_failure = continue
  }
}

resource "azurerm_resource_group" "test" {
  name       = "test-module-function-app-${random_id.rg_name.hex}-rg"
  location   = module.namings.location
  tags       = module.namings.default_tags # Policy: resource group needs certain tags
  depends_on = [null_resource.delete_rg]
}

module "onelab_azure_container_registry" {
  source                = "./.."
  namings               = module.namings
  resource_group        = azurerm_resource_group.test
  network_rule_set      = local.acr_network_rule_set
  retention_policy_days = 0
  dev_access_from_local = var.dev_access_from_local
}
```

</details>
<!-- END_TF_DOCS -->