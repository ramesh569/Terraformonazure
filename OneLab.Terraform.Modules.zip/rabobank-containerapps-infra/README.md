<!-- BEGIN_TF_DOCS -->
# Module: containerapps-infra
Creation of an Azure ContainerApps Environment ([CCC - Azure Container Apps](https://dev.azure.com/raboweb/Cloud%20Competence%20Center/_git/ft-containerapps)).
**Note** it's the Environment, like Kubernetes, not the Apps! App are deployed independently with own ci/cd lifecycle. The azure [official abbreviations](https://learn.microsoft.com/en-us/azure/cloud-adoption-framework/ready/azure-best-practices/resource-abbreviations#containers) is `cae`.

## Description
This module includes:
- Separate resource group, holding the resources, postfixed with `-cae`.
- Azure ContainerApps Environment (CAE)
  - Injected into a Subnet
  - Configured as `Internal`, no public ip, only within the VNet.
  - Type: Workload profiles which requires a smaller subnet
- Sharing an existing LogAnalytics workspace.

## TODO
Things this module should have as follow up after first version:
- An AppRegistration with permissions on AADGroup(s) to be able to restrict access to App's

## CCC alignment
This module follow the CCC security guidelines, as indicated in the link below
- [CCC Resource Overview](https://confluence.dev.rabobank.nl/display/Azure/Quickstarts)

## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >1.10.0 |
| <a name="requirement_azapi"></a> [azapi](#requirement\_azapi) | >=2.0.0, <3.0.0 |
| <a name="requirement_azuread"></a> [azuread](#requirement\_azuread) | >= 3.0.0, < 4.0.0 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >= 4.0.1, < 5.0.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azapi"></a> [azapi](#provider\_azapi) | >=2.0.0, <3.0.0 |
| <a name="provider_azuread"></a> [azuread](#provider\_azuread) | >= 3.0.0, < 4.0.0 |
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | >= 4.0.1, < 5.0.0 |
| <a name="provider_azurerm.onelabgen"></a> [azurerm.onelabgen](#provider\_azurerm.onelabgen) | >= 4.0.1, < 5.0.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azapi_resource.ca_environment](https://registry.terraform.io/providers/azure/azapi/latest/docs/resources/resource) | resource |
| [azuread_app_role_assignment.ca-role-assignment](https://registry.terraform.io/providers/hashicorp/azuread/latest/docs/resources/app_role_assignment) | resource |
| [azuread_application.container-app-registration](https://registry.terraform.io/providers/hashicorp/azuread/latest/docs/resources/application) | resource |
| [azuread_application_password.container-app-registration_password](https://registry.terraform.io/providers/hashicorp/azuread/latest/docs/resources/application_password) | resource |
| [azuread_service_principal.container-app-sp](https://registry.terraform.io/providers/hashicorp/azuread/latest/docs/resources/service_principal) | resource |
| [azurerm_container_app_environment_storage.cae_env_storage](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/container_app_environment_storage) | resource |
| [azurerm_private_dns_a_record.cae_private_dns_a_record](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_a_record) | resource |
| [azurerm_private_dns_zone.cae_private_dns](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_zone) | resource |
| [azurerm_private_dns_zone_virtual_network_link.cae_private_dns_link](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_zone_virtual_network_link) | resource |
| [azurerm_resource_group.cae_resource_group](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_storage_account.cae_storage_account](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_account) | resource |
| [azurerm_storage_share.cae_file_share](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_share) | resource |
| [azurerm_user_assigned_identity.cae_managed_identity](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/user_assigned_identity) | resource |
| [azuread_client_config.current](https://registry.terraform.io/providers/hashicorp/azuread/latest/docs/data-sources/client_config) | data source |
| [azuread_groups.groups](https://registry.terraform.io/providers/hashicorp/azuread/latest/docs/data-sources/groups) | data source |
| [azurerm_log_analytics_workspace.law_generic](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/log_analytics_workspace) | data source |
| [azurerm_subscription.current](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/subscription) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_account_replication_type"></a> [account\_replication\_type](#input\_account\_replication\_type) | Replication Types | `string` | `"LRS"` | no |
| <a name="input_account_tier"></a> [account\_tier](#input\_account\_tier) | Tier of storage account | `string` | `"Standard"` | no |
| <a name="input_ad_groups"></a> [ad\_groups](#input\_ad\_groups) | AAD group name of the project developer team | `list(string)` | `[]` | no |
| <a name="input_extra_fw_subnet_ids"></a> [extra\_fw\_subnet\_ids](#input\_extra\_fw\_subnet\_ids) | a list of network subnet ids to add to the firewall | `list(any)` | `[]` | no |
| <a name="input_extra_tags"></a> [extra\_tags](#input\_extra\_tags) | additional tags | `map(string)` | `{}` | no |
| <a name="input_hns_enabled"></a> [hns\_enabled](#input\_hns\_enabled) | Hierchical Namespace | `bool` | `"false"` | no |
| <a name="input_infra_subnet_id"></a> [infra\_subnet\_id](#input\_infra\_subnet\_id) | Subnet in which the containerapps are deployed | `string` | n/a | yes |
| <a name="input_law_name"></a> [law\_name](#input\_law\_name) | One!Lab GenericIT: Central Log Analytics Workspace name | `string` | n/a | yes |
| <a name="input_law_rg"></a> [law\_rg](#input\_law\_rg) | One!Lab GenericIT: Central Log Analytics Workspace resource group name | `string` | n/a | yes |
| <a name="input_namings"></a> [namings](#input\_namings) | the object of the onelab-standards | `any` | n/a | yes |
| <a name="input_settings"></a> [settings](#input\_settings) | Settings from ProjectDefinition | <pre>object({<br>    FileShares = map(object({<br>      Size     = optional(number, 10)<br>      ReadOnly = optional(bool, false)<br>    }))<br>    WorkloadProfiles = map(object({<br>      VmType   = optional(string, "D4")<br>      MinCount = optional(number, 0)<br>      MaxCount = optional(number, 1)<br>    }))<br>  })</pre> | n/a | yes |
| <a name="input_vnet_dns_links"></a> [vnet\_dns\_links](#input\_vnet\_dns\_links) | VNet pairs. Key: name suffix for the uniqueness of the dns-link resource. Value: vnet id. The VNets are linked to the Private DNS zone for resolving the container app domain. | `map(string)` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cae_app_registration_client_id"></a> [cae\_app\_registration\_client\_id](#output\_cae\_app\_registration\_client\_id) | Name of the app registration |
| <a name="output_cae_app_registration_client_secret"></a> [cae\_app\_registration\_client\_secret](#output\_cae\_app\_registration\_client\_secret) | n/a |
| <a name="output_cae_app_registration_object_id"></a> [cae\_app\_registration\_object\_id](#output\_cae\_app\_registration\_object\_id) | App Registration Object ID |
| <a name="output_cae_default_domain"></a> [cae\_default\_domain](#output\_cae\_default\_domain) | Default domain of the ContainerApps Environment |
| <a name="output_cae_dns_name"></a> [cae\_dns\_name](#output\_cae\_dns\_name) | n/a |
| <a name="output_cae_env"></a> [cae\_env](#output\_cae\_env) | Complete containerapp environment object |
| <a name="output_cae_id"></a> [cae\_id](#output\_cae\_id) | Resource ID of the containerapp environemnt |
| <a name="output_cae_identity_client_id"></a> [cae\_identity\_client\_id](#output\_cae\_identity\_client\_id) | Client ID of the user assigned managed identity |
| <a name="output_cae_identity_principal_id"></a> [cae\_identity\_principal\_id](#output\_cae\_identity\_principal\_id) | Principal ID of the user assigned managed identity |
| <a name="output_cae_identity_resource_id"></a> [cae\_identity\_resource\_id](#output\_cae\_identity\_resource\_id) | Resource ID of the user assigned managed identity |
| <a name="output_cae_resource_group"></a> [cae\_resource\_group](#output\_cae\_resource\_group) | ContainerApps environment resource group name |
| <a name="output_cae_spn_object_id"></a> [cae\_spn\_object\_id](#output\_cae\_spn\_object\_id) | Enterprise Application Object ID |

## Calling the module

<details>
<summary>Click to expand</summary>

```hcl
provider "azurerm" {
  features {}
  storage_use_azuread = true
}

## Resolve 403 for local deployement - https://github.com/Azure/terraform-provider-azapi/issues/247
provider "azapi" {
  use_msi = false
  use_cli = true
}

provider "azurerm" {
  alias = "ctx_sub"
  features {}
  subscription_id = "1dd73a91-5b7e-4b0c-ace3-fca74a7bb9ec"
}

provider "azurerm" {
  alias = "onelabgen"
  features {}
  subscription_id = "7bac2383-5f42-4f8e-8aea-ff0201c1d86f"
}

module "namings" {
  source      = "../../rabobank-onelab-standards"
  bp_code     = var.bp_code
  department  = var.department
  location    = var.location
  project     = var.project
  seq_nr      = random_integer.rnd_sq.result
  environment = var.environment
}

resource "random_id" "rg_name" {
  byte_length = 8
}

resource "random_integer" "rnd_sq" {
  min = 10
  max = 99
}

resource "null_resource" "delete_rg" {
  # Resource groups are sometimes not deleted due to errors. This null_resource prevents flaky tests.
  provisioner "local-exec" {
    command    = "az group delete --name 'test-module-container-apps-${random_id.rg_name.hex}-rg' --subscription '409c506d-38d6-46b8-bd83-301633d8a28d' --yes"
    on_failure = continue
  }
}

resource "azurerm_resource_group" "test" {
  name       = "test-module-container-apps-${random_id.rg_name.hex}-rg"
  location   = "West Europe"
  tags       = module.namings.default_tags # Policy: resource group needs certain tags
  depends_on = [null_resource.delete_rg]
}

resource "azurerm_virtual_network" "example" {
  name                = "virtnetname"
  address_space       = ["10.2.0.0/16"]
  location            = azurerm_resource_group.test.location
  resource_group_name = azurerm_resource_group.test.name

  tags = module.namings.default_tags # Policy: vnet needs certain tags
}

resource "azurerm_subnet" "example" {
  name                 = "subnetname"
  resource_group_name  = azurerm_resource_group.test.name
  virtual_network_name = azurerm_virtual_network.example.name
  address_prefixes     = ["10.2.0.0/27"]
  service_endpoints    = ["Microsoft.KeyVault", "Microsoft.Storage"]
  delegation {
    name = "delegation"

    service_delegation {
      name = "Microsoft.App/environments"
    }
  }
}

module "containerapp_env" {
  # Other subscription required for connecting the Private-DNS Zone to Citrix VNet.
  providers = {
    azurerm.ctx_sub   = azurerm.ctx_sub
    azurerm.onelabgen = azurerm.onelabgen
  }
  source  = "./.."
  namings = module.namings
  vnet_dns_links = {
    "example" : azurerm_virtual_network.example.id
  }
  infra_subnet_id = azurerm_subnet.example.id
  ad_groups       = ["eu.res.AADAzureOneLab.us"]
  law_name        = "la-1labgen-01-logmon-${module.namings.environment}01"
  law_rg          = "rg-1labgen-01-logmon-${module.namings.environment}01"
  extra_fw_subnet_ids = [
    # CCC provided Rabobank Self-hosted DevOps agents
    "/subscriptions/0cea37a3-6bdc-43cb-be5f-e6d390b05a3c/resourceGroups/rg-erconnect-Azdo-prd/providers/Microsoft.Network/virtualNetworks/vnet-erconnect-Azdo-prd-we/subnets/snet-workload-Azdo-prd-we"
  ]
  settings = {
    FileShares = {
      "volume1" : {
        Size : 10
      }
    }
    WorkloadProfiles = {
      "myprofile1" : {
        MinCount : 0
        MaxCount : 1
      }
    }
  }
}

```

</details>
<!-- END_TF_DOCS -->