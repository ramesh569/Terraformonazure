<!-- BEGIN_TF_DOCS -->


## CCC alignment
This module follow the CCC security guidelines, as indicated in the link below
- [CCC Resource Overview](https://confluence.dev.rabobank.nl/display/Azure/Quickstarts)

## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >1.10.0 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >= 4.0.1, < 5.0.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | >= 4.0.1, < 5.0.0 |
| <a name="provider_random"></a> [random](#provider\_random) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_cosmosdb_account.cosmos_ru_account](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/cosmosdb_account) | resource |
| [azurerm_mongo_cluster.cosmos_vcore_account](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/mongo_cluster) | resource |
| [random_password.password](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/password) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cosmos_account_configuration"></a> [cosmos\_account\_configuration](#input\_cosmos\_account\_configuration) | the object of the Cosmos account configuration | `any` | n/a | yes |
| <a name="input_extra_tags"></a> [extra\_tags](#input\_extra\_tags) | n/a | `map(any)` | n/a | yes |
| <a name="input_namings"></a> [namings](#input\_namings) | the object of the onelab-standards | `any` | n/a | yes |
| <a name="input_resource_group"></a> [resource\_group](#input\_resource\_group) | resource\_group data | `any` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cosmos_account"></a> [cosmos\_account](#output\_cosmos\_account) | n/a |
| <a name="output_id"></a> [id](#output\_id) | n/a |

## Calling the module

<details>
<summary>Click to expand</summary>

```hcl
provider "azurerm" {
  features {}
  storage_use_azuread = true
  subscription_id     = "409c506d-38d6-46b8-bd83-301633d8a28d"
}
resource "random_id" "rg_name" {
  byte_length = 8
}
resource "random_integer" "suffix" {
  min = 10
  max = 99
}
module "namings" {
  source      = "../../rabobank-onelab-standards"
  bp_code     = var.bp_code
  department  = var.department
  location    = var.location
  project     = var.project
  seq_nr      = random_integer.suffix.result
  environment = var.environment
}
resource "azurerm_resource_group" "test" {
  name     = "test-module-cosmos-account-${random_id.rg_name.hex}-rg"
  location = "West Europe"

  tags = module.namings.default_tags # Policy: resource group needs certain tags
}
module "onelab_cosmosdb_account" {
  source         = "../"
  namings        = module.namings
  resource_group = azurerm_resource_group.test

  cosmos_account_configuration = {
    offer_type                    = "Standard"
    local_authentication_disabled = false
    kind                          = "MongoDB"
    capabilities                  = ["EnableAggregationPipeline", "EnableMongo", "EnableMongoRoleBasedAccessControl", "mongoEnableDocLevelTTL", "MongoDBv3.4"]
    consistency_policy = {
      consistency_level       = "BoundedStaleness"
      max_interval_in_seconds = "300"
      max_staleness_prefix    = "100000"
    }
    virtual_network_rules = {
      Allow_DevOps_Agent_Rule = {
        id = "/subscriptions/0cea37a3-6bdc-43cb-be5f-e6d390b05a3c/resourceGroups/rg-erconnect-Azdo-prd/providers/Microsoft.Network/virtualNetworks/vnet-erconnect-Azdo-prd-we/subnets/snet-workload-Azdo-prd-we"
      }
    }
  }
  extra_tags = {}
}
module "onelab_cosmosdb_database" {
  source = "../sub-modules"
  mongodb_databases = {
    "db1" = {
      name             = "db1"
      cosmosdb_account = module.onelab_cosmosdb_account.cosmos_account
      throughput       = 400
    }
    "db2" = {
      name             = "db2"
      cosmosdb_account = module.onelab_cosmosdb_account.cosmos_account
      throughput       = 400
    }
  }
  mongodb_collections = {
    one = {
      collection_name           = "collection1"
      db_name                   = "db1"
      default_ttl_seconds       = "2592000"
      shard_key                 = "MyShardKey"
      cosmosdb_account          = module.onelab_cosmosdb_account.cosmos_account
      collection_throughout     = 400
      collection_max_throughput = null
      analytical_storage_ttl    = null
      indexes = {
        indexone = {
          mongo_index_keys   = ["_id"]
          mongo_index_unique = true
        }
      }
    },
    two = {
      collection_name           = "collection2"
      db_name                   = "db2"
      default_ttl_seconds       = "2592000"
      shard_key                 = "MyShardKey"
      cosmosdb_account          = module.onelab_cosmosdb_account.cosmos_account
      collection_throughout     = 400
      collection_max_throughput = null
      analytical_storage_ttl    = null
      indexes = {
        indextwo = {
          mongo_index_keys   = ["_id"]
          mongo_index_unique = true
        }
      }
    }
  }
}
```

</details>
<!-- END_TF_DOCS -->