<!-- BEGIN_TF_DOCS -->
# Module: databricks-infra
This module includes:
- Creation of a databricks workspace

# REMINDERS
The local value `public_network_access_enabled`  is set to `true`
This has to be put to `false` as soon as databricks is used with citrix
The current databricks projects uses `true`

For unit testing when a network is created by the networking module:
```hcl
  hub_firewall_ip = null
```  
Otherwise it will add that one as a default route to another subcription to where the CI subscripion has no access

The unit test uses a local token. In the blueprint it has to come from a key vault.

## CCC alignment
This module follow the CCC security guidelines, as indicated in the link below
- [CCC Resource Overview](https://confluence.dev.rabobank.nl/display/Azure/Quickstarts)

## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >1.10.0 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >= 4.0.1, < 5.0.0 |
| <a name="requirement_databricks"></a> [databricks](#requirement\_databricks) | >= 1.5.0, < 2.0.0 |
| <a name="requirement_dns"></a> [dns](#requirement\_dns) | >= 3.2.3 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | >= 4.0.1, < 5.0.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_databricks_access_connector.unity_catalog](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/databricks_access_connector) | resource |
| [azurerm_databricks_workspace.databricks](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/databricks_workspace) | resource |
| [azurerm_private_endpoint.pe](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [azurerm_private_endpoint.private_endpoint](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_create_databricks_pe"></a> [create\_databricks\_pe](#input\_create\_databricks\_pe) | n/a | `bool` | `true` | no |
| <a name="input_databricks_dns_zone_ids"></a> [databricks\_dns\_zone\_ids](#input\_databricks\_dns\_zone\_ids) | a list of dns zone ids to be added to the private endpoint | `list(string)` | `[]` | no |
| <a name="input_default_storage_firewall_enabled"></a> [default\_storage\_firewall\_enabled](#input\_default\_storage\_firewall\_enabled) | Enable Storage Firewall | `bool` | `null` | no |
| <a name="input_extra_tags"></a> [extra\_tags](#input\_extra\_tags) | additional tags | `map(string)` | `{}` | no |
| <a name="input_machine_learning_workspace_id"></a> [machine\_learning\_workspace\_id](#input\_machine\_learning\_workspace\_id) | The ID of a Azure Machine Learning workspace to link with Databricks workspace | `string` | `null` | no |
| <a name="input_namings"></a> [namings](#input\_namings) | the object of the onelab-standards | `any` | n/a | yes |
| <a name="input_network"></a> [network](#input\_network) | network object | `any` | n/a | yes |
| <a name="input_network_security_group_rules_required"></a> [network\_security\_group\_rules\_required](#input\_network\_security\_group\_rules\_required) | Does the data plane (clusters) to control plane communication happen over private link endpoint only or publicly? Possible values AllRules, NoAzureDatabricksRules or NoAzureServiceRules. Required | `string` | `"AllRules"` | no |
| <a name="input_private_endpoint_subnet_id"></a> [private\_endpoint\_subnet\_id](#input\_private\_endpoint\_subnet\_id) | Subnet holding the NIC's for the private endpoint(s). | `string` | `null` | no |
| <a name="input_private_endpoints"></a> [private\_endpoints](#input\_private\_endpoints) | A map of subResourceNames with their Private Endpoint Zone Id | `map(string)` | `{}` | no |
| <a name="input_public_network_access_enabled"></a> [public\_network\_access\_enabled](#input\_public\_network\_access\_enabled) | Allow public access to the workspace | `bool` | `true` | no |
| <a name="input_resource_group"></a> [resource\_group](#input\_resource\_group) | resourcegroup object | `any` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_access_connector"></a> [access\_connector](#output\_access\_connector) | Azure databricks Access Connector Name |
| <a name="output_dbw"></a> [dbw](#output\_dbw) | n/a |
| <a name="output_private_endpoint_ids"></a> [private\_endpoint\_ids](#output\_private\_endpoint\_ids) | n/a |
| <a name="output_workspace_hostname"></a> [workspace\_hostname](#output\_workspace\_hostname) | Azure databricks workspace hostname |
| <a name="output_workspace_name"></a> [workspace\_name](#output\_workspace\_name) | Azure databricks workspacename |

## Calling the module

<details>
<summary>Click to expand</summary>

```hcl
module "namings" {
  source      = "../../rabobank-onelab-standards"
  bp_code     = var.bp_code
  department  = var.department
  location    = var.location
  project     = var.project
  seq_nr      = "01"
  environment = var.environment
}

resource "random_id" "rg_name" {
  byte_length = 8
}

resource "null_resource" "delete_rg" {
  # Resource groups are sometimes not deleted due to errors. This null_resource prevents flaky tests.
  provisioner "local-exec" {
    command    = "az group delete --name 'test-module-databricks-${random_id.rg_name.hex}-rg' --subscription '409c506d-38d6-46b8-bd83-301633d8a28d' --yes"
    on_failure = continue
  }
}

resource "azurerm_resource_group" "test" {
  name       = "test-module-databricks-${random_id.rg_name.hex}-rg"
  location   = "West Europe"
  tags       = module.namings.default_tags # Policy: resource group needs certain tags
  depends_on = [null_resource.delete_rg]
}

resource "azurerm_private_dns_zone" "blob" {
  name                = "privatelink.blob.core.windows.net"
  resource_group_name = azurerm_resource_group.test.name
}

resource "azurerm_private_dns_zone" "dfs" {
  name                = "privatelink.dfs.core.windows.net"
  resource_group_name = azurerm_resource_group.test.name
}
# One!Lab network
module "onelab_network" {
  source             = "../../rabobank-networking"
  resource_group     = azurerm_resource_group.test
  namings            = module.namings
  vnet_address_space = local.vnet_address_space
  subnets            = local.subnets
  extra_routes       = local.routes
  route_to_firewall  = false # unit test
}

resource "azurerm_private_dns_zone" "example" {
  name                = "mydomain.com"
  resource_group_name = azurerm_resource_group.test.name

  tags = module.namings.default_tags # Policy: vnet needs certain tags
}

module "onelab_databricks_workspace" {
  source         = "./.."
  namings        = module.namings
  extra_tags     = var.extra_tags
  resource_group = azurerm_resource_group.test
  network        = module.onelab_network
  private_endpoints = {
    "blob" : azurerm_private_dns_zone.blob.id,
    "dfs" : azurerm_private_dns_zone.dfs.id
  }
  private_endpoint_subnet_id = module.onelab_network.subnets["sn-private-endpoint"].id
}
```

</details>
<!-- END_TF_DOCS -->