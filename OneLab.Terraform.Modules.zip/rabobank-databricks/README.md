<!-- BEGIN_TF_DOCS -->


## CCC alignment
This module follow the CCC security guidelines, as indicated in the link below
- [CCC Resource Overview](https://confluence.dev.rabobank.nl/display/Azure/Quickstarts)

## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >1.10.0 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >= 4.0.1, < 5.0.0 |
| <a name="requirement_databricks"></a> [databricks](#requirement\_databricks) | >= 1.5.0, < 2.0.0 |

## Providers

No providers.

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_onelab_databricks_config"></a> [onelab\_databricks\_config](#module\_onelab\_databricks\_config) | ./submodules/config | n/a |
| <a name="module_onelab_databricks_users"></a> [onelab\_databricks\_users](#module\_onelab\_databricks\_users) | ./submodules/users | n/a |

## Resources

No resources.

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_admin_managed_identity_application_id"></a> [admin\_managed\_identity\_application\_id](#input\_admin\_managed\_identity\_application\_id) | The application id of the admin managed identity used for maintenance. | `string` | n/a | yes |
| <a name="input_data_storage_account_name"></a> [data\_storage\_account\_name](#input\_data\_storage\_account\_name) | The name of the Storage Account that stores the Team's data | `string` | `"nonexistingstorage"` | no |
| <a name="input_databricks_settings"></a> [databricks\_settings](#input\_databricks\_settings) | Specific databricks settings which can be provided in the project yaml file | `map(string)` | `{}` | no |
| <a name="input_databricks_workspace_id"></a> [databricks\_workspace\_id](#input\_databricks\_workspace\_id) | Variable to force dependency on module databricks-infra | `string` | n/a | yes |
| <a name="input_databricks_workspace_url"></a> [databricks\_workspace\_url](#input\_databricks\_workspace\_url) | Hostname of the Databricks Workspace | `string` | n/a | yes |
| <a name="input_dbw_managed_identity_name"></a> [dbw\_managed\_identity\_name](#input\_dbw\_managed\_identity\_name) | The name of the managed identity used for the Databricks workspace. | `string` | `"dbmanagedidentity"` | no |
| <a name="input_dbw_managed_resource_group_name"></a> [dbw\_managed\_resource\_group\_name](#input\_dbw\_managed\_resource\_group\_name) | The resource group name of the Databricks workspace for a specific project. If not specified, the default value will be rg-1lab-md-<PROJECT\_NAME>-<ENVIRONMENT>01-dbw in the submodule using this variable. | `string` | `""` | no |
| <a name="input_environment"></a> [environment](#input\_environment) | environment | `string` | n/a | yes |
| <a name="input_ip_allow_list"></a> [ip\_allow\_list](#input\_ip\_allow\_list) | ip access list for databricks, list of addresses and cidr ranges | `list(string)` | `[]` | no |
| <a name="input_lab_variant"></a> [lab\_variant](#input\_lab\_variant) | Variable used to define the Lab | `string` | `"onelab"` | no |
| <a name="input_personas"></a> [personas](#input\_personas) | map of groups with the associated azure ad group | `map(string)` | n/a | yes |
| <a name="input_project"></a> [project](#input\_project) | projectname | `string` | n/a | yes |
| <a name="input_spark_env_vars"></a> [spark\_env\_vars](#input\_spark\_env\_vars) | n/a | `map(string)` | `{}` | no |
| <a name="input_test_locally"></a> [test\_locally](#input\_test\_locally) | Some resources cannot be deployed locally or in the CI pipeline for the module. Set this to TRUE if you are testing the module locally in test/main.tf. | `bool` | `false` | no |
| <a name="input_unity_enabled"></a> [unity\_enabled](#input\_unity\_enabled) | Set Unity Component on of off / default off | `bool` | `false` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_sql_warehouse_id"></a> [sql\_warehouse\_id](#output\_sql\_warehouse\_id) | Databricks SQL Warehouse ID |

## Calling the module

<details>
<summary>Click to expand</summary>

```hcl
module "namings" {
  source      = "../../rabobank-onelab-standards"
  bp_code     = var.bp_code
  department  = var.department
  location    = var.location
  project     = var.project
  seq_nr      = "01"
  environment = var.environment
}

resource "random_id" "rg_name" {
  byte_length = 8
}

resource "random_integer" "sa_suffix" {
  min = 10
  max = 99
}

resource "null_resource" "delete_rg" {
  # Resource groups are sometimes not deleted due to errors. This null_resource prevents flaky tests.
  provisioner "local-exec" {
    command    = "az group delete --name 'test-module-databricks-${random_id.rg_name.hex}-rg' --subscription '409c506d-38d6-46b8-bd83-301633d8a28d' --yes"
    on_failure = continue
  }
}

resource "azurerm_resource_group" "test" {
  name       = "test-module-databricks-${random_id.rg_name.hex}-rg"
  location   = "West Europe"
  tags       = module.namings.default_tags # Policy: resource group needs certain tags
  depends_on = [null_resource.delete_rg]
}

module "onelab_network" {
  source             = "../../rabobank-networking"
  resource_group     = azurerm_resource_group.test
  namings            = module.namings
  vnet_address_space = local.vnet_address_space
  subnets            = local.subnets
  extra_routes       = local.routes
  route_to_firewall  = false # value null for unit test 
}

# Network from which we connect to private endpoint
resource "azurerm_virtual_network" "example" {
  name                = "virtnetname"
  address_space       = ["10.2.0.0/16"]
  location            = azurerm_resource_group.test.location
  resource_group_name = azurerm_resource_group.test.name

  tags = module.namings.default_tags # Policy: vnet needs certain tags
}

module "onelab_databricks_workspace" {
  source               = "../../rabobank-databricks-infra"
  namings              = module.namings
  extra_tags           = var.extra_tags
  resource_group       = azurerm_resource_group.test
  create_databricks_pe = false
  network              = module.onelab_network
}

resource "azurerm_storage_account" "test" {
  name                      = "databricksmodtest${tostring(random_integer.sa_suffix.result)}"
  resource_group_name       = azurerm_resource_group.test.name
  location                  = azurerm_resource_group.test.location
  account_tier              = "Standard"
  account_replication_type  = "LRS"
  shared_access_key_enabled = true

  # The following settings are hardcoded as these are the only ones allowed by the CCC.
  account_kind = "StorageV2" # H-002
  #https_traffic_only_enabled       = true        # H-003
  allow_nested_items_to_be_public  = false    # H-005
  min_tls_version                  = "TLS1_2" # H-006
  cross_tenant_replication_enabled = false    # H-008

  network_rules {
    default_action             = "Deny" # H-004
    ip_rules                   = []
    virtual_network_subnet_ids = ["/subscriptions/0cea37a3-6bdc-43cb-be5f-e6d390b05a3c/resourceGroups/rg-erconnect-Azdo-prd/providers/Microsoft.Network/virtualNetworks/vnet-erconnect-Azdo-prd-we/subnets/snet-workload-Azdo-prd-we"]
    bypass                     = ["Logging", "Metrics", "AzureServices"]
  }
  tags = {
    Environment = var.environment
  }
  depends_on = [module.onelab_databricks_workspace]
}

resource "azurerm_user_assigned_identity" "test" {
  location            = azurerm_resource_group.test.location
  name                = "test-module-databricks-${random_id.rg_name.hex}-umi"
  resource_group_name = azurerm_resource_group.test.name
}


## This module works locally. If you get an API-related error, use apply again and it should work. 


module "onelab_databricks" {
  providers = {
    databricks = databricks
  }
  source                                = "./.."
  databricks_settings                   = local.databricks_settings
  personas                              = local.personas
  ip_allow_list                         = []
  databricks_workspace_id               = module.onelab_databricks_workspace.dbw.id
  databricks_workspace_url              = module.onelab_databricks_workspace.workspace_hostname
  project                               = var.project
  environment                           = var.environment
  spark_env_vars                        = local.spark_env_vars
  admin_managed_identity_application_id = azurerm_user_assigned_identity.test.client_id
  dbw_managed_resource_group_name       = local.managed_resource_group_name
  dbw_managed_identity_name             = data.azurerm_user_assigned_identity.dbw_identity.name
  test_locally                          = true # Disables some git stuff & local-exec that needs API access (when testing locally and in the CI pipeline)
  depends_on                            = [module.onelab_databricks_workspace]
}
```

</details>
<!-- END_TF_DOCS -->