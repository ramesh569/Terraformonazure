#!/bin/bash

# Auto-install pre-configured requirements.txt, timeout 15 min.
req_file=/dbfs/etc/requirements.txt

if [[ $DB_CLUSTER_NAME = "DevOps Automation" ]]; then
  echo "Skipping installation of '$req_file' on cluster with name: 'DevOps Automation'."
  exit 0
fi

if [ -f $req_file ] ; then
  timeout 900 pip install -r $req_file
else
  mkdir /dbfs/etc
  touch $req_file
fi