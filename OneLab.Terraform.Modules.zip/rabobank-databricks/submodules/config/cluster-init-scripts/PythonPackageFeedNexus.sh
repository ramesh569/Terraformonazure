#!/bin/bash
#
# CHANGELOG:
#   2024-march: Simplify the config using pip cli.
#   2023-July: new default index-url (onelab-pip) in project "One!Lab Support".
#   2024-April: change to nexus repo
#   2024-September: remove extra index url also to nexus repo

( test -z ${NEXUSCLOUD_PYPI_GROUP_REPOSITORY_URL} || test -z ${NEXUSCLOUD_USERNAME} || test -z ${NEXUSCLOUD_PASSWORD} ) && exit 1
clean_url=$(echo ${NEXUSCLOUD_PYPI_GROUP_REPOSITORY_URL}|sed 's/^https:\/\///g')

pip config --global set global.index-url https://${NEXUSCLOUD_USERNAME}:${NEXUSCLOUD_PASSWORD}@${clean_url}simple