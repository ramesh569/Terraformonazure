# Example notebook for mounting teamdata or GDP datasets

# for project teamdata:
container = 'teamdata'    # project container name
stgaccount = 'dls1labmd' + project + env + '01'   #  project storage account

# for GDP dataset (example):
# Collibra - Data Object Delivery Location
#   https://edlcorestdeuprod0001.dfs.core.windows.net/ebx/EBX_RABOCOUNTRYLIST/data/EDL_LOAD_DT=2023-03-06
#          [    stgaccount     ]                  [container]
#
# container = 'ebx'
# stgaccount = 'edlcorestdeuprod0001'

mount_point = '/mnt/' + container
source = 'abfss://' + container + '@' + stgaccount + '.dfs.core.windows.net/'

if mount_point in [mi.mountPoint for mi in dbutils.fs.mounts()]: 
    dbutils.notebook.exit(f"Skipped, already mounted: {mount_point}")

dbutils.fs.mount(
    source = source,
    mount_point = mount_point,
    extra_configs = {
        "fs.azure.account.auth.type": "CustomAccessToken",
        "fs.azure.account.custom.token.provider.class": spark.conf.get("spark.databricks.passthrough.adls.gen2.tokenProviderClassName")
    }
)