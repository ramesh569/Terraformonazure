<!-- BEGIN_TF_DOCS -->


## CCC alignment
This module follow the CCC security guidelines, as indicated in the link below
- [CCC Resource Overview](https://confluence.dev.rabobank.nl/display/Azure/Quickstarts)

## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >1.10.0 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >= 4.0.1, < 5.0.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | >= 4.0.1, < 5.0.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_firewall_policy.firewall_policy](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/firewall_policy) | resource |
| [azurerm_firewall_policy_rule_collection_group.polgroup](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/firewall_policy_rule_collection_group) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_base_policy_id"></a> [base\_policy\_id](#input\_base\_policy\_id) | (Optional) The ID of the base Firewall Policy. | `string` | `null` | no |
| <a name="input_extra_tags"></a> [extra\_tags](#input\_extra\_tags) | additional tags | `map(any)` | `{}` | no |
| <a name="input_firewall_policy_rule_collection_groups"></a> [firewall\_policy\_rule\_collection\_groups](#input\_firewall\_policy\_rule\_collection\_groups) | (Required) Azure Firewall Policy Configuration | `any` | n/a | yes |
| <a name="input_fw_policy_configuration"></a> [fw\_policy\_configuration](#input\_fw\_policy\_configuration) | (Required) Azure Firewall Policy Configuration | `any` | n/a | yes |
| <a name="input_ip_groups"></a> [ip\_groups](#input\_ip\_groups) | (Optional) Specifies a map of source IP groups. | `any` | `{}` | no |
| <a name="input_namings"></a> [namings](#input\_namings) | the object of the onelab-standards | `any` | n/a | yes |
| <a name="input_public_ip_addresses"></a> [public\_ip\_addresses](#input\_public\_ip\_addresses) | (Optional) A map of destination IP addresses (including CIDR). | `any` | `{}` | no |
| <a name="input_resource_group"></a> [resource\_group](#input\_resource\_group) | resource\_group data | `any` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_firewall_policy"></a> [firewall\_policy](#output\_firewall\_policy) | n/a |
| <a name="output_firewall_policy_id"></a> [firewall\_policy\_id](#output\_firewall\_policy\_id) | The ID of the Azure Firewall Polict |
| <a name="output_firewall_policy_names"></a> [firewall\_policy\_names](#output\_firewall\_policy\_names) | n/a |
| <a name="output_rule_collection_group_id"></a> [rule\_collection\_group\_id](#output\_rule\_collection\_group\_id) | The ID of the Firewall Policy Rule Collection Group |

## Calling the module

<details>
<summary>Click to expand</summary>

```hcl
provider "azurerm" {
  features {}
  storage_use_azuread = true
}

module "namings" {
  source      = "../../rabobank-onelab-standards"
  bp_code     = var.bp_code
  department  = var.department
  location    = var.location
  project     = var.project
  seq_nr      = "01"
  environment = var.environment
}

resource "random_id" "rg_name" {
  byte_length = 8
}
resource "random_integer" "suffix" {
  min = 10
  max = 99
}

resource "null_resource" "delete_rg" {
  # Resource groups are sometimes not deleted due to errors. This null_resource prevents flaky tests.
  provisioner "local-exec" {
    command    = "az group delete --name 'test-module-fw-${random_id.rg_name.hex}-rg' --subscription '409c506d-38d6-46b8-bd83-301633d8a28d' --yes"
    on_failure = continue
  }
}

resource "azurerm_resource_group" "test" {
  name       = "test-module-fw-${random_id.rg_name.hex}-rg"
  location   = module.namings.location
  tags       = module.namings.default_tags # Policy: resource group needs certain tags
  depends_on = [null_resource.delete_rg]
}

module "firewall-policies" {
  source                                 = "./.."
  namings                                = module.namings
  resource_group                         = azurerm_resource_group.test
  fw_policy_configuration                = local.fw_policy_configuration
  firewall_policy_rule_collection_groups = local.firewall_policy_rule_collection_groups
}

module "firewall_policies_child" {
  source         = "./.."
  namings        = module.namings
  resource_group = azurerm_resource_group.test
  //base_policy_id                         = module.firewall-policies.firewall_policy_id  // you can enable it in case you want to inherit the other rules
  fw_policy_configuration                = local.child_fw_policy_configuration
  firewall_policy_rule_collection_groups = local.child_firewall_policy_rule_collection_groups
}

resource "time_sleep" "after_azurerm_firewall_policies" {
  count = local.firewall_policy_rule_collection_groups != {} ? 1 : 0
  depends_on = [
    module.firewall-policies,
    module.firewall_policies_child
  ]

  triggers = {
    azurerm_firewall_policy_rule_collection_groups = jsonencode(keys(local.firewall_policy_rule_collection_groups))
  }

  create_duration = "10s"
}
```

</details>
<!-- END_TF_DOCS -->