<!-- BEGIN_TF_DOCS -->


## CCC alignment
This module follow the CCC security guidelines, as indicated in the link below
- [CCC Resource Overview](https://confluence.dev.rabobank.nl/display/Azure/Quickstarts)

## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >1.10.0 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >= 4.0.1, < 5.0.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | >= 4.0.1, < 5.0.0 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_firewall-workbook"></a> [firewall-workbook](#module\_firewall-workbook) | ./submodule/monitoring | n/a |

## Resources

| Name | Type |
|------|------|
| [azurerm_firewall.fw](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/firewall) | resource |
| [azurerm_public_ip.mgmt_public_ip](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/public_ip) | resource |
| [azurerm_public_ip.public_ip](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/public_ip) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_client_config"></a> [client\_config](#input\_client\_config) | n/a | `any` | `{}` | no |
| <a name="input_deploy_monitoring"></a> [deploy\_monitoring](#input\_deploy\_monitoring) | Deploy Azure Workbook Log in log analytics workspace. [GitHub Azure](https://github.com/Azure/Azure-Network-Security/tree/master/Azure%20Firewall/Workbook%20-%20Azure%20Firewall%20Monitor%20Workbook) | `bool` | `true` | no |
| <a name="input_extra_tags"></a> [extra\_tags](#input\_extra\_tags) | additional tags | `map(any)` | `{}` | no |
| <a name="input_firewall_configuration"></a> [firewall\_configuration](#input\_firewall\_configuration) | Firewall configuration settings. | `any` | `{}` | no |
| <a name="input_firewall_policy_id"></a> [firewall\_policy\_id](#input\_firewall\_policy\_id) | Linked Firewall Policy | `any` | `null` | no |
| <a name="input_mgmt_subnet_id"></a> [mgmt\_subnet\_id](#input\_mgmt\_subnet\_id) | (Optional) ID for the Management subnet where to deploy the Azure Firewall | `any` | `""` | no |
| <a name="input_namings"></a> [namings](#input\_namings) | the object of the onelab-standards | `any` | n/a | yes |
| <a name="input_resource_group"></a> [resource\_group](#input\_resource\_group) | resource\_group data | `any` | n/a | yes |
| <a name="input_subnet_id"></a> [subnet\_id](#input\_subnet\_id) | (Required) ID for the subnet where to deploy the Azure Firewall | `any` | `""` | no |
| <a name="input_virtual_hubs"></a> [virtual\_hubs](#input\_virtual\_hubs) | Map containing details about Virtual Hub resources. Key is resource group name | `any` | `{}` | no |
| <a name="input_virtual_wans"></a> [virtual\_wans](#input\_virtual\_wans) | List of virtual WANs and their associated hubs. | `any` | `{}` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_firewall"></a> [firewall](#output\_firewall) | Created Azure firewall |
| <a name="output_id"></a> [id](#output\_id) | The ID of the Azure Firewall. |
| <a name="output_name"></a> [name](#output\_name) | Name of the firewall |

## Calling the module

<details>
<summary>Click to expand</summary>

```hcl
provider "azurerm" {
  features {}
  storage_use_azuread = true
}

resource "random_id" "rg_name" {
  byte_length = 8
}

resource "random_integer" "suffix" {
  min = 10
  max = 99
}

module "namings" {
  source      = "../../rabobank-onelab-standards"
  bp_code     = var.bp_code
  department  = var.department
  location    = var.location
  project     = var.project
  seq_nr      = random_integer.suffix.result
  environment = var.environment
}

resource "null_resource" "delete_rg" {
  # Resource groups are sometimes not deleted due to errors. This null_resource prevents flaky tests.
  provisioner "local-exec" {
    command    = "az group delete --name 'test-module-firewall-${random_id.rg_name.hex}-rg' --subscription '409c506d-38d6-46b8-bd83-301633d8a28d' --yes"
    on_failure = continue
  }
}

resource "azurerm_resource_group" "test" {
  name       = "test-module-firewall-${random_id.rg_name.hex}-rg"
  location   = module.namings.location
  tags       = module.namings.default_tags
  depends_on = [null_resource.delete_rg]
}

resource "azurerm_virtual_network" "example" {
  name                = "vnet-firewall"
  address_space       = ["10.2.0.0/16"]
  location            = azurerm_resource_group.test.location
  resource_group_name = azurerm_resource_group.test.name

  tags = module.namings.default_tags # Policy: vnet needs certain tags
}

resource "azurerm_subnet" "firewall_mgmt_subnet" {
  name                 = "AzureFirewallManagementSubnet"
  resource_group_name  = azurerm_resource_group.test.name
  virtual_network_name = azurerm_virtual_network.example.name
  address_prefixes     = ["10.2.1.0/24"]
}

resource "azurerm_subnet" "firewall_subnet" {
  name                 = "AzureFirewallSubnet"
  resource_group_name  = azurerm_resource_group.test.name
  virtual_network_name = azurerm_virtual_network.example.name
  address_prefixes     = ["10.2.0.0/24"]
}

resource "azurerm_route_table" "rtable" {
  name                          = "route-table"
  location                      = azurerm_resource_group.test.location
  resource_group_name           = azurerm_resource_group.test.name
  bgp_route_propagation_enabled = false # Required for 'AzureFirewallSubnet'.
}

resource "azurerm_route" "default" {
  resource_group_name = azurerm_resource_group.test.name
  route_table_name    = azurerm_route_table.rtable.name
  name                = "DefaultToInternet"
  address_prefix      = "0.0.0.0/0"
  next_hop_type       = "Internet"
}

resource "azurerm_subnet_route_table_association" "rtable_fw" {
  subnet_id      = azurerm_subnet.firewall_subnet.id
  route_table_id = azurerm_route_table.rtable.id
}

resource "azurerm_subnet_route_table_association" "rtable_fw_mgnt" {
  subnet_id      = azurerm_subnet.firewall_mgmt_subnet.id
  route_table_id = azurerm_route_table.rtable.id
}

module "onelab_firewall" {
  source                 = "./.."
  namings                = module.namings
  resource_group         = azurerm_resource_group.test
  firewall_configuration = var.firewall_configuration
  firewall_policy_id     = try(var.firewall_policy_id, null)
  subnet_id              = azurerm_subnet.firewall_subnet.id
  mgmt_subnet_id         = azurerm_subnet.firewall_mgmt_subnet.id
  deploy_monitoring      = false
}
```

</details>
<!-- END_TF_DOCS -->