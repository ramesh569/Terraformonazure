<!-- BEGIN_TF_DOCS -->


## CCC alignment
This module follow the CCC security guidelines, as indicated in the link below
- [CCC Resource Overview](https://confluence.dev.rabobank.nl/display/Azure/Quickstarts)

## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >1.10.0 |
| <a name="requirement_azapi"></a> [azapi](#requirement\_azapi) | >=2.0.0, <3.0.0 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >= 4.0.1, < 5.0.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azuread"></a> [azuread](#provider\_azuread) | n/a |
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | >= 4.0.1, < 5.0.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azuread_app_role_assignment.onelabusers](https://registry.terraform.io/providers/hashicorp/azuread/latest/docs/resources/app_role_assignment) | resource |
| [azuread_application.linux-function-app-registration](https://registry.terraform.io/providers/hashicorp/azuread/latest/docs/resources/application) | resource |
| [azuread_application_api_access.microsoft_graph](https://registry.terraform.io/providers/hashicorp/azuread/latest/docs/resources/application_api_access) | resource |
| [azuread_service_principal.linux-fa-sp](https://registry.terraform.io/providers/hashicorp/azuread/latest/docs/resources/service_principal) | resource |
| [azurerm_linux_function_app.app](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/linux_function_app) | resource |
| [azuread_application_published_app_ids.well_known](https://registry.terraform.io/providers/hashicorp/azuread/latest/docs/data-sources/application_published_app_ids) | data source |
| [azuread_client_config.current](https://registry.terraform.io/providers/hashicorp/azuread/latest/docs/data-sources/client_config) | data source |
| [azuread_group.assignedUserGroups](https://registry.terraform.io/providers/hashicorp/azuread/latest/docs/data-sources/group) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_acrUseMI"></a> [acrUseMI](#input\_acrUseMI) | Use Managed Identity to authenticate with ACR | `bool` | `false` | no |
| <a name="input_allowed_subnet_ids"></a> [allowed\_subnet\_ids](#input\_allowed\_subnet\_ids) | list of allowed subnets for functionapp | `list(string)` | `[]` | no |
| <a name="input_always_on"></a> [always\_on](#input\_always\_on) | Determines whether the function app is always running | `bool` | `true` | no |
| <a name="input_api_management_api_id"></a> [api\_management\_api\_id](#input\_api\_management\_api\_id) | n/a | `string` | `null` | no |
| <a name="input_app_settings"></a> [app\_settings](#input\_app\_settings) | app settings | `map(any)` | `{}` | no |
| <a name="input_application_insights_connection_string"></a> [application\_insights\_connection\_string](#input\_application\_insights\_connection\_string) | n/a | `string` | `null` | no |
| <a name="input_application_insights_key"></a> [application\_insights\_key](#input\_application\_insights\_key) | n/a | `string` | `null` | no |
| <a name="input_backend_storage_account"></a> [backend\_storage\_account](#input\_backend\_storage\_account) | The backend storage account name which will be used by this Function App | `any` | n/a | yes |
| <a name="input_custom_domain_callback"></a> [custom\_domain\_callback](#input\_custom\_domain\_callback) | Custom domain callback for login | `string` | `null` | no |
| <a name="input_docker_image_name"></a> [docker\_image\_name](#input\_docker\_image\_name) | Docker image that is being used by the web app. | `string` | `null` | no |
| <a name="input_docker_image_tag"></a> [docker\_image\_tag](#input\_docker\_image\_tag) | Docker image tag that is being used by the web app. | `string` | `null` | no |
| <a name="input_docker_registry_password"></a> [docker\_registry\_password](#input\_docker\_registry\_password) | Docker registry password where the above mentioned docker image exists. | `string` | `null` | no |
| <a name="input_docker_registry_url"></a> [docker\_registry\_url](#input\_docker\_registry\_url) | Docker registry where the above mentioned docker image exists. | `string` | `null` | no |
| <a name="input_docker_registry_username"></a> [docker\_registry\_username](#input\_docker\_registry\_username) | Docker registry username where the above mentioned docker image exists. | `string` | `null` | no |
| <a name="input_extra_tags"></a> [extra\_tags](#input\_extra\_tags) | additional tags | `map(any)` | `{}` | no |
| <a name="input_fa_aad_group"></a> [fa\_aad\_group](#input\_fa\_aad\_group) | User group which can login and authenticate with the function app. Defaults to all rabobank employees. | `list(string)` | `[]` | no |
| <a name="input_graph_api_permissions"></a> [graph\_api\_permissions](#input\_graph\_api\_permissions) | Scope ids for graph api permissions | `list(string)` | `[]` | no |
| <a name="input_namings"></a> [namings](#input\_namings) | the object of the onelab-standards | `any` | n/a | yes |
| <a name="input_python_version"></a> [python\_version](#input\_python\_version) | The Python runtime version used by the function app | `string` | `null` | no |
| <a name="input_resource_group"></a> [resource\_group](#input\_resource\_group) | resource\_group data | `any` | n/a | yes |
| <a name="input_service_plan"></a> [service\_plan](#input\_service\_plan) | app service plan | `any` | n/a | yes |
| <a name="input_subnet_id"></a> [subnet\_id](#input\_subnet\_id) | The subnet used for the IP restriction of the function app | `any` | n/a | yes |
| <a name="input_unauthenticated_action"></a> [unauthenticated\_action](#input\_unauthenticated\_action) | The action to take for requests made without authentication. | `string` | `"RedirectToLoginPage"` | no |
| <a name="input_user_identity"></a> [user\_identity](#input\_user\_identity) | Managed Identity | `any` | n/a | yes |
| <a name="input_vnet_route_all_enabled"></a> [vnet\_route\_all\_enabled](#input\_vnet\_route\_all\_enabled) | Should all outbound traffic to have NAT Gateways, Network Security Groups and User Defined Routes applied | `bool` | `false` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_client_id"></a> [client\_id](#output\_client\_id) | client id of function app registered |
| <a name="output_function_app"></a> [function\_app](#output\_function\_app) | The created function app |
| <a name="output_function_app_host_name"></a> [function\_app\_host\_name](#output\_function\_app\_host\_name) | n/a |
| <a name="output_id"></a> [id](#output\_id) | n/a |

## Calling the module

<details>
<summary>Click to expand</summary>

```hcl
provider "azurerm" {
  features {}
  storage_use_azuread = true
}

resource "random_integer" "suffix" {
  min = 10
  max = 99
}

module "namings" {
  source      = "../../rabobank-onelab-standards"
  bp_code     = var.bp_code
  department  = var.department
  location    = var.location
  project     = var.project
  seq_nr      = random_integer.suffix.result
  environment = var.environment
}

resource "random_id" "rg_name" {
  byte_length = 8
}

resource "null_resource" "delete_rg" {
  # Resource groups are sometimes not deleted due to errors. This null_resource prevents flaky tests.
  provisioner "local-exec" {
    command    = "az group delete --name 'test-module-function-app-${random_id.rg_name.hex}-rg' --subscription '409c506d-38d6-46b8-bd83-301633d8a28d' --yes"
    on_failure = continue
  }
}

resource "azurerm_resource_group" "test" {
  name       = "test-module-function-app-${random_id.rg_name.hex}-rg"
  location   = module.namings.location
  tags       = module.namings.default_tags # Policy: resource group needs certain tags
  depends_on = [null_resource.delete_rg]
}

module "service-plan" {
  source                 = "../../rabobank-service-plan"
  namings                = module.namings
  resource_group         = azurerm_resource_group.test
  zone_balancing_enabled = var.zonebalancingenabled
  sku                    = var.sku
}

resource "azurerm_storage_account" "unittest" {
  name                     = "stfunapptmpstg${tostring(random_integer.suffix.result)}"
  resource_group_name      = azurerm_resource_group.test.name
  location                 = azurerm_resource_group.test.location
  account_tier             = "Standard"
  account_replication_type = "LRS"

  shared_access_key_enabled = false

  # The following settings are hardcoded as these are the only ones allowed by the CCC.
  account_kind                     = "StorageV2" # H-002
  https_traffic_only_enabled       = true        # H-003
  allow_nested_items_to_be_public  = false       # H-005
  min_tls_version                  = "TLS1_2"    # H-006
  cross_tenant_replication_enabled = false       # H-008

  network_rules {
    default_action             = "Deny" # H-004
    ip_rules                   = []
    virtual_network_subnet_ids = ["/subscriptions/0cea37a3-6bdc-43cb-be5f-e6d390b05a3c/resourceGroups/rg-erconnect-Azdo-prd/providers/Microsoft.Network/virtualNetworks/vnet-erconnect-Azdo-prd-we/subnets/snet-workload-Azdo-prd-we"]
    bypass                     = ["Logging", "Metrics", "AzureServices"]
  }

  tags = {
    Environment = var.environment
  }
}

resource "azurerm_virtual_network" "example" {
  name                = "virtnetname"
  address_space       = ["10.2.0.0/16"]
  location            = azurerm_resource_group.test.location
  resource_group_name = azurerm_resource_group.test.name

  tags = module.namings.default_tags # Policy: vnet needs certain tags
}

resource "azurerm_subnet" "example" {
  name                 = "subnetname"
  resource_group_name  = azurerm_resource_group.test.name
  virtual_network_name = azurerm_virtual_network.example.name
  address_prefixes     = ["10.2.0.0/24"]
  service_endpoints    = ["Microsoft.Sql", "Microsoft.Storage"]
  delegation {
    name = "app-service-plan"

    service_delegation {
      name    = "Microsoft.Web/serverFarms"
      actions = ["Microsoft.Network/virtualNetworks/subnets/action"]
    }
  }
}

resource "azurerm_user_assigned_identity" "test" {
  location            = azurerm_resource_group.test.location
  name                = "test-module-function-app-${random_id.rg_name.hex}-umi"
  resource_group_name = azurerm_resource_group.test.name
}

module "function_app" {
  source                  = "./.."
  namings                 = module.namings
  resource_group          = azurerm_resource_group.test
  backend_storage_account = azurerm_storage_account.unittest
  service_plan            = module.service-plan.azure_service_plan
  vnet_route_all_enabled  = true
  subnet_id               = azurerm_subnet.example.id
  python_version          = var.python_version
  always_on               = true
  app_settings            = local.app_settings
  user_identity           = azurerm_user_assigned_identity.test
}
```

</details>
<!-- END_TF_DOCS -->