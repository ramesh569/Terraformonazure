<!-- BEGIN_TF_DOCS -->


## CCC alignment
This module follow the CCC security guidelines, as indicated in the link below
- [CCC Resource Overview](https://confluence.dev.rabobank.nl/display/Azure/Quickstarts)

## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >1.10.0 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >= 4.0.1, < 5.0.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | >= 4.0.1, < 5.0.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_app_service_certificate.app_service_certificate](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/app_service_certificate) | resource |
| [azurerm_app_service_custom_hostname_binding.app_service_custom_hostname_binding](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/app_service_custom_hostname_binding) | resource |
| [azurerm_linux_web_app.app_service_linux](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/linux_web_app) | resource |
| [azurerm_windows_web_app.app_service_windows](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/windows_web_app) | resource |
| [azurerm_client_config.current](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/client_config) | data source |
| [azurerm_subscription.current](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/subscription) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_app_serice_plan_id"></a> [app\_serice\_plan\_id](#input\_app\_serice\_plan\_id) | the object of the app service plan | `any` | `null` | no |
| <a name="input_app_service_configuration"></a> [app\_service\_configuration](#input\_app\_service\_configuration) | the object of the app service configuration | `any` | `null` | no |
| <a name="input_extra_tags"></a> [extra\_tags](#input\_extra\_tags) | n/a | `map(any)` | n/a | yes |
| <a name="input_namings"></a> [namings](#input\_namings) | the object of the onelab-standards | `any` | n/a | yes |
| <a name="input_resource_group"></a> [resource\_group](#input\_resource\_group) | resource\_group data | `any` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_webapp"></a> [webapp](#output\_webapp) | Created WebApp |

## Calling the module

<details>
<summary>Click to expand</summary>

```hcl
provider "azurerm" {
  features {}
  storage_use_azuread = true
  subscription_id     = "409c506d-38d6-46b8-bd83-301633d8a28d"
}
resource "random_id" "rg_name" {
  byte_length = 8
}
resource "random_integer" "suffix" {
  min = 10
  max = 99
}
module "namings" {
  source      = "../../rabobank-onelab-standards"
  bp_code     = var.bp_code
  department  = var.department
  location    = var.location
  project     = var.project
  seq_nr      = random_integer.suffix.result
  environment = var.environment
}
resource "azurerm_resource_group" "test" {
  name     = "test-module-webapp-${random_id.rg_name.hex}-rg"
  location = "West Europe"

  tags = module.namings.default_tags # Policy: resource group needs certain tags
}

########

resource "azurerm_virtual_network" "example" {
  name                = "vnet-appsvc-${random_id.rg_name.hex}"
  address_space       = ["10.2.0.0/16"]
  location            = azurerm_resource_group.test.location
  resource_group_name = azurerm_resource_group.test.name

  tags = module.namings.default_tags # Policy: vnet needs certain tags
}

resource "azurerm_subnet" "example" {
  name                 = "subnetname"
  resource_group_name  = azurerm_resource_group.test.name
  virtual_network_name = azurerm_virtual_network.example.name
  address_prefixes     = ["10.2.0.0/24"]
  delegation {
    name = "app-service-plan"

    service_delegation {
      name    = "Microsoft.Web/serverFarms"
      actions = ["Microsoft.Network/virtualNetworks/subnets/action"]
    }
  }
}

module "onelab-service-plan" {
  source                 = "../../rabobank-service-plan"
  namings                = module.namings
  resource_group         = azurerm_resource_group.test
  ostype                 = "Linux"
  zone_balancing_enabled = false
  sku                    = "P1v2"
}
module "onelab-windows-service-plan" {
  source                 = "../../rabobank-service-plan"
  asp_name               = "asp-win-${module.namings.base_name}"
  namings                = module.namings
  resource_group         = azurerm_resource_group.test
  ostype                 = "Windows"
  zone_balancing_enabled = false
  sku                    = "P1v2"
}
module "onelab_appservice" {
  source         = "../"
  namings        = module.namings
  resource_group = azurerm_resource_group.test

  app_service_configuration = {
    os_type                                = "Linux"
    name                                   = "app${random_integer.suffix.result}-example-app-service"
    service_plan_id                        = module.onelab-service-plan.serviceplan_id
    public_network_access_enabled          = true
    app_service_vnet_integration_subnet_id = azurerm_subnet.example.id
    app_settings = {
      "WEBSITE_RUN_FROM_PACKAGE" = "1"
      "WEBSITE_TIME_ZONE"        = "W. Europe Standard Time"
    }
    site_config = {
      application_stack = {
        python_version = "3.12"
      }
      cors = {
        allowed_origins     = ["*"]
        support_credentials = false
      }
    }
    authorized_subnet_ids     = [azurerm_subnet.example.id]
    scm_authorized_subnet_ids = [azurerm_subnet.example.id, "/subscriptions/0cea37a3-6bdc-43cb-be5f-e6d390b05a3c/resourceGroups/rg-erconnect-Azdo-prd/providers/Microsoft.Network/virtualNetworks/vnet-erconnect-Azdo-prd-we/subnets/snet-workload-Azdo-prd-we"]
  }
  extra_tags = {}
}

module "onelab_windows_appservice" {
  source         = "../"
  namings        = module.namings
  resource_group = azurerm_resource_group.test

  app_service_configuration = {
    os_type                                = "Windows"
    name                                   = "app${random_integer.suffix.result}-win-example-app-service"
    service_plan_id                        = module.onelab-windows-service-plan.serviceplan_id
    public_network_access_enabled          = true
    app_service_vnet_integration_subnet_id = azurerm_subnet.example.id
    app_settings = {
      "WEBSITE_RUN_FROM_PACKAGE" = "1"
      "WEBSITE_TIME_ZONE"        = "W. Europe Standard Time"
    }
    site_config = {
      application_stack = {
        current_stack  = "dotnet"
        dotnet_version = "v9.0"
      }
    }
    authorized_subnet_ids     = [azurerm_subnet.example.id]
    scm_authorized_subnet_ids = [azurerm_subnet.example.id]
  }
  extra_tags = {}
}
```

</details>
<!-- END_TF_DOCS -->