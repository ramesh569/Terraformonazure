<!-- BEGIN_TF_DOCS -->
# Module: key-vault
This module includes:
- Creation of a Key Vault

## CCC alignment
This module follow the CCC security guidelines, as indicated in the link below
- [CCC Resource Overview](https://confluence.dev.rabobank.nl/display/Azure/Quickstarts)

## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >1.10.0 |
| <a name="requirement_azuread"></a> [azuread](#requirement\_azuread) | >= 3.0.0, < 4.0.0 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >= 4.0.1, < 5.0.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | >= 4.0.1, < 5.0.0 |
| <a name="provider_azurerm.ccc_management"></a> [azurerm.ccc\_management](#provider\_azurerm.ccc\_management) | >= 4.0.1, < 5.0.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_key_vault.key-vault](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault) | resource |
| [azurerm_key_vault_access_policy.kv_ap](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_access_policy) | resource |
| [azurerm_key_vault_secret.kv_secret](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_private_endpoint.pe_local_development](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [azurerm_client_config.current](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/client_config) | data source |
| [azurerm_key_vault_access_policy.all](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/key_vault_access_policy) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_access_rules"></a> [access\_rules](#input\_access\_rules) | A map with Azure AD Object IDs as keys and required Key Vault permissions as values | <pre>map(object({<br>    secret_permissions      = optional(list(string))<br>    key_permissions         = optional(list(string))<br>    storage_permissions     = optional(list(string))<br>    certificate_permissions = optional(list(string))<br>  }))</pre> | `{}` | no |
| <a name="input_bypass"></a> [bypass](#input\_bypass) | Specifies which traffic can bypass the network rules. Possible values are AzureServices and None. | `string` | `"None"` | no |
| <a name="input_dev_access_from_local"></a> [dev\_access\_from\_local](#input\_dev\_access\_from\_local) | Enable access to dev resources from local development environments (if they're conneted to the Rabo network). | `object({ enabled = bool, current_environment = string })` | <pre>{<br>  "current_environment": "dev",<br>  "enabled": false<br>}</pre> | no |
| <a name="input_enable_purge_protection"></a> [enable\_purge\_protection](#input\_enable\_purge\_protection) | Specify whether or not to enable purge protection for the Key Vault that will be created. | `bool` | `true` | no |
| <a name="input_extra_fw_ip_rules"></a> [extra\_fw\_ip\_rules](#input\_extra\_fw\_ip\_rules) | a list of additional ip adresses to add to the firewall | `list(any)` | `[]` | no |
| <a name="input_extra_fw_subnet_ids"></a> [extra\_fw\_subnet\_ids](#input\_extra\_fw\_subnet\_ids) | a list of network subnet ids to add to the firewall | `list(any)` | `[]` | no |
| <a name="input_extra_tags"></a> [extra\_tags](#input\_extra\_tags) | additional tags | `map(any)` | `{}` | no |
| <a name="input_namings"></a> [namings](#input\_namings) | the object of the onelab-standards | `any` | n/a | yes |
| <a name="input_resource_group"></a> [resource\_group](#input\_resource\_group) | Resource Group in which to create the Key Vault. | `any` | n/a | yes |
| <a name="input_secrets"></a> [secrets](#input\_secrets) | secrets that must be added to the keyvault | `map(map(string))` | `{}` | no |
| <a name="input_sku"></a> [sku](#input\_sku) | The Name of the SKU used for this Key Vault. Possible values are standard and premium | `string` | `"premium"` | no |
| <a name="input_soft_delete_retention_days"></a> [soft\_delete\_retention\_days](#input\_soft\_delete\_retention\_days) | The number of days that items should be retained for once soft-deleted. | `number` | `7` | no |
| <a name="input_tenant_id"></a> [tenant\_id](#input\_tenant\_id) | The Azure Active Directory tenant ID that should be used for authenticating requests to the key vault. | `string` | `"6e93a626-8aca-4dc1-9191-ce291b4b75a1"` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_key-vault"></a> [key-vault](#output\_key-vault) | Created key vault |
| <a name="output_kv_id"></a> [kv\_id](#output\_kv\_id) | Key Vault ID |
| <a name="output_name"></a> [name](#output\_name) | Name of the key vault |

## Calling the module

<details>
<summary>Click to expand</summary>

```hcl
provider "azurerm" {
  features {
    key_vault {
      purge_soft_delete_on_destroy    = true
      recover_soft_deleted_key_vaults = true
    }
  }
}

provider "azurerm" {
  alias           = "ccc_management"
  subscription_id = "f13f81f8-7578-4ca8-83f3-0a845fad3cb5" # sub-prd-global-cccmanagement
  features {
    key_vault {
      purge_soft_delete_on_destroy    = true
      recover_soft_deleted_key_vaults = true
    }
  }
  resource_provider_registrations = "none"
}

module "namings" {
  source      = "../../rabobank-onelab-standards"
  bp_code     = var.bp_code
  department  = var.department
  location    = var.location
  project     = var.project
  seq_nr      = tostring(random_integer.kv_suffix.result)
  environment = var.environment
}

resource "random_id" "rg_name" {
  byte_length = 8
}

resource "random_integer" "kv_suffix" {
  min = 10
  max = 99
}

resource "null_resource" "delete_rg" {
  # Resource groups are sometimes not deleted due to errors. This null_resource prevents flaky tests.
  provisioner "local-exec" {
    command    = "az group delete --name 'test-module-key-vault-${random_id.rg_name.hex}-rg' --subscription '409c506d-38d6-46b8-bd83-301633d8a28d' --yes"
    on_failure = continue
  }
}

resource "azurerm_resource_group" "test" {
  name       = "test-module-key-vault-${random_id.rg_name.hex}-rg"
  location   = module.namings.location
  tags       = module.namings.default_tags # Policy: resource group needs certain tags
  depends_on = [null_resource.delete_rg]
}

module "key-vault" {
  source                     = "./.."
  namings                    = module.namings
  resource_group             = azurerm_resource_group.test
  access_rules               = var.access_rules
  secrets                    = var.secrets
  tenant_id                  = var.tenant_id
  soft_delete_retention_days = var.soft_delete_retention_days
  dev_access_from_local      = var.dev_access_from_local
  providers = {
    azurerm                = azurerm
    azurerm.ccc_management = azurerm.ccc_management
  }
}
```

</details>
<!-- END_TF_DOCS -->