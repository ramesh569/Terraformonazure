<!-- BEGIN_TF_DOCS -->


## CCC alignment
This module follow the CCC security guidelines, as indicated in the link below
- [CCC Resource Overview](https://confluence.dev.rabobank.nl/display/Azure/Quickstarts)

## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >1.10.0 |
| <a name="requirement_azuread"></a> [azuread](#requirement\_azuread) | >= 3.0.0, < 4.0.0 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >= 4.0.1, < 5.0.0 |
| <a name="requirement_random"></a> [random](#requirement\_random) | >= 3.6.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azuread"></a> [azuread](#provider\_azuread) | >= 3.0.0, < 4.0.0 |
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | >= 4.0.1, < 5.0.0 |
| <a name="provider_random"></a> [random](#provider\_random) | >= 3.6.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azuread_app_role_assignment.onelabusers](https://registry.terraform.io/providers/hashicorp/azuread/latest/docs/resources/app_role_assignment) | resource |
| [azuread_application.linux-web-app-registration](https://registry.terraform.io/providers/hashicorp/azuread/latest/docs/resources/application) | resource |
| [azuread_application_api_access.microsoft_graph](https://registry.terraform.io/providers/hashicorp/azuread/latest/docs/resources/application_api_access) | resource |
| [azuread_application_password.linux-web-app-registration-secret](https://registry.terraform.io/providers/hashicorp/azuread/latest/docs/resources/application_password) | resource |
| [azuread_service_principal.linux-web-app-sp](https://registry.terraform.io/providers/hashicorp/azuread/latest/docs/resources/service_principal) | resource |
| [azurerm_linux_web_app.linux-web-app](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/linux_web_app) | resource |
| [random_uuid.unique_scopeid](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/uuid) | resource |
| [azuread_application_published_app_ids.well_known](https://registry.terraform.io/providers/hashicorp/azuread/latest/docs/data-sources/application_published_app_ids) | data source |
| [azuread_client_config.current](https://registry.terraform.io/providers/hashicorp/azuread/latest/docs/data-sources/client_config) | data source |
| [azuread_group.assignedUserGroups](https://registry.terraform.io/providers/hashicorp/azuread/latest/docs/data-sources/group) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_acrUseMI"></a> [acrUseMI](#input\_acrUseMI) | Use Managed Identity to authenticate with ACR | `bool` | `false` | no |
| <a name="input_allowed_subnet_ids"></a> [allowed\_subnet\_ids](#input\_allowed\_subnet\_ids) | list of allowed subnets for webapp | `list(string)` | `[]` | no |
| <a name="input_app_settings"></a> [app\_settings](#input\_app\_settings) | A list of key value pairs that will be passed as environment variables to the web app. | `map(any)` | `{}` | no |
| <a name="input_custom_domain_callback"></a> [custom\_domain\_callback](#input\_custom\_domain\_callback) | Custom domain callback for login | `string` | `null` | no |
| <a name="input_docker_image_name"></a> [docker\_image\_name](#input\_docker\_image\_name) | Docker image that is being used by the web app. | `string` | n/a | yes |
| <a name="input_docker_registry_password"></a> [docker\_registry\_password](#input\_docker\_registry\_password) | Docker registry password where the above mentioned docker image exists. | `string` | `null` | no |
| <a name="input_docker_registry_url"></a> [docker\_registry\_url](#input\_docker\_registry\_url) | Docker registry where the above mentioned docker image exists. | `string` | n/a | yes |
| <a name="input_docker_registry_username"></a> [docker\_registry\_username](#input\_docker\_registry\_username) | Docker registry username where the above mentioned docker image exists. | `string` | `null` | no |
| <a name="input_extra_tags"></a> [extra\_tags](#input\_extra\_tags) | Additional Tags | `map(string)` | `{}` | no |
| <a name="input_frontend_backend_api"></a> [frontend\_backend\_api](#input\_frontend\_backend\_api) | Backend API name that is needed for the frontend to point to the backend. | `string` | `null` | no |
| <a name="input_graph_api_permissions"></a> [graph\_api\_permissions](#input\_graph\_api\_permissions) | Scope ids for graph api permissions | `list(string)` | `[]` | no |
| <a name="input_namings"></a> [namings](#input\_namings) | The object of the onelab-standards | `any` | n/a | yes |
| <a name="input_resource_group"></a> [resource\_group](#input\_resource\_group) | Resource Group | `any` | n/a | yes |
| <a name="input_service_plan_id"></a> [service\_plan\_id](#input\_service\_plan\_id) | ID of the App Service Plan that hosts the App Service. | `string` | n/a | yes |
| <a name="input_subnet_id"></a> [subnet\_id](#input\_subnet\_id) | The subnet used for the IP restriction of the function app. | `any` | n/a | yes |
| <a name="input_unauthenticated_action"></a> [unauthenticated\_action](#input\_unauthenticated\_action) | The action to take for requests made without authentication. | `string` | `"RedirectToLoginPage"` | no |
| <a name="input_user_identity"></a> [user\_identity](#input\_user\_identity) | Managed Identity | `any` | n/a | yes |
| <a name="input_webapp_aad_group"></a> [webapp\_aad\_group](#input\_webapp\_aad\_group) | User group which can login and authenticate with the web aap. Defaults to all rabobank employees. | `list(string)` | `[]` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_client_id"></a> [client\_id](#output\_client\_id) | client id of app registered |
| <a name="output_linux_web_app"></a> [linux\_web\_app](#output\_linux\_web\_app) | n/a |

## Calling the module

<details>
<summary>Click to expand</summary>

```hcl
provider "azurerm" {
  features {}
}

module "namings" {
  source      = "../../rabobank-onelab-standards"
  bp_code     = var.bp_code
  department  = var.department
  location    = var.location
  project     = var.project
  seq_nr      = random_integer.rnd_sq.result
  environment = var.environment
}

resource "random_id" "rg_name" {
  byte_length = 8
}

resource "random_integer" "rnd_sq" {
  min = 10
  max = 99
}

resource "null_resource" "delete_rg" {
  # Resource groups are sometimes not deleted due to errors. This null_resource prevents flaky tests.
  provisioner "local-exec" {
    command    = "az group delete --name 'test-module-lwa-${random_id.rg_name.hex}-rg' --subscription '409c506d-38d6-46b8-bd83-301633d8a28d' --yes"
    on_failure = continue
  }
}

resource "azurerm_resource_group" "test" {
  name       = "test-module-lwa-${random_id.rg_name.hex}-rg"
  location   = module.namings.location
  tags       = merge(module.namings.default_tags, var.extra_tags)
  depends_on = [null_resource.delete_rg]
}


resource "azurerm_virtual_network" "example" {
  name                = "virtnetname"
  address_space       = ["10.2.0.0/16"]
  location            = azurerm_resource_group.test.location
  resource_group_name = azurerm_resource_group.test.name

  tags = module.namings.default_tags # Policy: vnet needs certain tags
}

resource "azurerm_subnet" "example" {
  name                 = "subnetname"
  resource_group_name  = azurerm_resource_group.test.name
  virtual_network_name = azurerm_virtual_network.example.name
  address_prefixes     = ["10.2.0.0/24"]
  service_endpoints    = ["Microsoft.Sql", "Microsoft.Storage"]
  delegation {
    name = "app-service-plan"

    service_delegation {
      name    = "Microsoft.Web/serverFarms"
      actions = ["Microsoft.Network/virtualNetworks/subnets/action"]
    }
  }
}

module "onelab-user-identity" {
  source           = "../../rabobank-user-assigned-identity"
  namings          = module.namings
  resource_group   = azurerm_resource_group.test
  role_assignments = [{ role = "Contributor", resource_id = (azurerm_resource_group.test.id) }]
}

module "onelab-service-plan" {
  source                 = "../../rabobank-service-plan"
  namings                = module.namings
  resource_group         = azurerm_resource_group.test
  ostype                 = var.ostype
  zone_balancing_enabled = var.zonebalancingenabled
  sku                    = var.sku
}

module "onelab-linux-web-app" {
  source              = "./.."
  namings             = module.namings
  resource_group      = azurerm_resource_group.test
  service_plan_id     = module.onelab-service-plan.azure_service_plan.id
  docker_image_name   = var.docker_image_name
  docker_registry_url = var.docker_registry_url
  user_identity       = module.onelab-user-identity.user_assigned_identity
  app_settings        = var.app_settings
  subnet_id           = azurerm_subnet.example.id
}
```

</details>
<!-- END_TF_DOCS -->