<!-- BEGIN_TF_DOCS -->
# Module: Log analytics
This module includes:
- Creation of a Log analytics

## CCC alignment
This module follow the CCC security guidelines, as indicated in the link below
- [CCC Resource Overview](https://confluence.dev.rabobank.nl/display/Azure/Quickstarts)

## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >1.10.0 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >= 4.0.1, < 5.0.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | >= 4.0.1, < 5.0.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_log_analytics_linked_storage_account.customLogs](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/log_analytics_linked_storage_account) | resource |
| [azurerm_log_analytics_workspace.log_analytics_workspace](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/log_analytics_workspace) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_allow_resource_only_permissions"></a> [allow\_resource\_only\_permissions](#input\_allow\_resource\_only\_permissions) | Grant users access to resource data they are authorized to view, without giving workspace permission | `bool` | `true` | no |
| <a name="input_data_source_type"></a> [data\_source\_type](#input\_data\_source\_type) | The data source type which should be used for this Log Analytics Linked Storage Account. Possible values are CustomLogs, AzureWatson, Query, Ingestion and Alerts | `list(string)` | <pre>[<br>  "CustomLogs",<br>  "Alerts"<br>]</pre> | no |
| <a name="input_extra_tags"></a> [extra\_tags](#input\_extra\_tags) | additional tags | `map(any)` | `{}` | no |
| <a name="input_internet_ingestion_enabled"></a> [internet\_ingestion\_enabled](#input\_internet\_ingestion\_enabled) | Support querying over the Public Internet | `bool` | `false` | no |
| <a name="input_internet_query_enabled"></a> [internet\_query\_enabled](#input\_internet\_query\_enabled) | Support ingestion over the Public Internet | `bool` | `false` | no |
| <a name="input_local_authentication_disabled"></a> [local\_authentication\_disabled](#input\_local\_authentication\_disabled) | Disable Local Authentication? | `bool` | `true` | no |
| <a name="input_namings"></a> [namings](#input\_namings) | the object of the onelab-standards | `any` | n/a | yes |
| <a name="input_resource_group"></a> [resource\_group](#input\_resource\_group) | resource group data | `any` | n/a | yes |
| <a name="input_retention_in_days"></a> [retention\_in\_days](#input\_retention\_in\_days) | The number of days that items should be retained for once soft-deleted. | `number` | `365` | no |
| <a name="input_sku"></a> [sku](#input\_sku) | The Name of the SKU used for this Log analytics. Possible values are Free, PerGB2018, Standalone, Standard, CapacityReservation and Unlimited | `string` | `"PerGB2018"` | no |
| <a name="input_storage_id"></a> [storage\_id](#input\_storage\_id) | storage account id | `any` | `null` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_id"></a> [id](#output\_id) | Name of the Log analytics |
| <a name="output_log-analytics"></a> [log-analytics](#output\_log-analytics) | Created Log analytics |
| <a name="output_name"></a> [name](#output\_name) | Name of the Log analytics |

## Calling the module

<details>
<summary>Click to expand</summary>

```hcl
provider "azurerm" {
  features {}
  storage_use_azuread = true
}

module "onelab_standards" {
  source      = "../../rabobank-onelab-standards"
  bp_code     = var.bp_code
  department  = var.department
  location    = var.location
  project     = var.project
  seq_nr      = tostring(random_integer.suffix.result)
  environment = var.environment
}

resource "random_id" "rg_name" {
  byte_length = 8
}

resource "random_integer" "suffix" {
  min = 10
  max = 99
}

resource "null_resource" "delete_rg" {
  # Resource groups are sometimes not deleted due to errors. This null_resource prevents flaky tests.
  provisioner "local-exec" {
    command    = "az group delete --name 'test-module-log-analytics-${random_id.rg_name.hex}-rg' --subscription '409c506d-38d6-46b8-bd83-301633d8a28d' --yes"
    on_failure = continue
  }
}

resource "azurerm_resource_group" "test" {
  name       = "test-module-log-analytics-${random_id.rg_name.hex}-rg"
  location   = module.onelab_standards.location
  tags       = module.onelab_standards.default_tags # Policy: resource group needs certain tags
  depends_on = [null_resource.delete_rg]
}

resource "azurerm_storage_account" "sa" {
  name                      = "salogs${tostring(random_integer.suffix.result)}"
  resource_group_name       = azurerm_resource_group.test.name
  location                  = azurerm_resource_group.test.location
  account_tier              = "Standard"
  account_replication_type  = "LRS"
  shared_access_key_enabled = false

  # The following settings are hardcoded as these are the only ones allowed by the CCC.
  account_kind                     = "StorageV2" # H-002
  https_traffic_only_enabled       = true        # H-003
  allow_nested_items_to_be_public  = false       # H-005
  min_tls_version                  = "TLS1_2"    # H-006
  cross_tenant_replication_enabled = false       # H-008

  network_rules {
    default_action             = "Deny" # H-004
    ip_rules                   = []
    virtual_network_subnet_ids = ["/subscriptions/0cea37a3-6bdc-43cb-be5f-e6d390b05a3c/resourceGroups/rg-erconnect-Azdo-prd/providers/Microsoft.Network/virtualNetworks/vnet-erconnect-Azdo-prd-we/subnets/snet-workload-Azdo-prd-we"]
    bypass                     = ["Logging", "Metrics", "AzureServices"]
  }

  tags = module.onelab_standards.default_tags # Policy: storage account needs certain tags
}
module "log-analytics" {
  source = "./.."

  namings           = module.onelab_standards
  resource_group    = azurerm_resource_group.test
  retention_in_days = var.retention_in_days
  extra_tags        = var.extra_tags
  sku               = var.sku
  storage_id        = azurerm_storage_account.sa.id
}
```

</details>
<!-- END_TF_DOCS -->