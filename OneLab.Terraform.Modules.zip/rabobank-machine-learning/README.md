<!-- BEGIN_TF_DOCS -->


## CCC alignment
This module follow the CCC security guidelines, as indicated in the link below
- [CCC Resource Overview](https://confluence.dev.rabobank.nl/display/Azure/Quickstarts)

## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >1.10.0 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >= 4.0.1, < 5.0.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | >= 4.0.1, < 5.0.0 |
| <a name="provider_null"></a> [null](#provider\_null) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_machine_learning_compute_cluster.aml_compute_cluster](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/machine_learning_compute_cluster) | resource |
| [azurerm_machine_learning_compute_instance.aml_compute_instance](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/machine_learning_compute_instance) | resource |
| [azurerm_machine_learning_workspace.ws](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/machine_learning_workspace) | resource |
| [azurerm_private_endpoint.aml_private_endpoint](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [null_resource.always_run](https://registry.terraform.io/providers/hashicorp/null/latest/docs/resources/resource) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_aml_compute_clusters"></a> [aml\_compute\_clusters](#input\_aml\_compute\_clusters) | Map of AML compute clusters | `any` | n/a | yes |
| <a name="input_aml_compute_instances"></a> [aml\_compute\_instances](#input\_aml\_compute\_instances) | n/a | `any` | `[]` | no |
| <a name="input_aml_private_endpoints"></a> [aml\_private\_endpoints](#input\_aml\_private\_endpoints) | n/a | `any` | `[]` | no |
| <a name="input_aml_workspace_configuration"></a> [aml\_workspace\_configuration](#input\_aml\_workspace\_configuration) | Configuration object for the machine learning workspace. | `any` | n/a | yes |
| <a name="input_compute_cluster_subnet_id"></a> [compute\_cluster\_subnet\_id](#input\_compute\_cluster\_subnet\_id) | n/a | `string` | `""` | no |
| <a name="input_extra_tags"></a> [extra\_tags](#input\_extra\_tags) | additional tags | `map(any)` | `{}` | no |
| <a name="input_namings"></a> [namings](#input\_namings) | the object of the onelab-standards | `any` | n/a | yes |
| <a name="input_private_endpoint_subnet_id"></a> [private\_endpoint\_subnet\_id](#input\_private\_endpoint\_subnet\_id) | n/a | `string` | `""` | no |
| <a name="input_resource_group"></a> [resource\_group](#input\_resource\_group) | resource\_group data | `any` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_identity"></a> [identity](#output\_identity) | An identity block exports the following: - principal\_id: The (Client) ID of the Service Principal, -tenant\_id: The ID of the Tenant the Service Principal is assigned in. |
| <a name="output_rbac_id"></a> [rbac\_id](#output\_rbac\_id) | n/a |
| <a name="output_workspac"></a> [workspac](#output\_workspac) | The ID of the Machine Learning Workspace. |

## Calling the module

<details>
<summary>Click to expand</summary>

```hcl
resource "random_integer" "suffix" {
  min = 10
  max = 99
}

resource "random_id" "rg_name" {
  byte_length = 8
}

module "onelab_standards" {
  source      = "../../rabobank-onelab-standards"
  bp_code     = var.bp_code
  department  = var.department
  location    = var.location
  project     = var.project
  seq_nr      = random_integer.suffix.result
  environment = var.environment
}

resource "null_resource" "delete_rg" {
  # Resource groups are sometimes not deleted due to errors. This null_resource prevents flaky tests.
  provisioner "local-exec" {
    command    = "az group delete --name 'test-module-aml-${random_id.rg_name.hex}-rg' --subscription '409c506d-38d6-46b8-bd83-301633d8a28d' --yes"
    on_failure = continue
  }
}

resource "azurerm_resource_group" "test" {
  name       = "test-module-aml-${random_id.rg_name.hex}-rg"
  location   = "West Europe"
  tags       = module.onelab_standards.default_tags # Policy: resource group needs certain tags
  depends_on = [null_resource.delete_rg]
}


module "onelab_network" {
  source             = "../../rabobank-networking"
  resource_group     = azurerm_resource_group.test
  namings            = module.onelab_standards
  vnet_address_space = local.vnet_address_space
  subnets            = local.subnets
  extra_tags         = local.extra_tags
}

module "onelab_storage_account" {
  source                          = "../../rabobank-storage-account"
  resource_group                  = azurerm_resource_group.test
  namings                         = module.onelab_standards
  hns_enabled                     = false
  shared_access_key_enabled       = true
  private_endpoint_subnet_id      = module.onelab_network.subnets["pe"].id
  allow_nested_items_to_be_public = false
  make_spn_contributor            = false #true
  extra_fw_subnet_ids             = module.onelab_network.subnet_ids
  storage_containers              = var.storage_containers
  private_endpoints = {
    # Note: AzCopy (StorageExplorer) uses the Blob api!
    "dfs" : local.aml_private_endpoint_dns_zone_ids["dfs"]
    "blob" : local.aml_private_endpoint_dns_zone_ids["blob"]
    "file" : local.aml_private_endpoint_dns_zone_ids["file"]
  }
  extra_tags = {
    AcceptedException_storage-H-007 : "The audit log is not supoorted with AzureAd Authentication so Accesskeys are required"
  }
  providers = {
    azurerm                = azurerm
    azurerm.ccc_management = azurerm.ccc_management
  }
}

module "onelab_azure_container_registry" {
  source                = "../../rabobank-container-registry"
  namings               = module.onelab_standards
  resource_group        = azurerm_resource_group.test
  network_rule_set      = local.acr_network_rule_set
  retention_policy_days = 8
}

module "onelab_key_vault" {
  source         = "../../rabobank-key-vault"
  namings        = module.onelab_standards
  resource_group = azurerm_resource_group.test
  access_rules = {
    # eu.res.AADAzureOneLab.us
    "d82e3ce3-2da5-4f37-beb2-ee913c39cd3f" = {
      secret_permissions = ["Get", "Set", "List"]
    }
    # cld.aut.AzureData.onelab.dev.spn
    "0094f540-6511-4385-b297-dc48f3904e05" = {
      secret_permissions = ["Get", "Set"]
    }
  }
  secrets                    = {}
  tenant_id                  = data.azurerm_subscription.current.tenant_id
  soft_delete_retention_days = 8
  providers = {
    azurerm                = azurerm,
    azurerm.ccc_management = azurerm.ccc_management
  }
}
resource "azurerm_application_insights" "appinsights" {
  name                = "aps-test-appinsights"
  location            = azurerm_resource_group.test.location
  resource_group_name = azurerm_resource_group.test.name
  application_type    = "web"
}

module "onelab_azure_machine_learning" {
  source                      = "./.."
  namings                     = module.onelab_standards
  resource_group              = azurerm_resource_group.test
  aml_workspace_configuration = local.machine_learning_workspaces
  private_endpoint_subnet_id  = module.onelab_network.subnets["pe"].id
  compute_cluster_subnet_id   = module.onelab_network.subnets["aml"].id
  aml_compute_clusters        = local.aml_compute_clusters
  depends_on                  = [azurerm_application_insights.appinsights, module.onelab_storage_account.sa, module.onelab_azure_container_registry.acr, module.onelab_key_vault.kv_id]
  providers = {
    azurerm                = azurerm
    azurerm.ccc_management = azurerm.ccc_management
  }
}
```

</details>
<!-- END_TF_DOCS -->