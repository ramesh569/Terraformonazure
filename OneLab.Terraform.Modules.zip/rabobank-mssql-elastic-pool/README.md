<!-- BEGIN_TF_DOCS -->


## CCC alignment
This module follow the CCC security guidelines, as indicated in the link below
- [CCC Resource Overview](https://confluence.dev.rabobank.nl/display/Azure/Quickstarts)

## Requirements

No requirements.

## Providers

No providers.

## Modules

No modules.

## Resources

No resources.

## Inputs

No inputs.

## Outputs

No outputs.

## Calling the module

<details>
<summary>Click to expand</summary>

```hcl
provider "azurerm" {
  alias                           = "ccc_management"
  resource_provider_registrations = "none"
  subscription_id                 = "f13f81f8-7578-4ca8-83f3-0a845fad3cb5" # sub-prd-global-cccmanagement
  features {}
}

resource "random_integer" "suffix" {
  min = 10
  max = 99
}

resource "random_id" "rg_name" {
  byte_length = 8
}

module "namings" {
  source      = "../../rabobank-onelab-standards"
  bp_code     = var.bp_code
  department  = var.department
  location    = var.location
  project     = var.project
  seq_nr      = random_integer.suffix.result
  environment = var.environment
}

resource "null_resource" "delete_rg" {
  # Resource groups are sometimes not deleted. This prevents flaky tests.
  provisioner "local-exec" {
    command    = "az group delete --name 'test-module-mssql-pool-${random_id.rg_name.hex}-rg' --subscription '409c506d-38d6-46b8-bd83-301633d8a28d' --yes"
    on_failure = continue
  }
}

resource "azurerm_resource_group" "test" {
  name       = "test-module-mssql-pool-${random_id.rg_name.hex}-rg"
  location   = "West Europe"
  tags       = module.namings.default_tags # Policy: resource group needs certain tags
  depends_on = [null_resource.delete_rg]
}


module "onelab_network" {
  source             = "../../rabobank-networking"
  resource_group     = azurerm_resource_group.test
  namings            = module.namings
  vnet_address_space = local.vnet_address_space
  subnets            = local.subnets
  extra_tags         = local.extra_tags
}
module "onelab_storage_account" {
  source                          = "../../rabobank-storage-account"
  resource_group                  = azurerm_resource_group.test
  namings                         = module.namings
  hns_enabled                     = false
  shared_access_key_enabled       = true
  private_endpoint_subnet_id      = module.onelab_network.subnets["pe"].id
  allow_nested_items_to_be_public = false
  make_spn_contributor            = true
  storage_containers              = var.storage_containers

  extra_tags = {
    AcceptedException_storage-H-007 : "The audit log is not supoorted with AzureAd Authentication so Accesskeys are required"
  }
  providers = {
    azurerm                = azurerm
    azurerm.ccc_management = azurerm.ccc_management
  }
}

module "onelab_mssql_servers" {
  source   = "./../modules/mssql_server"
  for_each = local.mssql_servers

  resource_group = azurerm_resource_group.test
  settings       = each.value
  extra_tags     = merge(local.allow_public_network_tag, local.extra_tags)
  depends_on     = [module.onelab_storage_account]
}

module "onelab_mssql_elasticpool" {
  source         = "./../modules/mssql_elastic_pool"
  namings        = module.namings
  server_name    = module.onelab_mssql_servers["masterSQLServer"].name
  resource_group = azurerm_resource_group.test
  settings       = local.mssql_elastic_pools
  extra_tags     = local.extra_tags
}

module "onelab_master_db" {
  source          = "./../modules/mssql_database"
  for_each        = local.mssql_databases
  resource_group  = azurerm_resource_group.test
  settings        = each.value
  storage_account = module.onelab_storage_account.sa.name
  extra_tags      = local.extra_tags
  depends_on      = [module.onelab_mssql_servers, module.onelab_mssql_elasticpool]
}
```

</details>
<!-- END_TF_DOCS -->