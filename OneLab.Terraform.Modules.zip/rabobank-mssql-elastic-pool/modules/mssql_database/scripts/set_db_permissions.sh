#!/bin/bash

set -e
az account get-access-token --resource https://database.windows.net --output tsv | cut -f 1 | tr -d '\n' | iconv -f ascii -t UTF-16LE >@token
sqlcmd -v DBUSERNAMES="${DBUSERNAMES}" DBROLES="${DBROLES}" -S "${SQLCMDSERVER}" -d "${SQLCMDDBNAME}" -i "${SQLFILEPATH}" -G -P @token
