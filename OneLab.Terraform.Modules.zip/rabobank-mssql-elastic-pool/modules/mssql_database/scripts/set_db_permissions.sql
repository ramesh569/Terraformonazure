:on error exit

DECLARE @dbusernames VARCHAR(1000), @username VARCHAR(100), @create_user_cmd VARCHAR(300)
DECLARE @dbroles VARCHAR(1000), @dbrolename VARCHAR(100), @alter_role_cmd VARCHAR(300), @db_customrole_cmd VARCHAR(3000)

-- to be passed from sqlcmd -v
SET @dbusernames = $(DBUSERNAMES)
PRINT CONCAT('all users ', $(DBUSERNAMES))
  WHILE len(@dbusernames) > 0
  BEGIN
    SET @username = left(@dbusernames, charindex(',', @dbusernames+',')-1)
    SET @create_user_cmd='CREATE USER [' + @username + '] FROM EXTERNAL PROVIDER'
    -- User creation
    IF NOT EXISTS (SELECT NAME FROM sys.database_principals WHERE NAME = @username)
      BEGIN
        EXEC(@create_user_cmd);
        PRINT CONCAT('User ', @username, ' created.');
      END
    ELSE
      PRINT CONCAT('User ', @username, ' already exist.');
    -- End - User creation
    -- Role assignment
    SET @dbroles = $(DBROLES)
    WHILE len(@dbroles) > 0
      BEGIN
        SET @dbrolename = left(@dbroles, charindex(',', @dbroles + ',')-1)
        IF NOT EXISTS (SELECT name FROM sys.database_principals WHERE name = @dbrolename)
          BEGIN
            SET @db_customrole_cmd= 'CREATE ROLE ' + @dbrolename + '; ' +
                                    'GRANT BACKUP DATABASE to ' + @dbrolename + '; ' +
                                    'GRANT BACKUP LOG to ' + @dbrolename + '; ' +
                                    'GRANT CHECKPOINT to ' + @dbrolename + '; ' +
                                    'GRANT CONNECT to ' + @dbrolename + '; ' +
                                    'GRANT CONTROL to ' + @dbrolename + '; ' +
                                    'GRANT CREATE AGGREGATE to ' + @dbrolename + '; ' +
                                    'GRANT CREATE ASSEMBLY to ' + @dbrolename + '; ' +
                                    'GRANT CREATE CONTRACT to ' + @dbrolename + '; ' +
                                    'GRANT CREATE DEFAULT to ' + @dbrolename + '; ' +
                                    'GRANT CREATE FUNCTION to ' + @dbrolename + '; ' +
                                    'GRANT CREATE PROCEDURE to ' + @dbrolename + '; ' +
                                    'GRANT CREATE QUEUE to ' + @dbrolename + '; ' +
                                    'GRANT CREATE RULE to ' + @dbrolename + '; ' +
                                    'GRANT CREATE SCHEMA to ' + @dbrolename + '; ' +
                                    'GRANT CREATE SYNONYM to ' + @dbrolename + '; ' +
                                    'GRANT CREATE TABLE to ' + @dbrolename + '; ' +
                                    'GRANT CREATE TYPE to ' + @dbrolename + '; ' +
                                    'GRANT CREATE VIEW to ' + @dbrolename + '; ' +
                                    'GRANT DELETE to ' + @dbrolename + '; ' +
                                    'GRANT DROP ANY DATABASE EVENT SESSION to ' + @dbrolename + '; ' +
                                    'GRANT EXECUTE to ' + @dbrolename + '; ' +
                                    'GRANT INSERT to ' + @dbrolename + '; ' +
                                    'GRANT KILL DATABASE CONNECTION to ' + @dbrolename + '; ' +
                                    'GRANT REFERENCES to ' + @dbrolename + '; ' +
                                    'GRANT SELECT to ' + @dbrolename + '; ' +
                                    'GRANT UPDATE to ' + @dbrolename + '; ' +
                                    'GRANT VIEW DATABASE STATE to ' + @dbrolename + '; ' +
                                    'GRANT VIEW DEFINITION to ' + @dbrolename + '; '
            EXEC(@db_customrole_cmd);
            PRINT CONCAT('Role ', @dbrolename, ' created.');
          END
        ELSE
          PRINT CONCAT('Role ', @dbrolename, ' already exist.');
        SET @alter_role_cmd = 'ALTER ROLE ' + @dbrolename + ' ADD MEMBER [' + @username + ']'
        EXEC(@alter_role_cmd)
        PRINT CONCAT('Added role ', @dbrolename, ' to user ', @username)
        SET @dbroles = stuff(@dbroles, 1, charindex(',', @dbroles+','), '')
      END
    -- END Role assignment
    SET @dbusernames = stuff(@dbusernames, 1, charindex(',', @dbusernames+','), '')
  END