<!-- BEGIN_TF_DOCS -->
# Module: networking
This module includes:
- Creation of a network

## Important Design decisions

- Current requirement: 1 route table for all subnets
- Default route to hub firewall

## CCC alignment
This module follow the CCC security guidelines, as indicated in the link below
- [CCC Resource Overview](https://confluence.dev.rabobank.nl/display/Azure/Quickstarts)

## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >1.10.0 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >= 4.0.1, < 5.0.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | >= 4.0.1, < 5.0.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_ip_group.ip_group](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/ip_group) | resource |
| [azurerm_network_security_group.nsg](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_group) | resource |
| [azurerm_network_security_rule.nsg_rules](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_security_rule) | resource |
| [azurerm_route.default](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/route) | resource |
| [azurerm_route.route](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/route) | resource |
| [azurerm_route_table.rtable](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/route_table) | resource |
| [azurerm_subnet.subnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet) | resource |
| [azurerm_subnet_network_security_group_association.nsga](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_network_security_group_association) | resource |
| [azurerm_subnet_route_table_association.rtable](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/subnet_route_table_association) | resource |
| [azurerm_virtual_network.vnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network) | resource |
| [azurerm_route_table.rtable](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/route_table) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_bgp_route_propagation_enabled"></a> [bgp\_route\_propagation\_enabled](#input\_bgp\_route\_propagation\_enabled) | Boolean flag which controls propagation of routes learned by BGP on that route table. false means disable | `bool` | `false` | no |
| <a name="input_create_route_table"></a> [create\_route\_table](#input\_create\_route\_table) | Boolean flag which controls the creation of RT | `bool` | `true` | no |
| <a name="input_dns_servers"></a> [dns\_servers](#input\_dns\_servers) | The DNS servers to be used with vNet. | `list(string)` | `[]` | no |
| <a name="input_extra_routes"></a> [extra\_routes](#input\_extra\_routes) | A list of extra routes to be added to the URD | <pre>map(<br>    object({<br>      nexthop_type = string<br>      route_prefix = string<br>    })<br>  )</pre> | `{}` | no |
| <a name="input_extra_tags"></a> [extra\_tags](#input\_extra\_tags) | additional tags | `map(string)` | `{}` | no |
| <a name="input_link_to_centralized_route_table"></a> [link\_to\_centralized\_route\_table](#input\_link\_to\_centralized\_route\_table) | Boolean flag which controls the assosciation with centralized RT | `bool` | `false` | no |
| <a name="input_namings"></a> [namings](#input\_namings) | the object of the onelab-standards | `any` | n/a | yes |
| <a name="input_resource_group"></a> [resource\_group](#input\_resource\_group) | resource\_group data | `any` | n/a | yes |
| <a name="input_route_to_firewall"></a> [route\_to\_firewall](#input\_route\_to\_firewall) | Boolean flag used to control the routing of traffic to AzFirewall. True means route the traffic to AzFirewall | `bool` | `true` | no |
| <a name="input_subnet_prefix"></a> [subnet\_prefix](#input\_subnet\_prefix) | prefix for subnetname | `string` | `"snet-"` | no |
| <a name="input_subnets"></a> [subnets](#input\_subnets) | A dictionary to configure your network | <pre>map(<br>    object({<br>      prefix                                         = string<br>      enforce_private_link_endpoint_network_policies = optional(string)<br>      enforce_private_link_service_network_policies  = optional(bool)<br>      service_endpoints                              = optional(list(any))<br>      service_endpoint_policy_ids                    = optional(list(string))<br>      delegations = optional(map(object({<br>        service_name    = optional(string)<br>        service_actions = optional(list(any))<br>      })))<br>      nsg_rules = optional(list(map(any)))<br>      use_nsg   = optional(bool)<br>    })<br>  )</pre> | n/a | yes |
| <a name="input_vnet_address_space"></a> [vnet\_address\_space](#input\_vnet\_address\_space) | The address space that is used by the virtual network. | `string` | `""` | no |
| <a name="input_vnet_address_spaces"></a> [vnet\_address\_spaces](#input\_vnet\_address\_spaces) | The address spaces used by the virtual network. | `list(string)` | `[]` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_nsgs"></a> [nsgs](#output\_nsgs) | List of Network Security Groups |
| <a name="output_route_table"></a> [route\_table](#output\_route\_table) | First route-table object, default for all subnets |
| <a name="output_subnet_ids"></a> [subnet\_ids](#output\_subnet\_ids) | All the subnet IDs |
| <a name="output_subnet_names"></a> [subnet\_names](#output\_subnet\_names) | All the subnet names |
| <a name="output_subnets"></a> [subnets](#output\_subnets) | Complete subnet objects |
| <a name="output_vnet"></a> [vnet](#output\_vnet) | Complete vnet object |
| <a name="output_vnet_id"></a> [vnet\_id](#output\_vnet\_id) | The id of the newly created vNet |
| <a name="output_vnet_name"></a> [vnet\_name](#output\_vnet\_name) | The Name of the newly created vNet |

## Calling the module

<details>
<summary>Click to expand</summary>

```hcl
provider "azurerm" {
  features {}
}

module "namings" {
  source      = "../../rabobank-onelab-standards"
  bp_code     = var.bp_code
  department  = var.department
  location    = var.location
  project     = var.project
  seq_nr      = "01"
  environment = var.environment
}

resource "random_id" "rg_name" {
  byte_length = 8
}

resource "null_resource" "delete_rg" {
  # Resource groups are sometimes not deleted due to errors. This null_resource prevents flaky tests.
  provisioner "local-exec" {
    command    = "az group delete --name 'test-module-network-${random_id.rg_name.hex}-rg' --subscription '409c506d-38d6-46b8-bd83-301633d8a28d' --yes"
    on_failure = continue
  }
}

resource "azurerm_resource_group" "test" {
  name       = "test-module-network-${random_id.rg_name.hex}-rg"
  location   = var.location
  tags       = module.namings.default_tags # Policy: resource group needs certain tags
  depends_on = [null_resource.delete_rg]
}

### Use either vnet_address_space or vnet_address_spaces in the network module
module "network" {
  source              = "./.."
  resource_group      = azurerm_resource_group.test
  namings             = module.namings
  vnet_address_spaces = var.address_spaces
  subnets             = var.subnets
  extra_routes        = var.routes
  extra_tags          = var.extra_tags
}
```

</details>
<!-- END_TF_DOCS -->