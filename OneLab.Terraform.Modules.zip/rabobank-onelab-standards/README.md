<!-- BEGIN_TF_DOCS -->
# Module: onelab-standards
This module includes:
- Only some naming and outputting of those

## CCC alignment
This module follow the CCC security guidelines, as indicated in the link below
- [CCC Resource Overview](https://confluence.dev.rabobank.nl/display/Azure/Quickstarts)

## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >1.10.0 |

## Providers

No providers.

## Modules

No modules.

## Resources

No resources.

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_bp_code"></a> [bp\_code](#input\_bp\_code) | Blueprint from which this resource group is created. | `string` | n/a | yes |
| <a name="input_department"></a> [department](#input\_department) | department, eg. 1lab | `string` | n/a | yes |
| <a name="input_environment"></a> [environment](#input\_environment) | Environment | `string` | n/a | yes |
| <a name="input_lab_variant"></a> [lab\_variant](#input\_lab\_variant) | n/a | `string` | `"onelab"` | no |
| <a name="input_location"></a> [location](#input\_location) | Location of the resource group | `string` | `"westeurope"` | no |
| <a name="input_project"></a> [project](#input\_project) | Project name | `string` | n/a | yes |
| <a name="input_seq_nr"></a> [seq\_nr](#input\_seq\_nr) | seq nr of resources | `string` | `"01"` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_base_name"></a> [base\_name](#output\_base\_name) | The Base name for every resource |
| <a name="output_bp_code"></a> [bp\_code](#output\_bp\_code) | bp\_code |
| <a name="output_default_tags"></a> [default\_tags](#output\_default\_tags) | A list of default tags within One!Lab |
| <a name="output_department"></a> [department](#output\_department) | department |
| <a name="output_environment"></a> [environment](#output\_environment) | Environment |
| <a name="output_lab_variant"></a> [lab\_variant](#output\_lab\_variant) | The different onelab variants that onelab has, this can be onelab for production data or openlab for development |
| <a name="output_location"></a> [location](#output\_location) | Location |
| <a name="output_project"></a> [project](#output\_project) | Project Name |
| <a name="output_seq_nr"></a> [seq\_nr](#output\_seq\_nr) | seq\_nr |
| <a name="output_short_base_name"></a> [short\_base\_name](#output\_short\_base\_name) | The Base name for every resource which has a limited caracter place e.g. Storage account |
| <a name="output_underscored_base_name"></a> [underscored\_base\_name](#output\_underscored\_base\_name) | The Base name for every resource with underscores |

## Calling the module

<details>
<summary>Click to expand</summary>

```hcl
module "onelab_namings" {
  source      = "./.."
  bp_code     = var.bp_code
  department  = var.department
  environment = var.environment
  project     = var.project
  seq_nr      = var.seq_nr
}
```

</details>
<!-- END_TF_DOCS -->