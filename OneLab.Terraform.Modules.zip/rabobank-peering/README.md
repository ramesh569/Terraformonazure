<!-- BEGIN_TF_DOCS -->
# Module: peering
This module includes:
- Peering between two existing VNet's. They might be in a different subscription.

## CCC alignment
This module follow the CCC security guidelines, as indicated in the link below
- [CCC Resource Overview](https://confluence.dev.rabobank.nl/display/Azure/Quickstarts)

## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >1.10.0 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >= 4.0.1, < 5.0.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | >= 4.0.1, < 5.0.0 |
| <a name="provider_azurerm.hub_sub"></a> [azurerm.hub\_sub](#provider\_azurerm.hub\_sub) | >= 4.0.1, < 5.0.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_private_dns_zone_virtual_network_link.private_links_for_dns_zones](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_dns_zone_virtual_network_link) | resource |
| [azurerm_virtual_network_peering.hub_to_instance](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_peering) | resource |
| [azurerm_virtual_network_peering.instance_to_hub](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network_peering) | resource |
| [azurerm_virtual_network.hub_virtual_network](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/virtual_network) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_add_dns_links_to_subnet"></a> [add\_dns\_links\_to\_subnet](#input\_add\_dns\_links\_to\_subnet) | Add dns linkings to network | `bool` | `false` | no |
| <a name="input_hub_network"></a> [hub\_network](#input\_hub\_network) | Hub Network object | <pre>object({<br>    resource_group_name = string,<br>    vnet_name           = string<br>  })</pre> | <pre>{<br>  "resource_group_name": "",<br>  "vnet_name": ""<br>}</pre> | no |
| <a name="input_instance_vnet"></a> [instance\_vnet](#input\_instance\_vnet) | Map of the vnet object from Module Networking | `any` | n/a | yes |
| <a name="input_lab_variant"></a> [lab\_variant](#input\_lab\_variant) | n/a | `string` | `"onelab"` | no |
| <a name="input_namings"></a> [namings](#input\_namings) | the object of the onelab-standards | `any` | n/a | yes |
| <a name="input_peer_network_to_hub"></a> [peer\_network\_to\_hub](#input\_peer\_network\_to\_hub) | Is a peering to hub network needed | `bool` | `true` | no |
| <a name="input_private_endpoint_ids"></a> [private\_endpoint\_ids](#input\_private\_endpoint\_ids) | Start the Instance Peerings, after these Private Endpoint ID's. | `list(string)` | `[]` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_peers"></a> [peers](#output\_peers) | all vnet peer objects with the ID, it's settings and reference the VNet object. |
| <a name="output_private_dns_zones"></a> [private\_dns\_zones](#output\_private\_dns\_zones) | all private dns objects |

## Calling the module

<details>
<summary>Click to expand</summary>

```hcl
provider "azurerm" {
  features {}
}

provider "azurerm" {
  alias = "hub_sub"
  features {}
}

provider "azurerm" {
  alias = "ctx_sub"
  features {}
}

module "namings" {
  source      = "../../rabobank-onelab-standards"
  bp_code     = var.bp_code
  department  = var.department
  location    = var.location
  project     = var.project
  seq_nr      = "01"
  environment = var.environment
}

resource "random_id" "rg_name" {
  byte_length = 8
}

resource "null_resource" "delete_rg" {
  # Resource groups are sometimes not deleted due to errors. This null_resource prevents flaky tests.
  provisioner "local-exec" {
    command    = "az group delete --name 'test-module-peering-${random_id.rg_name.hex}-rg' --subscription '409c506d-38d6-46b8-bd83-301633d8a28d' --yes"
    on_failure = continue
  }
}

resource "azurerm_resource_group" "test" {
  name       = "test-module-peering-${random_id.rg_name.hex}-rg"
  location   = var.location
  tags       = module.namings.default_tags # Policy: resource group needs certain tags
  depends_on = [null_resource.delete_rg]
}

resource "azurerm_virtual_network" "vnet" {
  count               = 3
  name                = "vnet-${var.department}-${var.project}-${var.environment}-0${tostring(count.index + 1)}"
  resource_group_name = azurerm_resource_group.test.name
  location            = azurerm_resource_group.test.location
  address_space       = [var.vnet_address_spaces[count.index]]

  tags = module.namings.default_tags # Policy: vnet needs certain tags
}

module "vnet-peering" {
  providers = {
    azurerm.instance_sub = azurerm
    azurerm.hub_sub      = azurerm.hub_sub
    azurerm.ctx_sub      = azurerm.ctx_sub
  }
  source = "./.."
  namings = {
    project     = var.project
    environment = var.environment
  }
  instance_vnet = azurerm_virtual_network.vnet[1]
  hub_network = {
    resource_group_name = azurerm_virtual_network.vnet[0].resource_group_name
    vnet_name           = azurerm_virtual_network.vnet[0].name
  }
  peer_network_to_hub     = true
  add_dns_links_to_subnet = false # TODO: test these as well but then we need to add zones here
  private_endpoint_ids    = var.private_endpoint_ids
}
```

</details>
<!-- END_TF_DOCS -->