<!-- BEGIN_TF_DOCS -->


## CCC alignment
This module follow the CCC security guidelines, as indicated in the link below
- [CCC Resource Overview](https://confluence.dev.rabobank.nl/display/Azure/Quickstarts)

## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >1.10.0 |
| <a name="requirement_azapi"></a> [azapi](#requirement\_azapi) | >=2.0.0, <3.0.0 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >= 4.0.1, < 5.0.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | >= 4.0.1, < 5.0.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_private_endpoint.private_endpoint](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_extra_tags"></a> [extra\_tags](#input\_extra\_tags) | additional tags | `map(string)` | `{}` | no |
| <a name="input_is_manual_connection"></a> [is\_manual\_connection](#input\_is\_manual\_connection) | Does the Private Endpoint require Manual Approval from the remote resource owner? | `bool` | `false` | no |
| <a name="input_namings"></a> [namings](#input\_namings) | the object of the onelab-standards | `any` | n/a | yes |
| <a name="input_pe_name"></a> [pe\_name](#input\_pe\_name) | name of private endpoint and link  after the pe\_ and psc\_ prefix | `string` | n/a | yes |
| <a name="input_pe_subnet_id"></a> [pe\_subnet\_id](#input\_pe\_subnet\_id) | The ID of the Subnet from which Private IP Addresses will be allocated for this Private Endpoint. | `string` | n/a | yes |
| <a name="input_private_connection_resource_id"></a> [private\_connection\_resource\_id](#input\_private\_connection\_resource\_id) | The ID of the Private Link Enabled Remote Resource which this Private Endpoint should be connected to | `string` | n/a | yes |
| <a name="input_private_dnszones"></a> [private\_dnszones](#input\_private\_dnszones) | A map of subResourceNames with their Private Endpoint Zone Id | `map(any)` | `{}` | no |
| <a name="input_resource_group"></a> [resource\_group](#input\_resource\_group) | resource\_group data | `any` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_status"></a> [status](#output\_status) | n/a |

## Calling the module

<details>
<summary>Click to expand</summary>

```hcl
provider "azurerm" {
  features {}
  storage_use_azuread = true
}

provider "azurerm" {
  alias                      = "ccc_management"
  skip_provider_registration = true
  subscription_id            = "f13f81f8-7578-4ca8-83f3-0a845fad3cb5" # sub-prd-global-cccmanagement
  features {}
}

resource "random_id" "rg_name" {
  byte_length = 8
}

resource "random_integer" "suffix" {
  min = 10
  max = 99
}

module "namings" {
  source      = "../../rabobank-onelab-standards"
  bp_code     = var.bp_code
  department  = var.department
  location    = var.location
  project     = var.project
  seq_nr      = random_integer.suffix.result
  environment = var.environment
}

resource "null_resource" "delete_rg" {
  # Resource groups are sometimes not deleted due to errors. This null_resource prevents flaky tests.
  provisioner "local-exec" {
    command    = "az group delete --name 'test-module-private-endpoint-${random_id.rg_name.hex}-rg' --subscription '409c506d-38d6-46b8-bd83-301633d8a28d' --yes"
    on_failure = continue
  }
}

resource "azurerm_resource_group" "test" {
  name       = "test-module-private-endpoint-${random_id.rg_name.hex}-rg"
  location   = "West Europe"
  tags       = module.namings.default_tags # Policy: resource group needs certain tags
  depends_on = [null_resource.delete_rg]
}

module "onelab_network" {
  source             = "../../rabobank-networking"
  resource_group     = azurerm_resource_group.test
  namings            = module.namings
  vnet_address_space = var.vnet_address_space
  subnets            = var.subnets
}

module "onelab_storage_account" {
  source                     = "../../rabobank-storage-account"
  namings                    = module.namings
  resource_group             = azurerm_resource_group.test
  extra_tags                 = var.extra_tags
  private_endpoint_subnet_id = module.onelab_network.subnets["test"].id
  make_spn_contributor       = true
  shared_access_key_enabled  = true # Work-around for: Status=403 Code="KeyBasedAuthenticationNotPermitted" Message="Key based authentication is not permitted on this storage account.
  dev_access_from_local      = { enabled = false, current_environment = "dev" }
  extra_fw_subnet_ids        = [module.onelab_network.subnets["test"].id]
  providers = {
    azurerm                = azurerm
    azurerm.ccc_management = azurerm.ccc_management
  }
}

module "onelab_private_endpoint" {
  source                         = "./.."
  resource_group                 = azurerm_resource_group.test
  namings                        = module.namings
  pe_name                        = "test"
  pe_subnet_id                   = module.onelab_network.subnets["test"].id
  private_dnszones               = var.storage.dnszone_subresources
  private_connection_resource_id = module.onelab_storage_account.sa.id
  is_manual_connection           = true
  extra_tags                     = var.extra_tags
}
```

</details>
<!-- END_TF_DOCS -->