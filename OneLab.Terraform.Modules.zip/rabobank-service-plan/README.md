<!-- BEGIN_TF_DOCS -->


## CCC alignment
This module follow the CCC security guidelines, as indicated in the link below
- [CCC Resource Overview](https://confluence.dev.rabobank.nl/display/Azure/Quickstarts)

## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >1.10.0 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >= 4.0.1, < 5.0.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | >= 4.0.1, < 5.0.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_service_plan.asp](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/service_plan) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_app_service_environment_id"></a> [app\_service\_environment\_id](#input\_app\_service\_environment\_id) | The ID of the App Service Environment to create this Service Plan in. Requires an Isolated SKU. Use one of I1, I2, I3 for `azurerm_app_service_environment`, or I1v2, I2v2, I3v2 for `azurerm_app_service_environment_v3`. | `string` | `null` | no |
| <a name="input_asp_name"></a> [asp\_name](#input\_asp\_name) | The Name of the App Service Plan. If not provided, a name will be generated. | `string` | `null` | no |
| <a name="input_extra_tags"></a> [extra\_tags](#input\_extra\_tags) | additional tags | `map(string)` | `{}` | no |
| <a name="input_maximum_elastic_worker_count"></a> [maximum\_elastic\_worker\_count](#input\_maximum\_elastic\_worker\_count) | The maximum number of workers to use in an Elastic SKU Plan. Cannot be set unless using an Elastic SKU. | `number` | `null` | no |
| <a name="input_namings"></a> [namings](#input\_namings) | the object of the onelab-standards | `any` | n/a | yes |
| <a name="input_ostype"></a> [ostype](#input\_ostype) | The O/S type for the App Services to be hosted in this plan. Possible values include `Windows`, `Linux`, and `WindowsContainer`. | `string` | `"Linux"` | no |
| <a name="input_per_site_scaling_enabled"></a> [per\_site\_scaling\_enabled](#input\_per\_site\_scaling\_enabled) | Should Per Site Scaling be enabled. | `bool` | `false` | no |
| <a name="input_resource_group"></a> [resource\_group](#input\_resource\_group) | The object of the resource group in which to create the App Plan. | `any` | n/a | yes |
| <a name="input_sku"></a> [sku](#input\_sku) | The Name of the SKU used for this App Plan. | `string` | `"S1"` | no |
| <a name="input_worker_count"></a> [worker\_count](#input\_worker\_count) | The number of Workers (instances) to be allocated. | `number` | `null` | no |
| <a name="input_zone_balancing_enabled"></a> [zone\_balancing\_enabled](#input\_zone\_balancing\_enabled) | Should zone load balancing be enabled. | `bool` | `false` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_azure_service_plan"></a> [azure\_service\_plan](#output\_azure\_service\_plan) | Created App plan |
| <a name="output_serviceplan_id"></a> [serviceplan\_id](#output\_serviceplan\_id) | Created App plan ID |

## Calling the module

<details>
<summary>Click to expand</summary>

```hcl
provider "azurerm" {
  features {}
}

module "namings" {
  source      = "../../rabobank-onelab-standards"
  bp_code     = var.bp_code
  department  = var.department
  location    = var.location
  project     = var.project
  seq_nr      = "01"
  environment = var.environment
}

resource "random_id" "rg_name" {
  byte_length = 8
}

resource "null_resource" "delete_rg" {
  # Resource groups are sometimes not deleted due to errors. This null_resource prevents flaky tests.
  provisioner "local-exec" {
    command    = "az group delete --name 'test-module-appplan-${random_id.rg_name.hex}-rg' --subscription '409c506d-38d6-46b8-bd83-301633d8a28d' --yes"
    on_failure = continue
  }
}

resource "azurerm_resource_group" "test" {
  name       = "test-module-appplan-${random_id.rg_name.hex}-rg"
  location   = module.namings.location
  tags       = module.namings.default_tags # Policy: resource group needs certain tags
  depends_on = [null_resource.delete_rg]
}

module "service-plan" {
  source                 = "./.."
  namings                = module.namings
  resource_group         = azurerm_resource_group.test
  ostype                 = var.ostype
  zone_balancing_enabled = var.zone_balancing_enabled
  sku                    = var.sku
}
```

</details>
<!-- END_TF_DOCS -->