<!-- BEGIN_TF_DOCS -->
# Module: service-principal
This module includes:
- Creation of a Service Principal

## CCC alignment
This module follow the CCC security guidelines, as indicated in the link below
- [CCC Resource Overview](https://confluence.dev.rabobank.nl/display/Azure/Quickstarts)

## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >1.10.0 |
| <a name="requirement_azuread"></a> [azuread](#requirement\_azuread) | >= 3.0.0, < 4.0.0 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >= 4.0.1, < 5.0.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azuread"></a> [azuread](#provider\_azuread) | >= 3.0.0, < 4.0.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azuread_application.aad_application_registration](https://registry.terraform.io/providers/hashicorp/azuread/latest/docs/resources/application) | resource |
| [azuread_application_password.aad_application_registration_password](https://registry.terraform.io/providers/hashicorp/azuread/latest/docs/resources/application_password) | resource |
| [azuread_service_principal.aad_service_principal](https://registry.terraform.io/providers/hashicorp/azuread/latest/docs/resources/service_principal) | resource |
| [azuread_client_config.current](https://registry.terraform.io/providers/hashicorp/azuread/latest/docs/data-sources/client_config) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_namings"></a> [namings](#input\_namings) | the object of the onelab-standards | `any` | n/a | yes |
| <a name="input_onelab_service_principal_type"></a> [onelab\_service\_principal\_type](#input\_onelab\_service\_principal\_type) | The type of the Service Principal (as supported by One!Lab) to be created. | `string` | `"data"` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_application_id"></a> [application\_id](#output\_application\_id) | Application ID of the created Service Principal |
| <a name="output_application_password"></a> [application\_password](#output\_application\_password) | n/a |
| <a name="output_service-principal"></a> [service-principal](#output\_service-principal) | Created Service Principal |

## Calling the module

<details>
<summary>Click to expand</summary>

```hcl
provider "azurerm" {
  features {}
}

module "namings" {
  source      = "../../rabobank-onelab-standards"
  bp_code     = var.bp_code
  department  = var.department
  project     = var.project
  seq_nr      = random_integer.rnd_sq.result
  environment = var.environment
}

resource "random_integer" "rnd_sq" {
  min = 10
  max = 99
}

module "aad_service_principal" {
  source                        = "./.."
  namings                       = module.namings
  onelab_service_principal_type = var.onelab_service_principal_type
}
```

</details>
<!-- END_TF_DOCS -->