<!-- BEGIN_TF_DOCS -->
# Module: shared-image-gallery
## Description:
This module includes:
- Creation of a [Shared Image Gallery](https://docs.microsoft.com/en-us/azure/virtual-machines/shared-image-galleries)

### Project\_info
The project info object is defined as follow:

```yml
  Project_info {
    Project = string
    Bp_code =  string
    Environment = string
    Department = string
    Seq_nr     = string
  }
```

### Shared images
The list is defined as followed:

```hcl
ImageName1 = {
      os_type = "Windows"
      specialized = false
      hyper_v_generation = V2
      trusted_launch_enabled = True
      tags = { extra tags }
  },

ImageName2 = {
      os_type = "Windows"
      # using all defaults.
  },

ImageName3 = {
    os_type = "Linux"
    identifier = {
      publisher = "Canonical"
      offer = "UbuntuServer"
      sku = "18.04-LTS"
    }
  }
```
and this can be repeated

## CCC alignment
This module follow the CCC security guidelines, as indicated in the link below
- [CCC Resource Overview](https://confluence.dev.rabobank.nl/display/Azure/Quickstarts)

## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >1.10.0 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >= 4.0.1, < 5.0.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | >= 4.0.1, < 5.0.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_shared_image.shared_image](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/shared_image) | resource |
| [azurerm_shared_image_gallery.sig](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/shared_image_gallery) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_extra_tags"></a> [extra\_tags](#input\_extra\_tags) | additional tags | `map(string)` | `{}` | no |
| <a name="input_gallery_description"></a> [gallery\_description](#input\_gallery\_description) | Reason for this Gallery | `string` | `""` | no |
| <a name="input_project_info"></a> [project\_info](#input\_project\_info) | See https://dev.azure.com/raboweb/Tribe Data and Analytics/\_wiki/wikis/One!Lab.wiki/61102/Project-definition | <pre>object({<br>    Project     = string<br>    Bp_code     = string<br>    Environment = string<br>    Department  = string<br>    Seq_nr      = string<br>  })</pre> | n/a | yes |
| <a name="input_resource_group"></a> [resource\_group](#input\_resource\_group) | Resource-Group object for name and it's location | `any` | n/a | yes |
| <a name="input_shared_images"></a> [shared\_images](#input\_shared\_images) | images to deploy | `any` | `{}` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_shared_image_gallery"></a> [shared\_image\_gallery](#output\_shared\_image\_gallery) | Created shared image gallery |
| <a name="output_shared_images"></a> [shared\_images](#output\_shared\_images) | Object of images created |

## Calling the module

<details>
<summary>Click to expand</summary>

```hcl
provider "azurerm" {
  features {}
}

resource "random_integer" "suffix" {
  min = 10
  max = 99
}

resource "random_id" "rg_name" {
  byte_length = 8
}

module "namings" {
  source      = "../../rabobank-onelab-standards"
  bp_code     = var.bp_code
  department  = var.department
  location    = var.location
  project     = var.project
  seq_nr      = random_integer.suffix.result
  environment = var.environment
}

resource "null_resource" "delete_rg" {
  # Resource groups are sometimes not deleted due to errors. This null_resource prevents flaky tests.
  provisioner "local-exec" {
    command    = "az group delete --name 'test-module-image-gallery-${random_id.rg_name.hex}-rg' --subscription '409c506d-38d6-46b8-bd83-301633d8a28d' --yes"
    on_failure = continue
  }
}

resource "azurerm_resource_group" "test" {
  name       = "test-module-shared-image-gallery-${random_id.rg_name.hex}-rg"
  location   = "West Europe"
  tags       = module.namings.default_tags # Policy: resource group needs certain tags
  depends_on = [null_resource.delete_rg]
}

module "onelab_shared-image-gallery" {
  source         = "./.."
  resource_group = azurerm_resource_group.test
  project_info = {
    Project     = module.namings.project
    Bp_code     = module.namings.bp_code
    Environment = module.namings.environment
    Department  = module.namings.department
    Seq_nr      = module.namings.seq_nr
  }
  extra_tags = module.namings.default_tags

  gallery_description = var.gallery_description
  shared_images       = var.shared_images
}
```

</details>
<!-- END_TF_DOCS -->