<!-- BEGIN_TF_DOCS -->
# Module: storage-account
## Description
This module includes:
- Creation of a storage account
- Creation of a private endpoint that allows for development from a local machine (dev resources)

## CCC alignment
This module follow the CCC security guidelines, as indicated in the link below
- [CCC Resource Overview](https://confluence.dev.rabobank.nl/display/Azure/Quickstarts)

## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >1.10.0 |
| <a name="requirement_azuread"></a> [azuread](#requirement\_azuread) | >= 3.0.0, < 4.0.0 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >= 4.0.1, < 5.0.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | >= 4.0.1, < 5.0.0 |
| <a name="provider_azurerm.ccc_management"></a> [azurerm.ccc\_management](#provider\_azurerm.ccc\_management) | >= 4.0.1, < 5.0.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_private_endpoint.pe_local_development_blob](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [azurerm_private_endpoint.pe_local_development_table](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [azurerm_private_endpoint.private_endpoint](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [azurerm_role_assignment.rbac_for_objects](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/role_assignment) | resource |
| [azurerm_role_assignment.spn_contributors](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/role_assignment) | resource |
| [azurerm_storage_account.sa](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_account) | resource |
| [azurerm_storage_account_queue_properties.name](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_account_queue_properties) | resource |
| [azurerm_storage_container.blob_container](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_container) | resource |
| [azurerm_storage_data_lake_gen2_filesystem.adls](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_data_lake_gen2_filesystem) | resource |
| [azurerm_storage_table.table](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_table) | resource |
| [azurerm_client_config.current](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/client_config) | data source |
| [azurerm_subscription.current](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/subscription) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_account_replication_type"></a> [account\_replication\_type](#input\_account\_replication\_type) | Replication Types | `string` | `"LRS"` | no |
| <a name="input_account_tier"></a> [account\_tier](#input\_account\_tier) | Tier of storage account | `string` | `"Standard"` | no |
| <a name="input_allow_nested_items_to_be_public"></a> [allow\_nested\_items\_to\_be\_public](#input\_allow\_nested\_items\_to\_be\_public) | The value that indicates whether to grant public access on blob containers | `bool` | `false` | no |
| <a name="input_bypass_network_settings"></a> [bypass\_network\_settings](#input\_bypass\_network\_settings) | Bypass nework rule exceptions | `any` | <pre>[<br>  "Logging",<br>  "Metrics",<br>  "AzureServices"<br>]</pre> | no |
| <a name="input_dev_access_from_local"></a> [dev\_access\_from\_local](#input\_dev\_access\_from\_local) | Enable access to dev resources from local development environments (if they're conneted to the Rabo network). | `object({ enabled = bool, current_environment = string })` | <pre>{<br>  "current_environment": "dev",<br>  "enabled": false<br>}</pre> | no |
| <a name="input_environment"></a> [environment](#input\_environment) | Environment where resources are deployed. | `string` | `"dev"` | no |
| <a name="input_extra_fw_ip_rules"></a> [extra\_fw\_ip\_rules](#input\_extra\_fw\_ip\_rules) | a list of additional ip addresses to add to the firewall | `list(any)` | `[]` | no |
| <a name="input_extra_fw_subnet_ids"></a> [extra\_fw\_subnet\_ids](#input\_extra\_fw\_subnet\_ids) | a list of network subnet ids to add to the firewall | `list(any)` | `[]` | no |
| <a name="input_extra_tags"></a> [extra\_tags](#input\_extra\_tags) | additional tags | `map(string)` | `{}` | no |
| <a name="input_hns_enabled"></a> [hns\_enabled](#input\_hns\_enabled) | Hierchical Namespace | `bool` | `"false"` | no |
| <a name="input_make_spn_contributor"></a> [make\_spn\_contributor](#input\_make\_spn\_contributor) | Makes the spn contributor on provided Containers | `bool` | `false` | no |
| <a name="input_namings"></a> [namings](#input\_namings) | the object of the onelab-standards | `any` | n/a | yes |
| <a name="input_private_endpoint_subnet_id"></a> [private\_endpoint\_subnet\_id](#input\_private\_endpoint\_subnet\_id) | Subnet holding the NIC's for the private endpoint(s). | `string` | `null` | no |
| <a name="input_private_endpoints"></a> [private\_endpoints](#input\_private\_endpoints) | A map of subResourceNames with their Private Endpoint Zone Id | `map(string)` | `{}` | no |
| <a name="input_resource_group"></a> [resource\_group](#input\_resource\_group) | resource\_group data | `any` | n/a | yes |
| <a name="input_shared_access_key_enabled"></a> [shared\_access\_key\_enabled](#input\_shared\_access\_key\_enabled) | Indicates whether the storage account permits requests to be authorized with the account access key via Shared Key. | `bool` | `false` | no |
| <a name="input_storage_containers"></a> [storage\_containers](#input\_storage\_containers) | Map of which the key is the container name and the value a nested map with IAM permissions. | <pre>map(object({<br>    access_type    = optional(string),<br>    authorizations = optional(map(string), {}),<br>  }))</pre> | `{}` | no |
| <a name="input_storage_tables"></a> [storage\_tables](#input\_storage\_tables) | Map of which the key is the table name and the value a nested map with IAM permissions. | <pre>map(object({<br>    authorizations = optional(map(string), {}),<br>  }))</pre> | `{}` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_adlsfs"></a> [adlsfs](#output\_adlsfs) | n/a |
| <a name="output_private_endpoint_ids"></a> [private\_endpoint\_ids](#output\_private\_endpoint\_ids) | n/a |
| <a name="output_private_endpoints"></a> [private\_endpoints](#output\_private\_endpoints) | n/a |
| <a name="output_sa"></a> [sa](#output\_sa) | n/a |

## Calling the module

<details>
<summary>Click to expand</summary>

```hcl
provider "azurerm" {
  features {}
  storage_use_azuread = true
}

provider "azurerm" {
  alias           = "ccc_management"
  subscription_id = "f13f81f8-7578-4ca8-83f3-0a845fad3cb5" # sub-prd-global-cccmanagement
  features {}
  skip_provider_registration = true
}

module "namings" {
  source      = "../../rabobank-onelab-standards"
  bp_code     = var.bp_code
  department  = var.department
  location    = var.location
  project     = var.project
  seq_nr      = random_integer.rnd_sq.result
  environment = var.environment
}

resource "random_id" "rg_name" {
  byte_length = 8
}

resource "random_integer" "rnd_sq" {
  min = 10
  max = 99
}

resource "null_resource" "delete_rg" {
  # Resource groups are sometimes not deleted due to errors. This null_resource prevents flaky tests.
  provisioner "local-exec" {
    command    = "az group delete --name 'test-module-storage-account-${random_id.rg_name.hex}-rg' --subscription '409c506d-38d6-46b8-bd83-301633d8a28d' --yes"
    on_failure = continue
  }
}

resource "azurerm_resource_group" "test" {
  name       = "test-module-storage-account-${random_id.rg_name.hex}-rg"
  location   = "West Europe"
  tags       = module.namings.default_tags # Policy: resource group needs certain tags
  depends_on = [null_resource.delete_rg]
}

resource "azurerm_virtual_network" "example" {
  name                = "virtnetname"
  address_space       = ["10.2.0.0/16"]
  location            = azurerm_resource_group.test.location
  resource_group_name = azurerm_resource_group.test.name

  tags = module.namings.default_tags # Policy: vnet needs certain tags
}

resource "azurerm_subnet" "example" {
  name                 = "subnetname"
  resource_group_name  = azurerm_resource_group.test.name
  virtual_network_name = azurerm_virtual_network.example.name
  address_prefixes     = ["10.2.0.0/24"]
  service_endpoints    = ["Microsoft.Sql", "Microsoft.Storage"]
}

resource "azurerm_subnet" "private_endpoint_subnet" {
  name                 = "privateendpointsubnetname"
  resource_group_name  = azurerm_resource_group.test.name
  virtual_network_name = azurerm_virtual_network.example.name
  address_prefixes     = ["10.2.1.0/24"]
  service_endpoints    = ["Microsoft.Sql", "Microsoft.Storage"]
}

resource "azurerm_private_dns_zone" "blob" {
  name                = "privatelink.blob.core.windows.net"
  resource_group_name = azurerm_resource_group.test.name
}

resource "azurerm_private_dns_zone" "dfs" {
  name                = "privatelink.dfs.core.windows.net"
  resource_group_name = azurerm_resource_group.test.name
}

resource "azurerm_private_dns_zone" "table" {
  name                = "privatelink.table.core.windows.net"
  resource_group_name = azurerm_resource_group.test.name
}

module "storage_account" {
  source                   = "./.."
  resource_group           = azurerm_resource_group.test
  namings                  = module.namings
  hns_enabled              = var.hns_enabled
  account_tier             = var.account_tier
  account_replication_type = var.account_replication_type
  extra_fw_ip_rules        = var.ip_rules
  extra_fw_subnet_ids = [
    azurerm_subnet.example.id
  ]
  storage_containers              = var.storage_containers
  storage_tables                  = var.storage_tables
  make_spn_contributor            = var.make_spn_contributor
  shared_access_key_enabled       = var.shared_access_key_enabled
  private_endpoint_subnet_id      = azurerm_subnet.private_endpoint_subnet.id
  allow_nested_items_to_be_public = var.allow_nested_items_to_be_public
  dev_access_from_local           = var.dev_access_from_local
  private_endpoints = {
    "blob" : azurerm_private_dns_zone.blob.id,
    "dfs" : azurerm_private_dns_zone.dfs.id,
    "table" : azurerm_private_dns_zone.table.id
  }
  extra_tags = var.extra_tags
  providers = {
    azurerm                = azurerm
    azurerm.ccc_management = azurerm.ccc_management
  }
}
```

</details>
<!-- END_TF_DOCS -->