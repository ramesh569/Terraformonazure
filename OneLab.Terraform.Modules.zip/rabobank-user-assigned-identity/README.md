<!-- BEGIN_TF_DOCS -->
# Module: user-assigned-identity
## Description
This module includes:
- Creation of a user assigned identity
- (Optionally) add role assignments to created identity

## CCC alignment
This module follow the CCC security guidelines, as indicated in the link below
- [CCC Resource Overview](https://confluence.dev.rabobank.nl/display/Azure/Quickstarts)

## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >1.10.0 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >= 4.0.1, < 5.0.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | >= 4.0.1, < 5.0.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_role_assignment.msi_roles](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/role_assignment) | resource |
| [azurerm_user_assigned_identity.user_identity](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/user_assigned_identity) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_extra_tags"></a> [extra\_tags](#input\_extra\_tags) | additional tags | `map(string)` | `{}` | no |
| <a name="input_namings"></a> [namings](#input\_namings) | the object of the onelab-standards | `any` | n/a | yes |
| <a name="input_resource_group"></a> [resource\_group](#input\_resource\_group) | The object of the resource group in which to create the User Assigned Identity. | `any` | n/a | yes |
| <a name="input_role_assignments"></a> [role\_assignments](#input\_role\_assignments) | The role assignments for the managed identity. Format: role: scope | <pre>list(object({<br>    role        = string<br>    resource_id = string<br>    condition   = optional(string, null)<br>  }))</pre> | `[]` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_user_assigned_identity"></a> [user\_assigned\_identity](#output\_user\_assigned\_identity) | User-Assigned Identity |

## Calling the module

<details>
<summary>Click to expand</summary>

```hcl
provider "azurerm" {
  features {}
}

module "namings" {
  source      = "../../rabobank-onelab-standards"
  bp_code     = var.bp_code
  department  = var.department
  location    = var.location
  project     = var.project
  seq_nr      = random_integer.rnd_sq.result
  environment = var.environment
}

resource "random_id" "rg_name" {
  byte_length = 8
}

resource "random_integer" "rnd_sq" {
  min = 10
  max = 99
}

resource "null_resource" "delete_rg" {
  # Resource groups are sometimes not deleted due to errors. This null_resource prevents flaky tests.
  provisioner "local-exec" {
    command    = "az group delete --name 'test-module-uai-${random_id.rg_name.hex}-rg' --subscription '409c506d-38d6-46b8-bd83-301633d8a28d' --yes"
    on_failure = continue
  }
}

resource "azurerm_resource_group" "test" {
  name       = "test-module-uai-${random_id.rg_name.hex}-rg"
  location   = module.namings.location
  tags       = module.namings.default_tags # Policy: resource group needs certain tags
  depends_on = [null_resource.delete_rg]
}

module "user_identity" {
  source         = "./.."
  namings        = module.namings
  resource_group = azurerm_resource_group.test
  role_assignments = [{
    role        = "Contributor",
    resource_id = azurerm_resource_group.test.id
  }]
}
```

</details>
<!-- END_TF_DOCS -->