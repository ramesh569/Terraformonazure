<!-- BEGIN_TF_DOCS -->
# Module: virtual-machine
This module includes:
- Creation of a virtual machine

## Important Design decisions

- option to create vm out of image or not

## CCC alignment
This module follow the CCC security guidelines, as indicated in the link below
- [CCC Resource Overview](https://confluence.dev.rabobank.nl/display/Azure/Quickstarts)

## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >1.10.0 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >= 4.0.1, < 5.0.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | >= 4.0.1, < 5.0.0 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_disk"></a> [disk](#module\_disk) | ./submodules/disk | n/a |

## Resources

| Name | Type |
|------|------|
| [azurerm_network_interface.vm_nic](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_interface) | resource |
| [azurerm_network_interface_security_group_association.vm_nsg_association](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_interface_security_group_association) | resource |
| [azurerm_resource_group.rg-vm](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_virtual_machine.vm](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_machine) | resource |
| [azurerm_image.search](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/image) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_namings"></a> [namings](#input\_namings) | the object of the onelab-standards | `any` | n/a | yes |
| <a name="input_network"></a> [network](#input\_network) | network object | `any` | n/a | yes |
| <a name="input_resource_group"></a> [resource\_group](#input\_resource\_group) | resourcegroup object | `any` | n/a | yes |
| <a name="input_subnet_name"></a> [subnet\_name](#input\_subnet\_name) | name of vm subnet | `string` | n/a | yes |
| <a name="input_vm_hostname"></a> [vm\_hostname](#input\_vm\_hostname) | hostname of vm | `string` | n/a | yes |
| <a name="input_vm_settings"></a> [vm\_settings](#input\_vm\_settings) | config settings vm | `any` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_vm"></a> [vm](#output\_vm) | n/a |

## Calling the module

<details>
<summary>Click to expand</summary>

```hcl
module "namings" {
  source      = "../../rabobank-onelab-standards"
  bp_code     = var.bp_code
  department  = var.department
  location    = var.location
  project     = var.project
  seq_nr      = "01"
  environment = var.environment
}

resource "random_id" "rg_name" {
  byte_length = 8
}

resource "azurerm_resource_group" "test" {
  name     = "test-module-appplan-${random_id.rg_name.hex}-rg"
  location = module.namings.location
  tags     = module.namings.default_tags # Policy: resource group needs certain tags
}

module "onelab_network" {
  source             = "../../rabobank-networking"
  resource_group     = azurerm_resource_group.test
  namings            = module.namings
  vnet_address_space = local.vnet_address_space
  subnets            = local.subnets
}

# module "vm" {
#   for_each       = local.vm_settings
#   source         = "./.."
#   namings        = module.namings
#   resource_group = azurerm_resource_group.test
#   network        = module.onelab_network
#   subnet_name    = "vm_subnet"
#   vm_hostname    = each.key
#   vm_settings    = each.value
# }
```

</details>
<!-- END_TF_DOCS -->