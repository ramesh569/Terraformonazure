<!-- BEGIN_TF_DOCS -->


## CCC alignment
This module follow the CCC security guidelines, as indicated in the link below
- [CCC Resource Overview](https://confluence.dev.rabobank.nl/display/Azure/Quickstarts)

## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >1.10.0 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >= 4.0.1, < 5.0.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | >= 4.0.1, < 5.0.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_image.vhd_image](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/image) | resource |
| [azurerm_managed_disk.extra_disk](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/managed_disk) | resource |
| [azurerm_network_interface.vm_nic](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_interface) | resource |
| [azurerm_network_interface_security_group_association.vm_nsg_association](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/network_interface_security_group_association) | resource |
| [azurerm_virtual_machine.vm](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_machine) | resource |
| [azurerm_virtual_machine_data_disk_attachment.extra_disk_attachment](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_machine_data_disk_attachment) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_namings"></a> [namings](#input\_namings) | the object of the onelab-standards | `any` | n/a | yes |
| <a name="input_network"></a> [network](#input\_network) | network object | `any` | n/a | yes |
| <a name="input_plan"></a> [plan](#input\_plan) | info for vm plan (currently required for neo4j hardened images) | `map(string)` | `{}` | no |
| <a name="input_resource_group"></a> [resource\_group](#input\_resource\_group) | resourcegroup object | `any` | n/a | yes |
| <a name="input_subnet_name"></a> [subnet\_name](#input\_subnet\_name) | name of vm subnet | `string` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | additional tags | `map(string)` | `{}` | no |
| <a name="input_vm_fromvhd_settings"></a> [vm\_fromvhd\_settings](#input\_vm\_fromvhd\_settings) | config settings vm | `any` | n/a | yes |
| <a name="input_vm_public_key"></a> [vm\_public\_key](#input\_vm\_public\_key) | VM SSH Public key | `any` | n/a | yes |

## Outputs

No outputs.

## Calling the module

<details>
<summary>Click to expand</summary>

```hcl
module "namings" {
  source      = "../../rabobank-onelab-standards"
  bp_code     = var.bp_code
  department  = var.department
  location    = var.location
  project     = var.project
  seq_nr      = "01"
  environment = var.environment
}

resource "random_id" "rg_name" {
  byte_length = 8
}

resource "null_resource" "delete_rg" {
  # Resource groups are sometimes not deleted due to errors. This null_resource prevents flaky tests.
  provisioner "local-exec" {
    command    = "az group delete --name 'test-module-vm-${random_id.rg_name.hex}-rg' --subscription '409c506d-38d6-46b8-bd83-301633d8a28d' --yes"
    on_failure = continue
  }
}

resource "azurerm_resource_group" "test" {
  name       = "test-module-vm-${random_id.rg_name.hex}-rg"
  location   = module.namings.location
  tags       = module.namings.default_tags # Policy: resource group needs certain tags
  depends_on = [null_resource.delete_rg]
}

module "onelab_network" {
  source             = "../../rabobank-networking"
  resource_group     = azurerm_resource_group.test
  namings            = module.namings
  vnet_address_space = local.vnet_address_space
  subnets            = local.subnets
}

module "vmfromvhd" {
  source              = "./.."
  namings             = module.namings
  resource_group      = azurerm_resource_group.test
  network             = module.onelab_network
  subnet_name         = "sn-vms-public"
  vm_fromvhd_settings = local.vm_fromvhd_settings
  vm_public_key       = file("./ssh/id_rsa.pub")
  tags = {
    AcceptedException_VM-H-002 = "VM within databricks project"
    AcceptedException_VM-H-008 = "VM within databricks project"
    AcceptedException_VM-H-009 = "Custom VM with approved OS version"
    AcceptedException_VM-H-005 = "VM with no internet connection/outbound"
    AcceptedException_VM-H-006 = "VM with no internet connection/outbound"
  }
  plan = var.plan
}
```

</details>
<!-- END_TF_DOCS -->