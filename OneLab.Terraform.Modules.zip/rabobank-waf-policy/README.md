<!-- BEGIN_TF_DOCS -->


## CCC alignment
This module follow the CCC security guidelines, as indicated in the link below
- [CCC Resource Overview](https://confluence.dev.rabobank.nl/display/Azure/Quickstarts)

## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >1.10.0 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >= 4.0.1, < 5.0.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | >= 4.0.1, < 5.0.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_web_application_firewall_policy.waf_policy](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/web_application_firewall_policy) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_custom_rules"></a> [custom\_rules](#input\_custom\_rules) | List of custom rules configuration for the WAF Policy | <pre>list(object({<br>    name      = optional(string)<br>    priority  = number<br>    rule_type = string<br>    action    = string // Allow, Block, Log<br>    match_conditions = list(object({<br>      match_variables = list(object({<br>        variable_name = string<br>        selector      = optional(string, null)<br>      }))<br>      match_values = optional(list(string))<br>      operator     = string<br>      negation     = optional(string, null)<br>      transforms   = optional(list(string), null)<br>    }))<br>  }))</pre> | `[]` | no |
| <a name="input_exclusions"></a> [exclusions](#input\_exclusions) | Exclusion rules configuration for the WAF Policy | <pre>list(object({<br>    match_variable          = string<br>    selector                = string<br>    selector_match_operator = string<br>    excluded_rule_set = optional(list(object({<br>      type    = optional(string, "OWASP")<br>      version = optional(string, "3.2")<br>      rule_groups = optional(list(object({<br>        rule_group_name = optional(string)<br>        excluded_rules  = optional(string)<br>      })))<br>    })))<br>  }))</pre> | `[]` | no |
| <a name="input_extra_tags"></a> [extra\_tags](#input\_extra\_tags) | Additional Tags | `map(string)` | `{}` | no |
| <a name="input_managed_rule_set"></a> [managed\_rule\_set](#input\_managed\_rule\_set) | Managed rule set configuration for the WAF Policy | <pre>list(object({<br>    type    = optional(string, "OWASP")<br>    version = optional(string, "3.2")<br>    rule_group_overrides = list(object({<br>      rule_group_name = optional(string, null)<br>      rules = list(object({<br>        id      = string<br>        enabled = optional(bool)<br>        action  = optional(string)<br>      }))<br>    }))<br>  }))</pre> | `[]` | no |
| <a name="input_namings"></a> [namings](#input\_namings) | The object of the onelab-standards | `any` | n/a | yes |
| <a name="input_policy_file_limit"></a> [policy\_file\_limit](#input\_policy\_file\_limit) | Policy regarding the size limit of uploaded files. Value is in MB. Accepted values are in the range `1` to `4000`. Defaults to `100`. | `number` | `100` | no |
| <a name="input_policy_max_body_size"></a> [policy\_max\_body\_size](#input\_policy\_max\_body\_size) | Policy regarding the maximum request body size. Value is in KB. Accepted values are in the range `8` to `2000`. Defaults to `128`. | `number` | `128` | no |
| <a name="input_policy_mode"></a> [policy\_mode](#input\_policy\_mode) | WAF Policy mode can be Detection or Prevention | `string` | `"Prevention"` | no |
| <a name="input_policy_request_body_check_enabled"></a> [policy\_request\_body\_check\_enabled](#input\_policy\_request\_body\_check\_enabled) | Describes if the Request Body Inspection is enabled. Defaults to `true`. | `string` | `true` | no |
| <a name="input_resource_group"></a> [resource\_group](#input\_resource\_group) | Resource Group | `any` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_http_listener_ids"></a> [http\_listener\_ids](#output\_http\_listener\_ids) | A list of HTTP Listener IDs from an azurerm\_application\_gateway. |
| <a name="output_path_based_rule_ids"></a> [path\_based\_rule\_ids](#output\_path\_based\_rule\_ids) | A list of URL Path Map Path Rule IDs from an azurerm\_application\_gateway. |
| <a name="output_waf_policy_id"></a> [waf\_policy\_id](#output\_waf\_policy\_id) | Waf Policy ID |

## Calling the module

<details>
<summary>Click to expand</summary>

```hcl
provider "azurerm" {
  features {}
}

module "namings" {
  source      = "../../rabobank-onelab-standards"
  bp_code     = var.bp_code
  department  = var.department
  location    = var.location
  project     = var.project
  seq_nr      = random_integer.rnd_sq.result
  environment = var.environment
}

resource "random_id" "rg_name" {
  byte_length = 8
}

resource "random_integer" "rnd_sq" {
  min = 10
  max = 99
}

resource "null_resource" "delete_rg" {
  # Resource groups are sometimes not deleted due to errors. This null_resource prevents flaky tests.
  provisioner "local-exec" {
    command    = "az group delete --name 'test-module-waf-${random_id.rg_name.hex}-rg' --subscription '409c506d-38d6-46b8-bd83-301633d8a28d' --yes"
    on_failure = continue
  }
}

resource "azurerm_resource_group" "test" {
  name       = "test-module-waf-${random_id.rg_name.hex}-rg"
  location   = module.namings.location
  tags       = merge(module.namings.default_tags, var.extra_tags)
  depends_on = [null_resource.delete_rg]
}

module "waf_policy" {
  source                            = "./.."
  namings                           = module.namings
  resource_group                    = azurerm_resource_group.test
  policy_file_limit                 = 100
  policy_request_body_check_enabled = true
  policy_max_body_size              = 128
  managed_rule_set                  = var.managed_rule_set
  exclusions                        = var.exclusions
  custom_rules                      = var.custom_rules
}
```

</details>
<!-- END_TF_DOCS -->