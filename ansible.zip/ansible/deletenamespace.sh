#!/bin/bash
#Date 31-3-2023
#Purpose delete cluster
if [ -z "$1" ] ; then
        echo "Usage: $0 <namespace>"
        exit 1
fi
name=$1
for i in `kubectl get ns |awk '{print $1}'|grep -v NAME`;do
    if [ "$i" ==  "$1" ]; then
    echo "Removing namespace"
    kubectl delete ns $1
    echo "PV dont get remove removing them forcefully"

    for i in `kubectl get pv -n $name |awk '{print $1}' |grep -v NAME`;do kubectl delete pv $i -n $name;done
    echo "Removing the file share for $name"
    sudo rm -rf /srv/nfsshare/$name
    fi
done
