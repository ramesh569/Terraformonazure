#!bin/bash

log_filename="/appl/riskshield/log/server/rba-dec-sc-processmonitoring.log"

clear_log_file(){
	> "$log_filename"
}

while true
do
	if [ ! -f "$log_filename" ]; then
		touch "$log_filename"
	fi

	current_day=$(date "+%Y-%m-%d")
	last_day=$(tail -n 1 $log_filename | awk '{print $3}')

	if [[ "$current_day" != "$last_day" ]]; then
		clear_log_file
	fi

	if pgrep "java" > null; then
		echo " 0 | "$(date "+%Y-%m-%d %T")" | rba-dec-sc | Process Monitoring | I | Status is active - DEC process monitoring" >> "$log_filename"
	else
		echo " 0 | "$(date "+%Y-%m-%d %T")" | rba-dec-sc | Process Monitoring | I | Status is inactive - DEC process monitoring" >> "$log_filename"
	fi
	sleep 60
done
