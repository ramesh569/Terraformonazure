#$PRJPOD=`kubectl get pods |grep prj|cut -d\   -f1`
#kubectl exec -it $PRJPOD -- /bin/bash
if [ -z "$1" ] ; then
        echo "Usage: $0 <akscontext>"
        exit 1
fi
name=$1
kubectl config use-context $1
kubectl config get-contexts

