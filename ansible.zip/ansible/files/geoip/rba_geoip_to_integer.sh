#!/bin/bash
#set -xv
#
# Name:          geoip.sh
# Description:   Script that downloads geo-ip data files from Maxmind and prepares the data for Riskshield server
#                The downloaded data files are: GeoIP2-ISP-CSV
#                                               GeoIP2-City-CSV
#                                               GeoIP2-Country-CSV (not in use yet)
#                The generated csv files are:   GeoIP2-City-Locations-en.csv
#                                               GeoIP2-City-Blocks-IPv4.csv
#                                               GeoIP2-ISP-Blocks-IPv4.csv
#                                               GeoIP2-City-Blocks-IPv6.csv
#                                               GeoIP2-ISP-Blocks-IPv6.csv
#
# Revision
# Date          Name                 Description
# --------------------------------------------------------------------------------------------------------------------------
# 02-02-2022    Pieter Zeeman        Adjustments for 2 new columns in the incoming file GeoIP2-ISP-Blocks-IPv6
# 11-03-2022    Pieter Zeeman        Changes for new IPv4 downloads (Transfer from old GeoIPCityISPOrg-144.csv to GeoIP2)
# 09-05-2022    Pieter Zeeman        Switched off download section because firewall is blocking traffic
# 06-07-2022	Edward	Markx		 Applied script for RBA-application GeoIP lists
#===========================================================================================================================

[[ -f ${HOME}/appl_profile ]] && . ${HOME}/appl_profile &>/dev/null
#
LOGFILE=${VCSLOG}/$(basename $0).log
PIDFILE=~/$(basename $0).pid
DOWNLOAD=/appl/rba/Backup/DecisionServer/enrl/CityList/incoming
BINDIR=/appl/rba/Backup/DecisionServer/enrl/CityList/incoming
KEY="qHkWrn12PBQN"
SKIP=0


logError ()
{
  TS=`date +"%b %d %H:%M:%S"`
  echo "${TS} ERROR ${1}" | tee -a ${LOGFILE} | mailx -s "$(basename $0), ERROR maxmind, $(date "+%Y-%m-%d %H:%M")" ${MAILLIST}
}


logInfo ()
{
  TS=`date +"%b %d %H:%M:%S"`
  echo "${TS} INFO  ${1}" | tee -a ${LOGFILE}
}


[[ -f ${PIDFILE} ]] && {
  logError "$(basename $0) already running"
  SKIP=1
} || {
  echo $$ > ${PIDFILE}
}
trap "rm -f ${PIDFILE} ${LOGTMP} 2>/dev/null" 0 1 2 11 15


# cleanup () {
#   [[ -d ${DOWNLOAD} ]] && {
#     logInfo "Cleanup download directory ${DOWNLOAD}"
#     rm -rf ${DOWNLOAD}/GeoIP2-City-CSV
#     rm -rf ${DOWNLOAD}/GeoIP2-ISP-CSV
#     [[ $? -eq 0 ]] && {
#       logInfo "Cleanup successful"
#     } || {
#       logError "Cleanup failed, please check"
#     }
#   }
# }


# download () {
#   curl "https://www.maxmind.com/app/download_new?edition_id=GeoIP2-ISP-CSV&suffix=zip&license_key=${KEY}" -o ${DOWNLOAD}/GeoIP2-ISP-CSV.zip &>/dev/null
#   [[ $? -eq 0 ]] && {
#     logInfo "Download GeoIP2-ISP-CSV successful"
#     touch GeoIP2-ISP-CSV.zip.sem
#   } || {
#     logError "Download GeoIP2-ISP-CSV failed"
#     SKIP=1
#   }

#   curl "https://www.maxmind.com/app/download_new?edition_id=GeoIP2-City-CSV&suffix=zip&license_key=${KEY}" -o ${DOWNLOAD}/GeoIP2-City-CSV.zip &>/dev/null
#   [[ $? -eq 0 ]] && {
#     logInfo "Download GeoIP2-City-CSV successful"
#     touch GeoIP2-City-CSV.zip.sem
#   } || {
#     logError "Download GeoIP2-City-CSV failed"
#     SKIP=1
#   }

  # curl "https://www.maxmind.com/app/download_new?edition_id=GeoIP2-Country-CSV&suffix=zip&license_key=${KEY}" -o ${DOWNLOAD}/GeoIP2-Country-CSV.zip &>/dev/null
  # [[ $? -eq 0 ]] && {
  #   logInfo "Download GeoIP2-Country-CSV.zip successful"
  #   touch GeoIP2-Country-CSV.zip.sem
  # } || {
  #   logError "Download GeoIP2-Country-CSV failed"
  #   SKIP=1
  # }
# }


unzips () {
  FILES="GeoIP2-City-CSV.zip GeoLite2-ASN-CSV.zip"  #  GeoIP2-Country-CSV.zip
  for i in ${FILES}
  do
    mkdir ${DOWNLOAD}/${i%.*} &>/dev/null
    unzip -j -o ${DOWNLOAD}/${i} -d ${DOWNLOAD}/${i%.*} &>/dev/null
    [[ $? -eq 0 ]] && {
      logInfo "Unzip ${i} successful"
    } || {
      logError "Unzip ${i} failed"
      SKIP=1
    }
  done
}


process1 () {
  FILE=${DOWNLOAD}/GeoLite2-ASN-CSV/GeoLite2-ASN-Blocks-IPv4.csv
  [[ -f ${FILE} ]] && {
    ${BINDIR}/geoip2-csv-converter -include-cidr -include-integer-range -block-file=${FILE} -output-file=${FILE}-integer-cidr.csv
    [[ $? -eq 0 ]] && {
      logInfo "geoip2-csv-converter for ${FILE##*/} successful"
      NRFIELDS=$(awk -F "," 'NR==1{print NF}' ${FILE}-integer-cidr.csv)
      [[ ${NRFIELDS} -ne 12 ]] && {
        logError "Nr of fields not equal to 12. Please check input file ${FILE##*/}-integer-cidr.csv"
        SKIP=1
      } || {
        sed -nre 's/^([^,]+)(,)([0-9]+,[0-9]+,)(.*)$/\3\1\2\3\4/p' ${FILE}-integer-cidr.csv | cat <(echo network_start_integer_Index,network_last_integer_Index,network,autonomous_system_number,autonomous_system_organization) - > ${FILE}.tmp
        [[ $? -eq 0 ]] && {
          cp ${FILE}.tmp ${FILE}
          rm ${FILE}.tmp
          logInfo "Added extra columns to ${FILE##*/} succesful"
        } || {
          logError "Adding extra columns for ${FILE##*/} failed"
          SKIP=1
        }
      }
    } || {
      logError "geoip2-csv-converter for ${FILE##*/} failed"
      SKIP=1
    }
  } || {
    logError "File ${FILE} does not exist"
  }
}


process2 () {
  FILE=${DOWNLOAD}/GeoLite2-ASN-CSV/GeoLite2-ASN-Blocks-IPv6.csv
  [[ -f ${FILE} ]] && {
    ${BINDIR}/geoip2-csv-converter -include-cidr -include-integer-range -block-file=${FILE} -output-file=${FILE}-integer-cidr.csv
    [[ $? -eq 0 ]] && {
      logInfo "geoip2-csv-converter for ${FILE##*/} successful"
      NRFIELDS=$(awk -F "," 'NR==1{print NF}' ${FILE}-integer-cidr.csv)
      [[ ${NRFIELDS} -ne 12 ]] && {
        logError "Nr of fields not equal to 12. Please check input file ${FILE##*/}-integer-cidr.csv"
        SKIP=1
      } || {
        sed -nre 's/^([^,]+)(,)([0-9]+,[0-9]+,)(.*)$/\3\1\2\3\4/p' ${FILE}-integer-cidr.csv | cat <(echo network_start_integer_Index,network_last_integer_Index,network,autonomous_system_number,autonomous_system_organization) - > ${FILE}.tmp
        [[ $? -eq 0 ]] && {
          cp ${FILE}.tmp ${FILE}
          rm ${FILE}.tmp
          logInfo "Added extra columns to ${FILE##*/} succesful"
        } || {
          logError "Adding extra columns for ${FILE##*/} failed"
          SKIP=1
        }
      }
    } || {
      logError "geoip2-csv-converter for ${FILE##*/} failed"
      SKIP=1
    }
  } || {
    logError "File ${FILE} does not exist"
  }
}


process3 () {
  FILE=${DOWNLOAD}/GeoIP2-City-CSV/GeoIP2-City-Blocks-IPv4.csv
  [[ -f ${FILE} ]] && {
    ${BINDIR}/geoip2-csv-converter -include-cidr -include-integer-range -block-file=${FILE} -output-file=${FILE}-integer-cidr.csv
    [[ $? -eq 0 ]] && {
      logInfo "geoip2-csv-converter for ${FILE##*/} successful"
      NRFIELDS=$(awk -F "," 'NR==1{print NF}' ${FILE}-integer-cidr.csv)
      [[ ${NRFIELDS} -ne 12 ]] && {
        logError "Nr of fields not equal to 12. Please check input file ${FILE##*/}-integer-cidr.csv"
        SKIP=1
      } || {
        sed -nre 's/^([^,]+)(,)([0-9]+,[0-9]+,)(.*)$/\3\1\2\3\4/p' ${FILE}-integer-cidr.csv | cat <(echo network_start_integer_Index,network_last_integer_Index,network,network_start_integer,network_last_integer,geoname_id,registered_country_geoname_id,represented_country_geoname_id,is_anonymous_proxy,is_satellite_provider,postal_code,latitude,longitude,accuracy_radius) - > ${FILE}.tmp
        [[ $? -eq 0 ]] && {
          cp ${FILE}.tmp ${FILE}
          rm ${FILE}.tmp
          logInfo "Added extra columns to ${FILE##*/} succesful"
        } || {
          logError "Adding extra columns for ${FILE##*/} failed"
          SKIP=1
        }
      }
    } || {
      logError "geoip2-csv-converter for ${FILE##*/} failed"
      SKIP=1
    }
  } || {
    logError "File ${FILE} does not exist"
  }
}


process4 () {
  FILE=${DOWNLOAD}/GeoIP2-City-CSV/GeoIP2-City-Blocks-IPv6.csv
  [[ -f ${FILE} ]] && {
    ${BINDIR}/geoip2-csv-converter -include-cidr -include-integer-range -block-file=${FILE} -output-file=${FILE}-integer-cidr.csv
    [[ $? -eq 0 ]] && {
      logInfo "geoip2-csv-converter for ${FILE##*/} successful"
      NRFIELDS=$(awk -F "," 'NR==1{print NF}' ${FILE}-integer-cidr.csv)
      [[ ${NRFIELDS} -ne 12 ]] && {
        logError "Nr of fields not equal to 12. Please check input file ${FILE##*/}-integer-cidr.csv"
        SKIP=1
      } || {
        sed -nre 's/^([^,]+)(,)([0-9]+,[0-9]+,)(.*)$/\3\1\2\3\4/p' ${FILE}-integer-cidr.csv | cat <(echo network_start_integer_Index,network_last_integer_Index,network,network_start_integer,network_last_integer,geoname_id,registered_country_geoname_id,represented_country_geoname_id,is_anonymous_proxy,is_satellite_provider,postal_code,latitude,longitude,accuracy_radius) - > ${FILE}.tmp
        [[ $? -eq 0 ]] && {
          cp ${FILE}.tmp ${FILE}
          rm ${FILE}.tmp
          logInfo "Added extra columns to ${FILE##*/} succesful"
        } || {
          logError "Adding extra columns for ${FILE##*/} failed"
          SKIP=1
        }
      }
    } || {
      logError "geoip2-csv-converter for ${FILE##*/} failed"
      SKIP=1
    }
  } || {
    logError "File ${FILE} does not exist"
  }
}


# copyfiles () {
# FILES=(GeoIP2-City-Locations-en.csv GeoIP2-City-Blocks-IPv4.csv GeoIP2-ISP-Blocks-IPv4.csv GeoIP2-City-Blocks-IPv6.csv GeoIP2-ISP-Blocks-IPv6.csv)
# DEST=(${VCSDAT}/geoip2/citylocations/incoming ${VCSDAT}/geoip2/cityblocksV4/incoming ${VCSDAT}/geoip2/ispblocksV4/incoming ${VCSDAT}/geoip2/cityblocksV6/incoming ${VCSDAT}/geoip2/ispblocksV6/incoming)
# COUNT=0
# for i in ${FILES[@]}
# do
#   ABSOLUTEPATH=$(find ${VCSDAT}/geoip/download -name ${i})
#   [[ -n ${ABSOLUTEPATH} ]] && {
#     mkdir ${DEST} &>/dev/null
#     cp ${ABSOLUTEPATH} ${DEST[${COUNT}]}
#     [[ $? -eq 0 ]] && {
#       touch ${DEST[${COUNT}]}/${ABSOLUTEPATH##*/}.sem
#       logInfo "copy ${ABSOLUTEPATH##*/} successful"
#     } || {
#       logError "copy ${ABSOLUTEPATH##*/} failed"
#     }
#     COUNT=$((COUNT + 1))
#   }
# done
# }


########
# Main #
########
logInfo "Start $(basename $0) ..."
[[ ${SKIP} -eq 0 ]] && {
  cleanup
  #[[ ${SKIP} -eq 0 ]] && {
    #download
    [[ ${SKIP} -eq 0 ]] && {
      unzips
      [[ ${SKIP} -eq 0 ]] && {
        process1
        [[ ${SKIP} -eq 0 ]] && {
          process2
          [[ ${SKIP} -eq 0 ]] && {
            process3
            [[ ${SKIP} -eq 0 ]] && {
              process4
              [[ ${SKIP} -eq 0 ]] && {
                copyfiles
              }
            }
          }
        }
      }
    }
  #}
}
logInfo "End $(basename $0) ..."
