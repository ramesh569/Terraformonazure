#$PRJPOD=`kubectl get pods |grep prj|cut -d\   -f1`
#kubectl exec -it $PRJPOD -- /bin/bash
if [ -z "$1" ] ; then
        echo "Usage: $0 <namespace>"
        exit 1
fi
name=$1
kubectl exec -it `kubectl get pods -n $1 |grep prj|cut -d\   -f1` -n $1 -- /bin/bash
