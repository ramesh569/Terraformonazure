#!/bin/bash
. ${RSROOT}/.def_profile.sh
. ${RSROOT}/functions/riskshield_functions
if [[ -f ${RSSAPP}/run/${RSINST}.pid ]]
then
  PID=`cat ${RSSAPP}/run/${RSINST}.pid`
  ps -p ${PID} > /dev/null 2>&1
  if [[ $? -ne "0" ]]; then
    start_service
    printf "Service $RSINST \e[30;42;1m STARTED \e[0m \n"
  else
    printf "${RSINST}       Already RUNNING\n"
  fi
else
    printf "NO PID_FILE starting service for the first time\n"
    printf "\n"
    start_service
fi