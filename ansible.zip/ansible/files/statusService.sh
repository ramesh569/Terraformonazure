#!/bin/bash
export JVM=`which java`
PROC=`/usr/bin/ps -ef|grep java|grep -v grep`
GET_PID=`echo $PROC|awk '{print $2}'`
if [ -z "$GET_PID" ]; then
echo "$CONTAINERNAME process is not running"
else
echo "$CONTAINERNAME process is running with pid $GET_PID"
fi