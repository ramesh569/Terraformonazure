#!/bin/bash
. ${RSROOT}/.def_profile.sh
export JVM=`which java`
. ${RSROOT}/functions/riskshield_functions
if [[ -f ${RSSAPP}/run/${RSINST}.pid ]]
then
  PID=`cat ${RSSAPP}/run/${RSINST}.pid`
  ps -p ${PID} > /dev/null 2>&1
  if [[ $? == "1" ]]; then
     printf "${RSINST}       Already STOPPED\n"
  else
      CR_PORT=`awk '{if($1=="CR_PORT") print $3}' ${RSSAPP}/conf/server.properties`
      CR_PORT=${CR_PORT:? $(echo "Variable CR_PORT not set, please check..."; exit 1)}
      cd ${RSSAPP}
     ${JVM} -classpath "lib/*" ${RS_STOP} -p${CR_PORT}
     printf "\n"
     check_stop
  fi
fi