#!/usr/bin/python
# -*- coding: utf-8 -*-
# Author Sunil Sankar (sunil.sankar@rabobank.nl)
DOCUMENTATION = '''
---
module: mssql_sql
short_description: Run a SQL query on a Microsoft SQL Server database.
description:
  - Run a SQL query on a Microsoft SQL Server database.
options:
  username:
    description:
      - The username used to authenticate with.
    required: false
    default: ''
  password:
    description:
      - The password used to authenticate with.
    required: false
    default: ''
  host:
    description:
      - The host running the database.
    required: false
    default: 'localhost'
  port:
    description:
      - The database port to connect to.
    type: int
    required: false
    default: 1433
    aliases: ['login_port']
  db:
    description:
      - The name of the database.
    required: false
    default: ''
  sql:
    description:
      - The SQL query to run.
    required: false
  autocommit:
    description:
      - Automatically commit the change only if the import succeed. Sometimes it is necessary to use autocommit=true, since some content can't be changed within a transaction.
    required: false
    default: true
  tds_version:
    description:
      - The TDS protocol version to use.
    required: false
    default: 7.1
  as_dict:
    description:
      - If true, return results as a list of dictionaries.
    type: bool
    required: false
    default: false
  script:
    description:
        - The script you want to execute. Doesn't handle selects
    required: false
notes:
  - pymssql is installed
requirements: ['pymssql']
'''
EXAMPLES = '''
# Execute arbitrary sql
- mssql_sql:
    username: "{{ user }}"
    password: "{{ password }}"
    db: rac
    hostname: 
    sql: 'select username from dba_users'
# Execute arbitrary script1
- mssql_sql:
    username: "{{ user }}"
    password: "{{ password }}"
    db: rac
    script: /u01/scripts/create-all-the-procedures.sql
# Execute arbitrary script2
- mssql_sql:
    username: "{{ user }}"
    password: "{{ password }}"
    db: rac
    script: /u01/scripts/create-tables-and-insert-default-values.sql
'''
import os
from ansible.module_utils.basic import AnsibleModule
try:
    import pymssql

    HAS_LIB = True
except ImportError:
    HAS_LIB = False

def execute_sql_get(module, cursor, sql):
    try:
        cursor.execute(sql)
        result = (cursor.fetchall())
    except pymssql.DatabaseError  as exc:
        error, = exc.args
        #msg = 'Something went wrong while executing sql_get - %s sql: %s' % (error.message, sql)
        msg = '%s' %(error.message)
        module.fail_json(msg=msg, changed=False)
        return False
    return result

def execute_sql(module, cursor, conn, sql):
    if 'insert' or 'delete' or 'update' in sql.lower():
        docommit = True
    else:
        docommit = False

    
    try:
        # module.exit_json(msg=sql.strip())
        cursor.execute(sql)
    except pymssql.DatabaseError as exc:
        #error, = exc.args
        #msg = 'Something went wrong while executing sql - %s sql: %s' % (error.message, sql)
        #msg = '%s' %(error.message)
        module.exit_json(msg=msg, changed=True)
        return False
    
    if docommit:
        conn.commit()
    return True

def read_file(module, script):
    try:
        f = open(script, 'r')
        sqlfile = f.read()
        f.close()
        return sqlfile
    except IOError as e:
        msg = 'Couldn\'t open/read file: %s' % (e)
        module.fail_json(msg=msg, changed=False)
    return


def clean_sqlfile(sqlfile):
    sqlfile = sqlfile.strip()
    sqlfile = sqlfile.lstrip()
    sqlfile = sqlfile.lstrip()
    sqlfile = os.linesep.join([s for s in sqlfile.splitlines() if s])
    return sqlfile

#############
def main():
    """Main execution path."""

    module = AnsibleModule(
         argument_spec=dict(
            username=dict(required=False, aliases=['un', 'username']),
            password=dict(required=False, no_log=True, aliases=['pw']),
            db=dict(required=True),
            hostname=dict(required=False, default='localhost', aliases=['host']),
            port=dict(required=False, default=1433),
            sql=dict(required=False),
            script=dict(required=False),
         ),
         mutually_exclusive=[['sql', 'script']]
    )
    
    username = module.params["username"]
    password = module.params["password"]
    db = module.params["db"]
    hostname = module.params["hostname"]
    port = module.params["port"]
    sql = module.params["sql"]
    script = module.params["script"]
    
    if not HAS_LIB:
        module.fail_json(msg='pymssql is required for this module')
    try:
        conn = pymssql.connect(
            user=username, password=password, host=hostname, database=db)
        
    except Exception as e:
        if "Unknown database" in str(e):
            errno, errstr = e.args
            module.fail_json(msg="ERROR: %s %s" % (errno, errstr))
        else:
            module.fail_json(msg="unable to connect, check username and password are correct")
    cursor = conn.cursor(as_dict=True)
    if sql:      
       if sql.lower().startswith('select '):
          result = execute_sql_get(module, cursor, sql)
          module.exit_json(msg=result, changed=False)
       else:
          execute_sql(module, cursor, conn, sql)
          msg = 'SQL executed: %s' % (sql)
          module.exit_json(msg=msg, changed=True)
    else:
       sqlfile = read_file(module, script)
       if len(sqlfile) > 0:
          sqlfile = clean_sqlfile(sqlfile)
          sql = sqlfile.split('\nGO\n')
          for q in sql:
                try:
                  if q == 'GO':
                      continue
                  else:
                    cursor.execute(q)
                    conn.commit()
                    msg = 'Running %s' %(q)
                    module.exit_json(msg=msg, changed=True)
                except pymssql.DatabaseError:
                     msg = 'Already exist %s \nContents: \n%s' % (script, sqlfile)
                     module.exit_json(msg=msg, changed=False)
          msg = 'Finished running script %s \nContents: \n%s' % (script, sqlfile)
       else:
         module.fail_json(msg='SQL file seems to be empty')
    module.exit_json(msg="Unhandled exit", changed=False)

if __name__ == '__main__':
    main()

