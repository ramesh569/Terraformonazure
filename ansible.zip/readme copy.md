# Azure for AC5

AC5 is an AML application to scan the Correspondent Banking Transactions. This application uses Riskshield as a scanning engine.This repository can be used to install AC5 Applications. The Application structure split and sits into two linux servers. One is Scan Engine and another one is RCM Engine.

## Run

The playbook can be run either from Azure pipelines or in your local sandbox. Running in your local sandbox needs cloning the repo.

Running from Azure Pipeline :

It consists of two steps.

    1) Run the build using Build.yml - https://dev.azure.com/raboweb/RSP/_build?definitionId=10056

        You must select the branch from the ac5 repo to run the build. It create an artifact of complete ac5 repo.

    2) Run the Deploy using deploy.yml - https://dev.azure.com/raboweb/RSP/_build?definitionId=11337

        Run the deploy to the servers specified in the deploy.yml. You can deploy only to specific servers too. You must select the build version that you performed in the previous step.

Running from your sandbox :

    It involves multiple steps to run the project from your sandbox. You need to clone molecule repo along with ac5 repo to have your docker instance installed in your sandbox. But to make our life easier the R2-D2 team have configured a pipeline to perform all the steps automatically with few inputs.

    The below link has the complete procedure to install the Project in your sandbox

    https://confluence.dev.rabobank.nl/display/DET/yAML-+Setting+up+a+Sandbox+for+AC5

## Test

If you want to test the playbook, you can run the molecule locally from the sandbox that you setup as per previous step.

Run molecule from the ac5/ansible folder

$ molecule -c ../ansible-molecule-base/molecule.yml dependency$ molecule -c ../ansible-molecule-base/molecule.yml converge

This will provide you a docker container with all AC5 riskshield applications installed in it.

## Contact us :

If you have any more doubts about ac5 repository please contact us in below functional mailbox :

l.global.COO.ITSystems.R&F.Compliance.Detection.yAML@rabobank.com
